import { studioBus } from './eventBus';
import { DEFAULT_ASSET_VAULT_URL } from './secretsService';
import type { AssetCategory, StudioAssetItem } from '../types/studio';

export const ASSET_HUNT_TIMEOUT_MS = 5000;
export const MAX_HUNT_RESULTS = 16;

export interface AssetDepartmentMeta {
  id: AssetCategory;
  label: string;
  shortLabel: string;
  sourceKind: 'vault' | 'iconify' | 'wikimedia';
  accentBg: string;
  accentText: string;
  keywords: string[];
}

export const ASSET_DEPARTMENTS: AssetDepartmentMeta[] = [
  {
    id: 'vehicles',
    label: 'Vehicles',
    shortLabel: 'Vehicles',
    sourceKind: 'vault',
    accentBg: 'bg-[#007AFF]/12',
    accentText: 'text-[#007AFF]',
    keywords: [
      'vehicle',
      'vehicles',
      'car',
      'cars',
      'truck',
      'trucks',
      'bus',
      'bike',
      'motorcycle',
      'scooter',
      'tractor',
      'jeep',
      'suv',
      'van',
      'auto',
      'rickshaw',
      'tank',
      'helicopter',
      'plane',
      'boat',
      'ship',
      'train',
      'gaadi',
      'gadi',
      'गाड़ी',
      'ट्रक',
      'कार',
      'बाइक',
    ],
  },
  {
    id: 'characters',
    label: 'Characters',
    shortLabel: 'Characters',
    sourceKind: 'vault',
    accentBg: 'bg-[#5856D6]/12',
    accentText: 'text-[#5856D6]',
    keywords: [
      'character',
      'characters',
      'hero',
      'player',
      'npc',
      'human',
      'man',
      'woman',
      'soldier',
      'warrior',
      'police',
      'zombie',
      'monster',
      'enemy',
      'robot',
      'avatar',
      'animal',
      'horse',
      'dog',
      'villager',
      'farmer',
      'person',
      'खिलाड़ी',
      'कैरेक्टर',
    ],
  },
  {
    id: 'weapons_gear',
    label: 'Weapons',
    shortLabel: 'Weapons',
    sourceKind: 'vault',
    accentBg: 'bg-[#FF3B30]/12',
    accentText: 'text-[#DC2626]',
    keywords: [
      'weapon',
      'weapons',
      'gear',
      'gun',
      'rifle',
      'pistol',
      'shotgun',
      'sniper',
      'sword',
      'knife',
      'axe',
      'bow',
      'arrow',
      'shield',
      'armor',
      'helmet',
      'grenade',
      'ammo',
      'tool',
      'bandook',
      'talwar',
      'हथियार',
      'बंदूक',
    ],
  },
  {
    id: 'village_world',
    label: 'World',
    shortLabel: 'World',
    sourceKind: 'vault',
    accentBg: 'bg-[#10B981]/12',
    accentText: 'text-[#059669]',
    keywords: [
      'world',
      'village',
      'environment',
      'env',
      'building',
      'house',
      'hut',
      'home',
      'shop',
      'temple',
      'city',
      'town',
      'street',
      'road',
      'bridge',
      'tree',
      'trees',
      'forest',
      'rock',
      'mountain',
      'fence',
      'prop',
      'props',
      'furniture',
      'farm',
      'gaon',
      'ghar',
      'ped',
      'गाँव',
      'घर',
      'पेड़',
      'सड़क',
    ],
  },
  {
    id: 'textures_pbr',
    label: 'Textures',
    shortLabel: 'Textures',
    sourceKind: 'vault',
    accentBg: 'bg-[#F59E0B]/14',
    accentText: 'text-[#B45309]',
    keywords: [
      'texture',
      'textures',
      'pbr',
      'material',
      'materials',
      'albedo',
      'normal',
      'roughness',
      'grass',
      'dirt',
      'mud',
      'sand',
      'asphalt',
      'concrete',
      'brick',
      'wood',
      'metal',
      'stone',
      'marble',
      'fabric',
      'ground',
      'terrain',
      'floor',
      'wall',
    ],
  },
  {
    id: 'hdri_sky',
    label: 'Sky',
    shortLabel: 'Sky',
    sourceKind: 'vault',
    accentBg: 'bg-[#0EA5E9]/14',
    accentText: 'text-[#0284C7]',
    keywords: [
      'sky',
      'skybox',
      'hdri',
      'hdr',
      'exr',
      'sunset',
      'sunrise',
      'night',
      'clouds',
      'cloud',
      'atmosphere',
      'lighting',
      'daylight',
      'dusk',
      'dawn',
      'aasman',
      'आसमान',
    ],
  },
  {
    id: 'audio_sfx',
    label: 'Game SFX',
    shortLabel: 'Game SFX',
    sourceKind: 'vault',
    accentBg: 'bg-[#EC4899]/12',
    accentText: 'text-[#DB2777]',
    keywords: [
      'sfx',
      'sound',
      'sounds',
      'audio',
      'effect',
      'effects',
      'engine',
      'horn',
      'explosion',
      'gunshot',
      'shoot',
      'footstep',
      'crash',
      'hit',
      'ambient',
      'wind',
      'rain',
      'bgm',
      'music',
      'aawaz',
      'awaz',
      'आवाज़',
    ],
  },
  {
    id: 'app_audio',
    label: 'App Audio',
    shortLabel: 'App Audio',
    sourceKind: 'vault',
    accentBg: 'bg-[#8B5CF6]/12',
    accentText: 'text-[#7C3AED]',
    keywords: [
      'app audio',
      'ui sound',
      'ui sfx',
      'click',
      'tap',
      'chime',
      'beep',
      'notification',
      'alert',
      'pop',
      'whoosh',
      'success',
      'error sound',
      'button sound',
      'jingle',
    ],
  },
  {
    id: 'wikimedia_photos',
    label: 'Photos',
    shortLabel: 'Photos',
    sourceKind: 'wikimedia',
    accentBg: 'bg-[#14B8A6]/12',
    accentText: 'text-[#0F766E]',
    keywords: [
      'photo',
      'photos',
      'photograph',
      'image',
      'images',
      'picture',
      'pictures',
      'wikimedia',
      'commons',
      'wallpaper',
      'portrait',
      'landscape',
      'tasveer',
      'फोटो',
      'तस्वीर',
    ],
  },
  {
    id: 'iconify_icons',
    label: 'Icons',
    shortLabel: 'Icons',
    sourceKind: 'iconify',
    accentBg: 'bg-[#6366F1]/12',
    accentText: 'text-[#4F46E5]',
    keywords: [
      'icon',
      'icons',
      'iconify',
      'svg',
      'glyph',
      'symbol',
      'badge',
      'logo',
      'vector',
      'ui icon',
      'आइकन',
    ],
  },
];

export const VALID_ASSET_CATEGORIES = new Set<AssetCategory>(
  ASSET_DEPARTMENTS.map((d) => d.id)
);

const VAULT_DEPARTMENT_IDS: AssetCategory[] = ASSET_DEPARTMENTS.filter(
  (d) => d.sourceKind === 'vault'
).map((d) => d.id);

interface IndexedVaultCatalog {
  url: string;
  fetchedAt: number;
  totalCount: number;
  buckets: Record<AssetCategory, StudioAssetItem[]>;
}

const vaultCatalogCache = new Map<string, IndexedVaultCatalog>();

export interface AssetSubSearchResult {
  items: StudioAssetItem[];
  timedOut: boolean;
  error?: string;
}

export interface HuntAssetsOptions {
  query: string;
  categories?: AssetCategory[];
  assetVaultUrl?: string;
  limit?: number;
}

export interface AssetHuntResult {
  query: string;
  items: StudioAssetItem[];
  departments: AssetCategory[];
  catalogTotalCount: number;
  fromCache: boolean;
  timedOut: boolean;
  warnings: string[];
  durationMs: number;
}

function createEmptyBuckets(): Record<AssetCategory, StudioAssetItem[]> {
  return {
    vehicles: [],
    characters: [],
    weapons_gear: [],
    village_world: [],
    textures_pbr: [],
    hdri_sky: [],
    audio_sfx: [],
    app_audio: [],
    wikimedia_photos: [],
    iconify_icons: [],
  };
}

function normalizeDepartmentAlias(raw: string): AssetCategory | null {
  const key = raw.trim().toLowerCase().replace(/[\s-]+/g, '_');
  if (!key) return null;
  if (VALID_ASSET_CATEGORIES.has(key as AssetCategory)) {
    return key as AssetCategory;
  }

  if (/(vehicle|car|truck|bike|transport|auto|traffic|aircraft|ship|boat)/.test(key)) {
    return 'vehicles';
  }
  if (/(character|hero|npc|human|avatar|creature|animal|enemy|zombie|player|rig)/.test(key)) {
    return 'characters';
  }
  if (/(weapon|gear|gun|sword|armor|combat|ammo|equipment|tool)/.test(key)) {
    return 'weapons_gear';
  }
  if (/(village|world|env|environment|building|house|city|prop|foliage|tree|nature|road|architecture|scene)/.test(key)) {
    return 'village_world';
  }
  if (/(texture|pbr|material|surface|terrain|ground|decal)/.test(key)) {
    return 'textures_pbr';
  }
  if (/(hdri|hdr|sky|skybox|exr|atmosphere|envmap)/.test(key)) {
    return 'hdri_sky';
  }
  if (/(app_audio|ui_audio|ui_sound|ui_sfx|notification|interface_audio)/.test(key)) {
    return 'app_audio';
  }
  if (/(audio|sfx|sound|music|bgm|foley|voice|ambience|ambient)/.test(key)) {
    return 'audio_sfx';
  }
  if (/(photo|wikimedia|image|picture)/.test(key)) {
    return 'wikimedia_photos';
  }
  if (/(icon|iconify|svg|glyph)/.test(key)) {
    return 'iconify_icons';
  }
  return null;
}

function inferCategoryFromEntry(
  raw: Record<string, unknown>,
  fallbackDept: AssetCategory | null
): AssetCategory {
  const explicitFields = [
    raw.category,
    raw.department,
    raw.dept,
    raw.folder,
    raw.group,
    raw.type,
  ];
  for (const field of explicitFields) {
    if (typeof field === 'string') {
      const matched = normalizeDepartmentAlias(field);
      if (matched) return matched;
    }
  }

  if (fallbackDept) return fallbackDept;

  const urlOrPath = String(
    raw.url ?? raw.path ?? raw.file ?? raw.src ?? raw.name ?? ''
  ).toLowerCase();

  if (/\.(hdr|exr)$/.test(urlOrPath)) return 'hdri_sky';
  if (/\.(mp3|wav|ogg|m4a|flac)$/.test(urlOrPath)) {
    return /(ui|click|tap|chime|notif|beep|app)/.test(urlOrPath)
      ? 'app_audio'
      : 'audio_sfx';
  }

  const combinedText = [
    raw.name,
    raw.title,
    raw.path,
    raw.url,
    Array.isArray(raw.tags) ? raw.tags.join(' ') : '',
  ]
    .filter(Boolean)
    .join(' ');

  const guessed = inferDepartmentsFromQuery(combinedText);
  const firstVault = guessed.find((d) => VAULT_DEPARTMENT_IDS.includes(d));
  return firstVault ?? 'village_world';
}

function resolveCatalogAssetUrl(rawUrl: string, baseCatalogUrl: string): string {
  const trimmed = rawUrl.trim();
  if (!trimmed) return '';
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  try {
    return new URL(trimmed.replace(/^\/+/, ''), baseCatalogUrl).toString();
  } catch {
    return trimmed;
  }
}

function inferFormatFromUrl(url: string, explicitFormat?: unknown): string {
  if (typeof explicitFormat === 'string' && explicitFormat.trim()) {
    return explicitFormat.trim().replace(/^\./, '').toLowerCase();
  }
  const clean = url.split('?')[0].split('#')[0];
  const ext = clean.split('.').pop()?.toLowerCase() ?? '';
  if (ext && ext.length <= 6 && ext !== clean.toLowerCase()) {
    return ext;
  }
  return 'asset';
}

function normalizeRawCatalogEntry(
  entry: unknown,
  fallbackDept: AssetCategory | null,
  baseCatalogUrl: string,
  index: number
): StudioAssetItem | null {
  if (!entry || typeof entry !== 'object') return null;
  const obj = entry as Record<string, unknown>;

  const rawUrl = String(
    obj.url ?? obj.downloadUrl ?? obj.rawUrl ?? obj.path ?? obj.file ?? obj.src ?? ''
  ).trim();
  const resolvedUrl = resolveCatalogAssetUrl(rawUrl, baseCatalogUrl);

  const rawName = String(
    obj.name ?? obj.title ?? obj.label ?? obj.filename ?? ''
  ).trim();
  const derivedName =
    rawName ||
    resolvedUrl
      .split('/')
      .pop()
      ?.replace(/\.[^.]+$/, '')
      .replace(/[-_]+/g, ' ') ||
    `Asset ${index + 1}`;

  if (!resolvedUrl && !rawName) return null;

  const category = inferCategoryFromEntry(obj, fallbackDept);
  const rawPreview = String(
    obj.previewUrl ?? obj.thumbnail ?? obj.thumb ?? obj.preview ?? obj.image ?? ''
  ).trim();
  const previewUrl = rawPreview
    ? resolveCatalogAssetUrl(rawPreview, baseCatalogUrl)
    : undefined;

  const tags: string[] = [];
  if (Array.isArray(obj.tags)) {
    for (const t of obj.tags) {
      if (typeof t === 'string' && t.trim()) tags.push(t.trim().toLowerCase());
    }
  } else if (typeof obj.tags === 'string') {
    for (const t of obj.tags.split(/[,\s]+/)) {
      if (t.trim()) tags.push(t.trim().toLowerCase());
    }
  }
  if (typeof obj.pack === 'string' && obj.pack.trim()) {
    tags.push(obj.pack.trim().toLowerCase());
  }

  const sizeBytes =
    typeof obj.sizeBytes === 'number'
      ? obj.sizeBytes
      : typeof obj.size === 'number'
        ? obj.size
        : undefined;

  const idSource = String(obj.id ?? `${category}:${resolvedUrl || derivedName}:${index}`);

  return {
    id: idSource,
    name: derivedName,
    category,
    source: typeof obj.source === 'string' && obj.source.trim() ? obj.source.trim() : '3D Vault',
    url: resolvedUrl || baseCatalogUrl,
    previewUrl,
    format: inferFormatFromUrl(resolvedUrl || rawName, obj.format ?? obj.ext),
    license: typeof obj.license === 'string' ? obj.license.trim() : 'CC0 / Vault',
    sizeBytes,
    tags: tags.length > 0 ? Array.from(new Set(tags)) : undefined,
    selected: false,
    addedAt: Date.now(),
  };
}

function indexCatalogPayload(
  data: unknown,
  catalogUrl: string
): IndexedVaultCatalog {
  const buckets = createEmptyBuckets();
  let totalCount = 0;

  const pushArray = (arr: unknown[], fallbackDept: AssetCategory | null) => {
    for (let i = 0; i < arr.length; i++) {
      const normalized = normalizeRawCatalogEntry(
        arr[i],
        fallbackDept,
        catalogUrl,
        totalCount + i
      );
      if (normalized) {
        buckets[normalized.category].push(normalized);
        totalCount += 1;
      }
    }
  };

  if (Array.isArray(data)) {
    pushArray(data, null);
  } else if (data && typeof data === 'object') {
    const obj = data as Record<string, unknown>;
    const topArrays = ['assets', 'items', 'catalog', 'models'] as const;
    let handledTopArray = false;

    for (const key of topArrays) {
      if (Array.isArray(obj[key])) {
        pushArray(obj[key] as unknown[], null);
        handledTopArray = true;
      }
    }

    const nestedMap =
      (obj.departments && typeof obj.departments === 'object'
        ? (obj.departments as Record<string, unknown>)
        : null) ??
      (obj.categories && typeof obj.categories === 'object'
        ? (obj.categories as Record<string, unknown>)
        : null);

    if (nestedMap) {
      for (const [deptKey, deptValue] of Object.entries(nestedMap)) {
        const mappedDept = normalizeDepartmentAlias(deptKey);
        if (Array.isArray(deptValue)) {
          pushArray(deptValue, mappedDept);
        } else if (deptValue && typeof deptValue === 'object') {
          const inner = deptValue as Record<string, unknown>;
          if (Array.isArray(inner.items)) {
            pushArray(inner.items, mappedDept);
          } else if (Array.isArray(inner.assets)) {
            pushArray(inner.assets, mappedDept);
          }
        }
      }
    } else if (!handledTopArray) {
      for (const [key, value] of Object.entries(obj)) {
        const mappedDept = normalizeDepartmentAlias(key);
        if (Array.isArray(value)) {
          pushArray(value, mappedDept);
        } else if (value && typeof value === 'object') {
          for (const [subKey, subVal] of Object.entries(
            value as Record<string, unknown>
          )) {
            if (Array.isArray(subVal)) {
              pushArray(subVal, normalizeDepartmentAlias(subKey) ?? mappedDept);
            }
          }
        }
      }
    }
  }

  return {
    url: catalogUrl,
    fetchedAt: Date.now(),
    totalCount,
    buckets,
  };
}

export function clearAssetVaultCache(url?: string): void {
  if (url) {
    vaultCatalogCache.delete(url.trim());
  } else {
    vaultCatalogCache.clear();
  }
}

export function getCachedCatalogInfo(
  url?: string
): { totalCount: number; fetchedAt: number } | null {
  const key = (url?.trim() || DEFAULT_ASSET_VAULT_URL).trim();
  const cached = vaultCatalogCache.get(key);
  if (!cached) return null;
  return { totalCount: cached.totalCount, fetchedAt: cached.fetchedAt };
}

async function fetchJsonWithTimeout(
  url: string,
  timeoutMs = ASSET_HUNT_TIMEOUT_MS
): Promise<unknown> {
  const controller = new AbortController();
  const timerId = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return await response.json();
  } finally {
    window.clearTimeout(timerId);
  }
}

async function loadVaultCatalog(
  vaultUrl?: string
): Promise<{
  catalog: IndexedVaultCatalog | null;
  fromCache: boolean;
  timedOut: boolean;
  error?: string;
}> {
  const targetUrl = (vaultUrl?.trim() || DEFAULT_ASSET_VAULT_URL).trim();
  const cached = vaultCatalogCache.get(targetUrl);
  if (cached) {
    return { catalog: cached, fromCache: true, timedOut: false };
  }

  let parsedUrl: URL;
  try {
    parsedUrl = new URL(targetUrl);
  } catch {
    return {
      catalog: null,
      fromCache: false,
      timedOut: false,
      error: 'Invalid Asset Vault URL in Secrets.',
    };
  }

  if (parsedUrl.protocol !== 'https:' && parsedUrl.protocol !== 'http:') {
    return {
      catalog: null,
      fromCache: false,
      timedOut: false,
      error: 'Asset Vault URL must use https:// or http://.',
    };
  }

  try {
    const rawJson = await fetchJsonWithTimeout(
      parsedUrl.toString(),
      ASSET_HUNT_TIMEOUT_MS
    );
    const indexed = indexCatalogPayload(rawJson, parsedUrl.toString());
    vaultCatalogCache.set(targetUrl, indexed);
    return { catalog: indexed, fromCache: false, timedOut: false };
  } catch (err) {
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    return {
      catalog: null,
      fromCache: false,
      timedOut: isTimeout,
      error: isTimeout
        ? 'Asset Vault timed out after 5s'
        : err instanceof Error
          ? `Asset Vault: ${err.message}`
          : 'Unable to fetch Asset Vault catalog.json',
    };
  }
}

export function inferDepartmentsFromQuery(query: string): AssetCategory[] {
  const clean = query.trim().toLowerCase();
  if (!clean) {
    return ['vehicles', 'village_world'];
  }

  const scored: { id: AssetCategory; score: number }[] = [];
  for (const dept of ASSET_DEPARTMENTS) {
    let score = 0;
    for (const kw of dept.keywords) {
      if (clean === kw) {
        score += 10;
      } else if (clean.includes(kw)) {
        score += kw.includes(' ') ? 6 : 4;
      }
    }
    if (score > 0) {
      scored.push({ id: dept.id, score });
    }
  }

  if (scored.length === 0) {
    // Scoped default — never scans all 10 departments blindly
    return ['village_world', 'vehicles', 'characters'];
  }

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 3).map((s) => s.id);
}

function tokenizeQuery(query: string): string[] {
  const stopWords = new Set([
    'find',
    'search',
    'hunt',
    'get',
    'show',
    'asset',
    'assets',
    'vault',
    'for',
    'the',
    'a',
    'an',
    'me',
    'dhoondo',
    'dhundo',
    'khojo',
    'dikhao',
    'lao',
    'chahiye',
  ]);

  return query
    .toLowerCase()
    .split(/[^a-z0-9\u0900-\u097f]+/i)
    .map((t) => t.trim())
    .filter((t) => t.length >= 2 && !stopWords.has(t));
}

function scoreAssetItem(item: StudioAssetItem, tokens: string[], rawQuery: string): number {
  if (tokens.length === 0) return 1;

  const nameLower = item.name.toLowerCase();
  const tagsLower = (item.tags ?? []).join(' ').toLowerCase();
  const urlLower = item.url.toLowerCase();
  const fmtLower = (item.format ?? '').toLowerCase();

  let score = 0;
  const fullLower = rawQuery.trim().toLowerCase();
  if (fullLower && nameLower === fullLower) score += 25;
  else if (fullLower && nameLower.includes(fullLower)) score += 14;

  for (const tok of tokens) {
    if (nameLower === tok) score += 12;
    else if (nameLower.startsWith(tok)) score += 8;
    else if (nameLower.includes(tok)) score += 6;

    if (tagsLower.includes(tok)) score += 5;
    if (urlLower.includes(tok)) score += 3;
    if (fmtLower === tok) score += 4;
  }

  return score;
}

export async function searchIconifyIcons(
  query: string,
  limit = 12
): Promise<AssetSubSearchResult> {
  const clean = query.trim() || 'game';
  const url = `https://api.iconify.design/search?query=${encodeURIComponent(
    clean
  )}&limit=${Math.min(Math.max(1, limit), 24)}`;

  try {
    const json = (await fetchJsonWithTimeout(url, ASSET_HUNT_TIMEOUT_MS)) as {
      icons?: unknown;
    };
    const rawIcons = Array.isArray(json?.icons) ? json.icons : [];
    const now = Date.now();
    const items: StudioAssetItem[] = [];

    for (const iconKey of rawIcons) {
      if (typeof iconKey !== 'string' || !iconKey.includes(':')) continue;
      const [prefix, iconName] = iconKey.split(':');
      if (!prefix || !iconName) continue;
      const svgUrl = `https://api.iconify.design/${encodeURIComponent(
        prefix
      )}/${encodeURIComponent(iconName)}.svg`;
      items.push({
        id: `iconify:${iconKey}`,
        name: iconName.replace(/[-_]+/g, ' '),
        category: 'iconify_icons',
        source: `Iconify (${prefix})`,
        url: svgUrl,
        previewUrl: svgUrl,
        format: 'svg',
        license: 'Open Source SVG',
        tags: [prefix, ...iconName.split('-').filter(Boolean)],
        selected: false,
        addedAt: now,
      });
    }

    return { items, timedOut: false };
  } catch (err) {
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    return {
      items: [],
      timedOut: isTimeout,
      error: isTimeout
        ? 'Iconify timed out after 5s'
        : err instanceof Error
          ? `Iconify: ${err.message}`
          : 'Iconify search failed',
    };
  }
}

export async function searchWikimediaPhotos(
  query: string,
  limit = 12
): Promise<AssetSubSearchResult> {
  const clean = query.trim() || 'landscape';
  const url = `https://commons.wikimedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
    clean
  )}&srnamespace=6&srlimit=${Math.min(
    Math.max(1, limit),
    20
  )}&format=json&origin=*`;

  try {
    const json = (await fetchJsonWithTimeout(url, ASSET_HUNT_TIMEOUT_MS)) as {
      query?: {
        search?: { title?: string; pageid?: number; size?: number }[];
      };
    };

    const hits = Array.isArray(json?.query?.search) ? json.query.search : [];
    const now = Date.now();
    const items: StudioAssetItem[] = [];

    for (const hit of hits) {
      const fullTitle = typeof hit.title === 'string' ? hit.title : '';
      if (!fullTitle) continue;
      const fileName = fullTitle.replace(/^File:/i, '').trim();
      if (!fileName) continue;

      const ext = inferFormatFromUrl(fileName);
      // Skip non-image documents when hunting photos
      if (['pdf', 'djvu', 'ogg', 'ogv', 'webm', 'wav', 'mid'].includes(ext)) {
        continue;
      }

      const filePathUrl = `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(
        fileName
      )}?width=320`;
      const pageUrl = `https://commons.wikimedia.org/wiki/${encodeURIComponent(
        fullTitle.replace(/ /g, '_')
      )}`;

      items.push({
        id: `wikimedia:${hit.pageid ?? fileName}`,
        name: fileName.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' '),
        category: 'wikimedia_photos',
        source: 'Wikimedia Commons',
        url: pageUrl,
        previewUrl: filePathUrl,
        format: ext === 'asset' ? 'jpg' : ext,
        license: 'Wikimedia Commons',
        sizeBytes: typeof hit.size === 'number' ? hit.size : undefined,
        tags: clean.toLowerCase().split(/\s+/).filter(Boolean),
        selected: false,
        addedAt: now,
      });
    }

    return { items, timedOut: false };
  } catch (err) {
    const isTimeout = err instanceof DOMException && err.name === 'AbortError';
    return {
      items: [],
      timedOut: isTimeout,
      error: isTimeout
        ? 'Wikimedia timed out after 5s'
        : err instanceof Error
          ? `Wikimedia: ${err.message}`
          : 'Wikimedia search failed',
    };
  }
}

export async function huntStudioAssets(
  options: HuntAssetsOptions
): Promise<AssetHuntResult> {
  const startedAt = Date.now();
  const cleanQuery = options.query.trim();
  const limit = Math.min(Math.max(1, options.limit ?? MAX_HUNT_RESULTS), MAX_HUNT_RESULTS);

  const explicitCategories = (options.categories ?? []).filter((c) =>
    VALID_ASSET_CATEGORIES.has(c)
  );
  const targetDepartments =
    explicitCategories.length > 0
      ? Array.from(new Set(explicitCategories))
      : inferDepartmentsFromQuery(cleanQuery);

  const vaultDepts = targetDepartments.filter((d) =>
    VAULT_DEPARTMENT_IDS.includes(d)
  );
  const wantIcons = targetDepartments.includes('iconify_icons');
  const wantPhotos = targetDepartments.includes('wikimedia_photos');

  const deptLabel = targetDepartments
    .map((id) => ASSET_DEPARTMENTS.find((d) => d.id === id)?.shortLabel ?? id)
    .join(', ');

  studioBus.emit('bot:progress', {
    botId: 'asset',
    status: 'working',
    progress: 25,
    message: `Hunting ${deptLabel}...`,
  });

  let finalStatus: 'ready' | 'error' = 'ready';
  let finalProgress = 100;
  let finalMessage = 'Asset hunt ready';

  try {
    const warnings: string[] = [];
    let timedOut = false;
    let fromCache = false;
    let catalogTotalCount = 0;

    const tasks: Promise<void>[] = [];
    const scoredCandidates: { item: StudioAssetItem; score: number }[] = [];
    const tokens = tokenizeQuery(cleanQuery);

    if (vaultDepts.length > 0) {
      tasks.push(
        loadVaultCatalog(options.assetVaultUrl).then((res) => {
          fromCache = res.fromCache;
          if (res.timedOut) timedOut = true;
          if (res.error) warnings.push(res.error);
          if (!res.catalog) return;

          catalogTotalCount = res.catalog.totalCount;

          // Department-scoped scan ONLY — never touches unrelated buckets
          for (const dept of vaultDepts) {
            const bucket = res.catalog.buckets[dept] ?? [];
            const matchedInBucket: { item: StudioAssetItem; score: number }[] = [];

            for (const item of bucket) {
              const s = scoreAssetItem(item, tokens, cleanQuery);
              if (tokens.length === 0 || s > 0) {
                matchedInBucket.push({ item, score: s });
              }
            }

            // If user selected this exact department explicitly and typed a broad term,
            // surface top items from this department when strict token hits are empty.
            if (matchedInBucket.length === 0 && bucket.length > 0 && explicitCategories.length > 0) {
              for (const item of bucket.slice(0, limit)) {
                matchedInBucket.push({ item, score: 1 });
              }
            }

            scoredCandidates.push(...matchedInBucket);
          }
        })
      );
    }

    if (wantIcons) {
      const iconQuery =
        tokens
          .filter((t) => !['icon', 'icons', 'iconify', 'svg'].includes(t))
          .join(' ') || cleanQuery || 'app';
      tasks.push(
        searchIconifyIcons(iconQuery, 12).then((res) => {
          if (res.timedOut) timedOut = true;
          if (res.error) warnings.push(res.error);
          for (let i = 0; i < res.items.length; i++) {
            scoredCandidates.push({
              item: res.items[i],
              score: Math.max(10 - i * 0.2, 2),
            });
          }
        })
      );
    }

    if (wantPhotos) {
      const photoQuery =
        tokens
          .filter((t) =>
            !['photo', 'photos', 'image', 'images', 'picture', 'wikimedia'].includes(t)
          )
          .join(' ') || cleanQuery || 'nature';
      tasks.push(
        searchWikimediaPhotos(photoQuery, 12).then((res) => {
          if (res.timedOut) timedOut = true;
          if (res.error) warnings.push(res.error);
          for (let i = 0; i < res.items.length; i++) {
            scoredCandidates.push({
              item: res.items[i],
              score: Math.max(10 - i * 0.2, 2),
            });
          }
        })
      );
    }

    await Promise.allSettled(tasks);

    scoredCandidates.sort((a, b) => b.score - a.score);

    const deduped: StudioAssetItem[] = [];
    const seenIds = new Set<string>();
    for (const entry of scoredCandidates) {
      if (seenIds.has(entry.item.id)) continue;
      seenIds.add(entry.item.id);
      deduped.push(entry.item);
      if (deduped.length >= limit) break;
    }

    const durationMs = Date.now() - startedAt;

    if (deduped.length === 0 && warnings.length > 0) {
      finalStatus = 'error';
      finalProgress = 0;
      finalMessage = warnings[0];
    } else {
      finalStatus = 'ready';
      finalProgress = 100;
      finalMessage = `Found ${deduped.length} in ${deptLabel}`;
    }

    return {
      query: cleanQuery,
      items: deduped,
      departments: targetDepartments,
      catalogTotalCount,
      fromCache,
      timedOut,
      warnings,
      durationMs,
    };
  } catch (err) {
    finalStatus = 'error';
    finalProgress = 0;
    finalMessage =
      err instanceof Error ? err.message : 'Asset hunt interrupted';
    return {
      query: cleanQuery,
      items: [],
      departments: targetDepartments,
      catalogTotalCount: 0,
      fromCache: false,
      timedOut: false,
      warnings: [finalMessage],
      durationMs: Date.now() - startedAt,
    };
  } finally {
    // Zero-Hang Guarantee: ALWAYS resolve the Asset pill out of 'working'
    studioBus.emit('bot:progress', {
      botId: 'asset',
      status: finalStatus,
      progress: finalProgress,
      message: finalMessage,
    });
  }
}
