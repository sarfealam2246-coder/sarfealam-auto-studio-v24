import { requestStudioAICompletion } from './aiRouter';
import { studioBus } from './eventBus';
import { buildMemoryContext } from './memoryService';
import type { VirtualFile, WorldState } from '../types/studio';

export interface ApplyAIFileEditOptions {
  instruction: string;
  files: VirtualFile[];
  activeFilePath: string | null;
  state: WorldState;
}

export interface AIFileEditResult {
  ok: boolean;
  nextFiles: VirtualFile[];
  backupFiles: VirtualFile[];
  changedPaths: string[];
  summary: string;
  providerUsed: string;
  error?: string;
}

interface ParsedEditPayload {
  summary: string;
  updatedFiles: { path: string; content: string; language?: string }[];
}

function inferLanguage(path: string, fallback?: string): string {
  if (fallback && fallback.trim()) return fallback.trim().toLowerCase();
  const ext = path.split('.').pop()?.toLowerCase() ?? '';
  if (ext === 'tsx' || ext === 'ts') return ext;
  if (ext === 'jsx' || ext === 'js') return ext;
  if (ext === 'html' || ext === 'htm') return 'html';
  if (ext === 'css') return 'css';
  if (ext === 'json') return 'json';
  if (ext === 'md') return 'markdown';
  return 'text';
}

function parseAIFileEditJson(rawText: string): ParsedEditPayload | null {
  const trimmed = rawText.trim();
  if (!trimmed) return null;

  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenceMatch ? fenceMatch[1].trim() : trimmed;

  const tryParse = (str: string): ParsedEditPayload | null => {
    try {
      const parsed: unknown = JSON.parse(str);
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        return null;
      }
      const obj = parsed as Record<string, unknown>;
      if (!Array.isArray(obj.updatedFiles)) return null;

      const updatedFiles: { path: string; content: string; language?: string }[] = [];
      for (const item of obj.updatedFiles) {
        if (!item || typeof item !== 'object') continue;
        const rec = item as Record<string, unknown>;
        const path =
          typeof rec.path === 'string'
            ? rec.path.trim().replace(/^\/+/, '')
            : '';
        const content = typeof rec.content === 'string' ? rec.content : null;
        if (!path || content === null) continue;
        updatedFiles.push({
          path,
          content,
          language:
            typeof rec.language === 'string' ? rec.language.trim() : undefined,
        });
      }

      if (updatedFiles.length === 0) return null;

      const summary =
        typeof obj.summary === 'string' && obj.summary.trim()
          ? obj.summary.trim()
          : `Updated ${updatedFiles.length} file${updatedFiles.length === 1 ? '' : 's'}.`;

      return { summary, updatedFiles };
    } catch {
      return null;
    }
  };

  const direct = tryParse(candidate);
  if (direct) return direct;

  const firstBrace = candidate.indexOf('{');
  const lastBrace = candidate.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    return tryParse(candidate.slice(firstBrace, lastBrace + 1));
  }

  return null;
}

function buildFilesContext(files: VirtualFile[], activeFilePath: string | null): string {
  const active =
    files.find((f) => f.path === activeFilePath) ?? files[0] ?? null;

  const prioritized: VirtualFile[] = [];
  if (active) prioritized.push(active);
  for (const file of files) {
    if (active && file.path === active.path) continue;
    if (
      file.path === 'docs/index.html' ||
      file.path === 'index.html' ||
      file.path.endsWith('.css') ||
      file.path.endsWith('.html') ||
      file.path === 'assets/manifest.json'
    ) {
      prioritized.push(file);
    }
  }
  for (const file of files) {
    if (!prioritized.some((p) => p.path === file.path)) {
      prioritized.push(file);
    }
  }

  const maxChars = 14_000;
  let used = 0;
  const blocks: string[] = [];

  for (const file of prioritized.slice(0, 8)) {
    const snippet =
      file.content.length > 3500
        ? `${file.content.slice(0, 3500)}\n/* ...truncated... */`
        : file.content;
    const block = `--- FILE: ${file.path} (${file.language}) ---\n${snippet}`;
    if (used + block.length > maxChars && blocks.length > 0) break;
    blocks.push(block);
    used += block.length;
  }

  return blocks.join('\n\n');
}

export async function applyAIFileEdit(
  options: ApplyAIFileEditOptions
): Promise<AIFileEditResult> {
  const backupFiles = options.files.map((f) => ({ ...f }));
  const cleanInstruction = options.instruction.trim();

  if (!cleanInstruction) {
    return {
      ok: false,
      nextFiles: options.files,
      backupFiles,
      changedPaths: [],
      summary: 'Enter an edit instruction first.',
      providerUsed: 'Local',
      error: 'Empty edit instruction.',
    };
  }

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 30,
    message: 'AI editing virtual files...',
  });

  let finalStatus: 'ready' | 'error' = 'ready';
  let finalProgress = 100;
  let finalMessage = 'AI file edit staged';

  try {
    const memoryBlock = buildMemoryContext(options.state.memoryRules);
    const activeLabel = options.activeFilePath || options.files[0]?.path || 'docs/index.html';

    const systemPrompt = [
      'You are Sarfealam Auto-Studio Live AI File Editor.',
      options.state.language === 'hi'
        ? 'Write the summary in natural Hindi/Hinglish and keep code clean.'
        : 'Write a short, clear English summary and clean production-ready code.',
      ...(memoryBlock ? [memoryBlock] : []),
      'Return STRICT JSON ONLY (no markdown fences) matching this exact schema:',
      '{"summary":"short description of edits","updatedFiles":[{"path":"exact/file/path","content":"full updated file content","language":"html|css|js|ts|tsx|json|markdown"}]}',
      'Rules:',
      '- Always return COMPLETE file content for each edited file (never diffs or placeholders).',
      '- Prefer updating the active file or docs/index.html (for live iframe preview) unless the user asks to create/edit another file.',
    ].join('\n');

    const userPrompt = [
      `Active File: ${activeLabel}`,
      `All Workspace Files: [${options.files.map((f) => f.path).join(', ')}]`,
      '',
      'Current Workspace Context:',
      buildFilesContext(options.files, options.activeFilePath),
      '',
      `User Edit Instruction: ${cleanInstruction}`,
    ].join('\n');

    const completion = await requestStudioAICompletion(
      systemPrompt,
      userPrompt,
      options.state
    );

    if (!completion.ok) {
      throw new Error(completion.error || 'AI provider unavailable.');
    }

    const parsed = parseAIFileEditJson(completion.rawText);
    if (!parsed) {
      throw new Error('AI returned an invalid edit payload. Please try again.');
    }

    const now = Date.now();
    const nextMap = new Map<string, VirtualFile>();
    for (const file of backupFiles) {
      nextMap.set(file.path, { ...file });
    }

    const changedPaths: string[] = [];
    for (const edit of parsed.updatedFiles) {
      const existing = nextMap.get(edit.path);
      nextMap.set(edit.path, {
        path: edit.path,
        content: edit.content,
        language: inferLanguage(edit.path, edit.language ?? existing?.language),
        updatedAt: now,
        generatedBy: 'code',
      });
      changedPaths.push(edit.path);
    }

    const nextFiles = Array.from(nextMap.values());
    finalStatus = 'ready';
    finalProgress = 100;
    finalMessage = `Staged ${changedPaths.length} file edit${changedPaths.length === 1 ? '' : 's'} (${completion.providerUsed})`;

    return {
      ok: true,
      nextFiles,
      backupFiles,
      changedPaths,
      summary: parsed.summary,
      providerUsed: completion.providerUsed,
    };
  } catch (err) {
    const message =
      err instanceof Error ? err.message : 'AI file edit failed.';
    finalStatus = 'error';
    finalProgress = 0;
    finalMessage = message;
    return {
      ok: false,
      nextFiles: options.files,
      backupFiles,
      changedPaths: [],
      summary: message,
      providerUsed: 'Local',
      error: message,
    };
  } finally {
    studioBus.emit('bot:progress', {
      botId: 'code',
      status: finalStatus,
      progress: finalProgress,
      message: finalMessage,
    });
  }
}
