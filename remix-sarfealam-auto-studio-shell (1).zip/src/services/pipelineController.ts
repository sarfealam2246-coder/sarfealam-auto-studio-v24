import { studioBus } from './eventBus';

export type StageNumber = 1 | 2 | 3 | 4 | 5;

export interface PipelineStageInfo {
  number: StageNumber;
  short: string;
  label: string;
}

export const PIPELINE_STAGES: PipelineStageInfo[] = [
  { number: 1, short: 'Shell', label: '1. Shell' },
  { number: 2, short: 'Assets', label: '2. Assets' },
  { number: 3, short: 'Logic', label: '3. Logic' },
  { number: 4, short: 'Controls', label: '4. Controls' },
  { number: 5, short: 'Package', label: '5. Package' },
];

export function formatStageLabel(stage: StageNumber): string {
  return PIPELINE_STAGES[stage - 1]?.label ?? '1. Shell';
}

export function parseStageNumber(stageText?: string): StageNumber {
  if (!stageText) return 1;
  const lower = stageText.toLowerCase();
  const explicitNum = lower.match(/\b([1-5])\b/);
  if (explicitNum) {
    return Number(explicitNum[1]) as StageNumber;
  }
  if (lower.includes('package') || lower.includes('apk')) return 5;
  if (lower.includes('control')) return 4;
  if (lower.includes('logic')) return 3;
  if (lower.includes('asset')) return 2;
  return 1;
}

class StudioPipelineController {
  private stage: StageNumber = 1;
  private paused = false;
  private resumeWaiters = new Set<() => void>();

  syncFromWorld(currentStage: string, paused: boolean): void {
    this.stage = parseStageNumber(currentStage);
    const wasPaused = this.paused;
    this.paused = paused;
    if (wasPaused && !paused) {
      this.flushWaiters();
    }
  }

  getStage(): StageNumber {
    return this.stage;
  }

  getStageLabel(): string {
    return formatStageLabel(this.stage);
  }

  isPaused(): boolean {
    return this.paused;
  }

  private flushWaiters(): void {
    const callbacks = Array.from(this.resumeWaiters);
    this.resumeWaiters.clear();
    for (const resolve of callbacks) {
      resolve();
    }
  }

  /**
   * Cooperative checkpoint: resolves immediately if running,
   * or waits cleanly until resumeStudioPipeline() is invoked.
   */
  waitIfPaused(signal?: AbortSignal): Promise<void> {
    if (!this.paused) {
      return Promise.resolve();
    }
    if (signal?.aborted) {
      return Promise.reject(new DOMException('Pipeline checkpoint aborted', 'AbortError'));
    }

    return new Promise<void>((resolve, reject) => {
      const onResume = () => {
        if (signal) {
          signal.removeEventListener('abort', onAbort);
        }
        resolve();
      };

      const onAbort = () => {
        this.resumeWaiters.delete(onResume);
        reject(new DOMException('Pipeline checkpoint aborted', 'AbortError'));
      };

      this.resumeWaiters.add(onResume);
      if (signal) {
        signal.addEventListener('abort', onAbort, { once: true });
      }
    });
  }

  /**
   * STRICT NON-DESTRUCTIVE PAUSE:
   * Holds the exact stage cursor in place without disconnecting Voice,
   * wiping files/assets, or clearing secrets/memory rules.
   */
  pause(currentStage?: string): { stage: StageNumber; stageLabel: string } {
    if (currentStage) {
      this.stage = parseStageNumber(currentStage);
    }
    this.paused = true;
    const stageLabel = this.getStageLabel();

    studioBus.emit('world:update', {
      patch: {
        paused: true,
        currentStage: stageLabel,
      },
      source: 'pipeline-controller',
    });

    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'paused',
      progress: this.stage * 20,
      message: `Paused at Stage ${this.stage} (${PIPELINE_STAGES[this.stage - 1].short}) — Inspect Mode`,
    });

    return { stage: this.stage, stageLabel };
  }

  /**
   * Resumes cleanly from the exact held stage cursor (never resets to Stage 1).
   */
  resume(currentStage?: string): { stage: StageNumber; stageLabel: string } {
    if (currentStage) {
      this.stage = parseStageNumber(currentStage);
    }
    this.paused = false;
    const stageLabel = this.getStageLabel();

    this.flushWaiters();

    studioBus.emit('world:update', {
      patch: {
        paused: false,
        currentStage: stageLabel,
      },
      source: 'pipeline-controller',
    });

    studioBus.emit('bot:progress', {
      botId: 'code',
      status: 'ready',
      progress: this.stage * 20,
      message: `Resumed at Stage ${this.stage} (${PIPELINE_STAGES[this.stage - 1].short})`,
    });

    return { stage: this.stage, stageLabel };
  }

  setStage(stage: StageNumber): string {
    this.stage = stage;
    const stageLabel = this.getStageLabel();

    studioBus.emit('world:update', {
      patch: { currentStage: stageLabel },
      source: 'pipeline-controller',
    });

    studioBus.emit('bot:progress', {
      botId: 'code',
      status: this.paused ? 'paused' : 'ready',
      progress: stage * 20,
      message: this.paused
        ? `Inspecting Stage ${stage} (${PIPELINE_STAGES[stage - 1].short})`
        : `Active on Stage ${stage} (${PIPELINE_STAGES[stage - 1].short})`,
    });

    return stageLabel;
  }

  async advanceStage(
    currentStage?: string,
    signal?: AbortSignal
  ): Promise<{ stage: StageNumber; stageLabel: string; completed: boolean }> {
    if (currentStage) {
      this.stage = parseStageNumber(currentStage);
    }

    // Cooperatively hold if pipeline is paused
    await this.waitIfPaused(signal);

    const nextNum = (this.stage < 5 ? this.stage + 1 : 5) as StageNumber;
    const stageLabel = this.setStage(nextNum);
    return {
      stage: nextNum,
      stageLabel,
      completed: nextNum === 5,
    };
  }
}

export const pipelineController = new StudioPipelineController();

export function syncPipelineFromWorld(currentStage: string, paused: boolean): void {
  pipelineController.syncFromWorld(currentStage, paused);
}

export function waitIfPaused(signal?: AbortSignal): Promise<void> {
  return pipelineController.waitIfPaused(signal);
}

export function pauseStudioPipeline(currentStage?: string): {
  stage: StageNumber;
  stageLabel: string;
} {
  return pipelineController.pause(currentStage);
}

export function resumeStudioPipeline(currentStage?: string): {
  stage: StageNumber;
  stageLabel: string;
} {
  return pipelineController.resume(currentStage);
}

export function setStudioPipelineStage(stage: StageNumber): string {
  return pipelineController.setStage(stage);
}

export function advanceStage(
  currentStage?: string,
  signal?: AbortSignal
): Promise<{ stage: StageNumber; stageLabel: string; completed: boolean }> {
  return pipelineController.advanceStage(currentStage, signal);
}
