import { studioBus } from './eventBus';
import { waitIfPaused } from './pipelineController';
import type { StudioAssetItem, VirtualFile } from '../types/studio';

export interface GeneratePro3DGameOptions {
  title?: string;
  theme?: string;
  selectedAssets: StudioAssetItem[];
  appsSupabaseUrl?: string;
  appsSupabaseAnonKey?: string;
  signal?: AbortSignal;
}

export interface GeneratedPro3DGameResult {
  files: VirtualFile[];
  entryPath: string;
  title: string;
  theme: string;
  injectedAssetsCount: number;
}

interface GameAssetPayload {
  vehicles: { name: string; url: string; format?: string }[];
  characters: { name: string; url: string; format?: string }[];
  villageWorld: { name: string; url: string; format?: string }[];
  hdriSky: { name: string; url: string; previewUrl?: string; format?: string }[];
  texturesPbr: { name: string; url: string; previewUrl?: string }[];
  audioSfx: { name: string; url: string; format?: string }[];
}

function escapeHtmlAttr(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function safeJsonForScript(data: unknown): string {
  return JSON.stringify(data).replace(/</g, '\\u003c').replace(/>/g, '\\u003e');
}

function resolveThemeArchetype(theme: string): 'truck' | 'suv' | 'sports' | 'car' {
  const lower = theme.toLowerCase();
  if (/(truck|lorry|cargo|pickup|tractor|dumper|ट्रक)/.test(lower)) {
    return 'truck';
  }
  if (/(suv|jeep|offroad|off-road|thar|4x4|safari)/.test(lower)) {
    return 'suv';
  }
  if (/(sport|race|racing|supercar|drift|turbo|coupe)/.test(lower)) {
    return 'sports';
  }
  return 'car';
}

function extractGameAssets(selectedAssets: StudioAssetItem[]): GameAssetPayload {
  const pick = (cat: StudioAssetItem['category']) =>
    selectedAssets.filter((a) => a.category === cat && Boolean(a.url));

  return {
    vehicles: pick('vehicles').map((a) => ({
      name: a.name,
      url: a.url,
      format: a.format,
    })),
    characters: pick('characters').map((a) => ({
      name: a.name,
      url: a.url,
      format: a.format,
    })),
    villageWorld: pick('village_world').map((a) => ({
      name: a.name,
      url: a.url,
      format: a.format,
    })),
    hdriSky: pick('hdri_sky').map((a) => ({
      name: a.name,
      url: a.url,
      previewUrl: a.previewUrl,
      format: a.format,
    })),
    texturesPbr: pick('textures_pbr').map((a) => ({
      name: a.name,
      url: a.url,
      previewUrl: a.previewUrl,
    })),
    audioSfx: pick('audio_sfx').map((a) => ({
      name: a.name,
      url: a.url,
      format: a.format,
    })),
  };
}

function buildManifestJson(
  title: string,
  theme: string,
  selectedAssets: StudioAssetItem[],
  appsSupabaseUrl?: string
): string {
  const categories = Array.from(new Set(selectedAssets.map((a) => a.category)));
  const payload = {
    studio: 'Sarfealam Auto-Studio',
    runtime: 'threejs-3d-pro',
    title,
    theme,
    schemaVersion: 1,
    updatedAt: new Date().toISOString(),
    supabaseConfigured: Boolean(appsSupabaseUrl?.trim()),
    count: selectedAssets.length,
    categories:
      categories.length > 0
        ? categories
        : ['vehicles', 'characters', 'village_world', 'hdri_sky', 'audio_sfx'],
    assets: selectedAssets.map((item) => ({
      id: item.id,
      name: item.name,
      category: item.category,
      source: item.source,
      url: item.url,
      ...(item.previewUrl ? { previewUrl: item.previewUrl } : {}),
      ...(item.format ? { format: item.format } : {}),
      ...(item.license ? { license: item.license } : {}),
    })),
  };
  return `${JSON.stringify(payload, null, 2)}\n`;
}

function buildPro3DGameHtml(config: {
  title: string;
  theme: string;
  archetype: 'truck' | 'suv' | 'sports' | 'car';
  assets: GameAssetPayload;
  appsSupabaseUrl?: string;
  appsSupabaseAnonKey?: string;
}): string {
  const runtimeConfig = {
    title: config.title,
    theme: config.theme,
    archetype: config.archetype,
    assets: config.assets,
    supabase: {
      url: config.appsSupabaseUrl?.trim() || '',
      anonKey: config.appsSupabaseAnonKey?.trim() || '',
    },
  };

  const configJson = safeJsonForScript(runtimeConfig);

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover"
    />
    <title>${escapeHtmlAttr(config.title)}</title>
    <style>
      html,
      body.game-3d-root {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        height: 100% !important;
        overflow: hidden !important;
        background: #1a2433 !important;
        color: #f8fafc !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
        touch-action: none !important;
        user-select: none !important;
        -webkit-user-select: none !important;
      }

      #stage-canvas-wrap {
        position: fixed;
        inset: 0;
        width: 100%;
        height: 100%;
        z-index: 1;
        overflow: hidden;
      }

      #stage-canvas-wrap canvas {
        display: block;
        width: 100% !important;
        height: 100% !important;
      }

      /* Top compact status HUD (solid rgba, zero backdrop-filter over WebGL) */
      #hud-top {
        position: fixed;
        top: 6px;
        left: 6px;
        right: 6px;
        z-index: 20;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        pointer-events: none;
      }

      .hud-chip-group {
        display: flex;
        align-items: center;
        gap: 4px;
        pointer-events: auto;
        min-width: 0;
      }

      .hud-pill {
        height: 26px;
        padding: 0 8px;
        border-radius: 999px;
        background: rgba(15, 23, 42, 0.82);
        border: 1px solid rgba(255, 255, 255, 0.18);
        color: #f8fafc;
        font-size: 11px;
        font-weight: 700;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        white-space: nowrap;
        font-variant-numeric: tabular-nums;
      }

      .hud-speed {
        color: #38bdf8;
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 12px;
        font-weight: 800;
      }

      .hud-gear-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 18px;
        height: 18px;
        padding: 0 4px;
        border-radius: 6px;
        background: #10b981;
        color: #052e16;
        font-size: 10.5px;
        font-weight: 900;
      }

      .hud-gear-badge.gear-r {
        background: #ef4444;
        color: #fff;
      }

      .hud-gear-badge.gear-n {
        background: #f59e0b;
        color: #1c1917;
      }

      .hud-btn {
        height: 26px;
        padding: 0 8px;
        border-radius: 999px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        background: rgba(15, 23, 42, 0.84);
        color: #f8fafc;
        font-size: 10px;
        font-weight: 700;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        white-space: nowrap;
        touch-action: manipulation;
      }

      .hud-btn:active {
        transform: scale(0.95);
        background: rgba(30, 41, 59, 0.96);
      }

      .hud-btn.active {
        background: #007aff;
        border-color: #60a5fa;
        color: #ffffff;
      }

      /* Floating transient toast */
      #hud-toast {
        position: fixed;
        top: 38px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 25;
        padding: 4px 11px;
        border-radius: 999px;
        background: rgba(15, 23, 42, 0.88);
        border: 1px solid rgba(56, 189, 248, 0.45);
        color: #e0f2fe;
        font-size: 10.5px;
        font-weight: 700;
        pointer-events: none;
        opacity: 0;
        transition: opacity 0.22s ease;
        white-space: nowrap;
        max-width: calc(100vw - 24px);
        overflow: hidden;
        text-overflow: ellipsis;
      }

      #hud-toast.show {
        opacity: 1;
      }

      /* Bottom unified touch control dock (zero center occlusion) */
      #hud-controls {
        position: fixed;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 20;
        padding: 6px 8px 8px;
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        gap: 6px;
        pointer-events: none;
        transition: transform 0.24s ease, opacity 0.24s ease;
      }

      #hud-controls.hidden-hud {
        transform: translateY(115%);
        opacity: 0;
      }

      /* Left: Rotating Touch Steering Wheel */
      .steer-zone {
        pointer-events: auto;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 3px;
        flex-shrink: 0;
      }

      #steering-wheel {
        width: 84px;
        height: 84px;
        border-radius: 50%;
        background: rgba(15, 23, 42, 0.72);
        border: 2px solid rgba(255, 255, 255, 0.22);
        box-shadow: 0 6px 18px rgba(0, 0, 0, 0.4);
        display: flex;
        align-items: center;
        justify-content: center;
        touch-action: none;
        cursor: grab;
        position: relative;
      }

      #steering-wheel:active {
        cursor: grabbing;
        border-color: rgba(56, 189, 248, 0.75);
      }

      #steering-wheel-rotator {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        will-change: transform;
      }

      #steering-wheel svg {
        width: 92%;
        height: 92%;
        display: block;
        pointer-events: none;
      }

      /* Center: R / N / 1 / 2 / 3 Gearbox + Action Buttons */
      .center-dock {
        pointer-events: auto;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 5px;
        min-width: 0;
      }

      .action-row {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
      }

      .action-btn {
        height: 26px;
        padding: 0 9px;
        border-radius: 9px;
        border: 1px solid rgba(255, 255, 255, 0.22);
        background: rgba(15, 23, 42, 0.86);
        color: #f8fafc;
        font-size: 10px;
        font-weight: 800;
        cursor: pointer;
        white-space: nowrap;
        touch-action: manipulation;
      }

      .action-btn:active {
        transform: scale(0.95);
      }

      .action-btn.gate-open {
        background: #059669;
        border-color: #34d399;
        color: #ffffff;
      }

      .action-btn.walk-mode {
        background: #6366f1;
        border-color: #a5b4fc;
        color: #ffffff;
      }

      .gearbox {
        display: flex;
        align-items: center;
        gap: 3px;
        padding: 3px;
        border-radius: 11px;
        background: rgba(15, 23, 42, 0.86);
        border: 1px solid rgba(255, 255, 255, 0.18);
      }

      .gear-btn {
        width: 24px;
        height: 26px;
        border-radius: 7px;
        border: 1px solid rgba(255, 255, 255, 0.12);
        background: rgba(30, 41, 59, 0.9);
        color: #cbd5e1;
        font-size: 10.5px;
        font-weight: 800;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0;
        touch-action: manipulation;
      }

      .gear-btn.active-r {
        background: #ef4444;
        border-color: #fca5a5;
        color: #fff;
      }

      .gear-btn.active-n {
        background: #f59e0b;
        border-color: #fde68a;
        color: #1c1917;
      }

      .gear-btn.active-1 {
        background: #10b981;
        border-color: #6ee7b7;
        color: #052e16;
      }

      .gear-btn.active-2 {
        background: #0ea5e9;
        border-color: #7dd3fc;
        color: #082f49;
      }

      .gear-btn.active-3 {
        background: #6366f1;
        border-color: #a5b4fc;
        color: #ffffff;
      }

      /* Right: Brake & Gas Pedals */
      .pedal-zone {
        pointer-events: auto;
        display: flex;
        align-items: flex-end;
        gap: 6px;
        flex-shrink: 0;
      }

      .pedal {
        border-radius: 12px;
        border: 1.5px solid rgba(255, 255, 255, 0.24);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 3px;
        font-weight: 900;
        letter-spacing: 0.04em;
        cursor: pointer;
        touch-action: none;
        box-shadow: 0 5px 14px rgba(0, 0, 0, 0.36);
        transition: transform 0.08s ease;
      }

      .pedal-brake {
        width: 46px;
        height: 52px;
        background: linear-gradient(180deg, rgba(220, 38, 38, 0.88), rgba(153, 27, 27, 0.94));
        color: #fee2e2;
        font-size: 9.5px;
      }

      .pedal-gas {
        width: 48px;
        height: 68px;
        background: linear-gradient(180deg, rgba(16, 185, 129, 0.9), rgba(4, 120, 87, 0.95));
        color: #ecfdf5;
        font-size: 10px;
      }

      .pedal.pressed {
        transform: scale(0.92) translateY(2px);
        filter: brightness(1.16);
      }

      .pedal-tread {
        width: 62%;
        height: 3px;
        border-radius: 2px;
        background: rgba(255, 255, 255, 0.35);
      }

      /* Ultra-compact fit for inline 310x176 Display A preview iframe */
      @media (max-height: 240px), (max-width: 345px) {
        #hud-top {
          top: 4px;
          left: 4px;
          right: 4px;
        }
        .hud-pill,
        .hud-btn {
          height: 22px;
          padding: 0 6px;
          font-size: 9.5px;
        }
        .hud-speed {
          font-size: 10.5px;
        }
        #hud-controls {
          padding: 4px 5px 5px;
          gap: 4px;
        }
        #steering-wheel {
          width: 60px;
          height: 60px;
        }
        .action-btn {
          height: 22px;
          padding: 0 6px;
          font-size: 9px;
          border-radius: 7px;
        }
        .gearbox {
          padding: 2px;
          gap: 2px;
        }
        .gear-btn {
          width: 21px;
          height: 22px;
          font-size: 9.5px;
        }
        .pedal-brake {
          width: 38px;
          height: 40px;
          font-size: 8px;
          border-radius: 9px;
        }
        .pedal-gas {
          width: 40px;
          height: 50px;
          font-size: 8.5px;
          border-radius: 9px;
        }
        .hide-on-mini {
          display: none !important;
        }
      }
    </style>
    <script type="importmap">
      {
        "imports": {
          "three": "https://esm.sh/three@0.170.0",
          "three/addons/": "https://esm.sh/three@0.170.0/examples/jsm/"
        }
      }
    </script>
  </head>
  <body class="game-3d-root">
    <div id="stage-canvas-wrap"></div>

    <!-- Top Compact HUD -->
    <div id="hud-top">
      <div class="hud-chip-group">
        <div class="hud-pill">
          <span class="hud-speed" id="hud-speed">0 km/h</span>
          <span class="hud-gear-badge" id="hud-gear-badge">1</span>
          <span id="hud-mode-label">DRIVE</span>
        </div>
      </div>
      <div class="hud-chip-group">
        <button type="button" class="hud-btn" id="btn-horn" title="Horn (H)">HORN</button>
        <button type="button" class="hud-btn" id="btn-cam" title="Camera View (C)">CAM</button>
        <button type="button" class="hud-btn active hide-on-mini" id="btn-sfx" title="Toggle Audio">SFX</button>
        <button type="button" class="hud-btn" id="btn-hud-toggle" title="Toggle Controls (U)">HUD</button>
      </div>
    </div>

    <div id="hud-toast"></div>

    <!-- Bottom Touch Controls -->
    <div id="hud-controls">
      <!-- Bottom-Left: Rotating Touch Steering Wheel -->
      <div class="steer-zone">
        <div id="steering-wheel" aria-label="Touch Steering Wheel">
          <div id="steering-wheel-rotator">
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="50" cy="50" r="42" stroke="#1e293b" stroke-width="11" />
              <circle cx="50" cy="50" r="42" stroke="#94a3b8" stroke-width="2.5" />
              <rect x="46.5" y="4" width="7" height="10" rx="2.5" fill="#ef4444" />
              <line x1="50" y1="50" x2="14" y2="56" stroke="#cbd5e1" stroke-width="7" stroke-linecap="round" />
              <line x1="50" y1="50" x2="86" y2="56" stroke="#cbd5e1" stroke-width="7" stroke-linecap="round" />
              <line x1="50" y1="50" x2="50" y2="88" stroke="#cbd5e1" stroke-width="7" stroke-linecap="round" />
              <circle cx="50" cy="50" r="14" fill="#0f172a" stroke="#38bdf8" stroke-width="2.5" />
              <circle cx="50" cy="50" r="4.5" fill="#38bdf8" />
            </svg>
          </div>
        </div>
      </div>

      <!-- Bottom-Center: Gate + Enter/Exit + R/N/1/2/3 Gearbox -->
      <div class="center-dock">
        <div class="action-row">
          <button type="button" class="action-btn" id="btn-gate">Gate</button>
          <button type="button" class="action-btn" id="btn-enter-exit">Exit Car</button>
        </div>
        <div class="gearbox" role="group" aria-label="Gearbox">
          <button type="button" class="gear-btn" data-gear="R">R</button>
          <button type="button" class="gear-btn" data-gear="N">N</button>
          <button type="button" class="gear-btn active-1" data-gear="1">1</button>
          <button type="button" class="gear-btn" data-gear="2">2</button>
          <button type="button" class="gear-btn" data-gear="3">3</button>
        </div>
      </div>

      <!-- Bottom-Right: Brake & Gas Pedals -->
      <div class="pedal-zone">
        <button type="button" class="pedal pedal-brake" id="pedal-brake" aria-label="Brake Pedal">
          <span class="pedal-tread"></span>
          <span class="pedal-tread"></span>
          <span>BRK</span>
        </button>
        <button type="button" class="pedal pedal-gas" id="pedal-gas" aria-label="Gas Pedal">
          <span class="pedal-tread"></span>
          <span class="pedal-tread"></span>
          <span class="pedal-tread"></span>
          <span>GAS</span>
        </button>
      </div>
    </div>

    <script id="studio-game-config" type="application/json">${configJson}</script>
    <script type="module">
      import * as THREE from 'three';
      import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
      import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
      import { RGBELoader } from 'three/addons/loaders/RGBELoader.js';
      import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

      const CONFIG = JSON.parse(document.getElementById('studio-game-config').textContent);
      window.__STUDIO_APP_CONFIG__ = CONFIG;

      // ------------------------------------------------------------------
      // 1. Software WebGL Guard + Renderer Setup
      // ------------------------------------------------------------------
      const isSoftwareGl = (() => {
        try {
          const probe = document.createElement('canvas');
          const gl = probe.getContext('webgl2') || probe.getContext('webgl');
          if (!gl) return true;
          const ext = gl.getExtension('WEBGL_debug_renderer_info');
          const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
          const gpu = String(gl.getParameter(param) || '');
          gl.getExtension('WEBGL_lose_context')?.loseContext();
          return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
        } catch {
          return false;
        }
      })();

      const mountEl = document.getElementById('stage-canvas-wrap');
      const renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.08;
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2));
      renderer.setSize(window.innerWidth, window.innerHeight);
      renderer.shadowMap.enabled = !isSoftwareGl;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      mountEl.appendChild(renderer.domElement);

      const scene = new THREE.Scene();
      const skyHex =
        CONFIG.archetype === 'sports'
          ? 0xdce8f8
          : CONFIG.archetype === 'truck'
            ? 0xdcebf7
            : 0xcbe3fa;
      scene.background = new THREE.Color(skyHex);
      scene.fog = new THREE.Fog(skyHex, 58, 178);

      const camera = new THREE.PerspectiveCamera(
        58,
        Math.max(1, window.innerWidth) / Math.max(1, window.innerHeight),
        0.2,
        280
      );

      // Mandatory Studio IBL (RoomEnvironment) so metallic paint & chrome shine
      const pmremGenerator = new THREE.PMREMGenerator(renderer);
      scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;

      // Balanced Outdoor Daylight Lighting (Warm Sun Key + Cool Sky/Ground Fill)
      const hemiLight = new THREE.HemisphereLight(0xdbeeff, 0x5c6b4d, 0.82);
      hemiLight.position.set(0, 60, 0);
      scene.add(hemiLight);

      const sunLight = new THREE.DirectionalLight(0xfff1d6, 2.0);
      sunLight.position.set(28, 42, 22);
      sunLight.castShadow = !isSoftwareGl;
      sunLight.shadow.mapSize.width = 1024;
      sunLight.shadow.mapSize.height = 1024;
      sunLight.shadow.camera.near = 2;
      sunLight.shadow.camera.far = 130;
      const sd = 34;
      sunLight.shadow.camera.left = -sd;
      sunLight.shadow.camera.right = sd;
      sunLight.shadow.camera.top = sd;
      sunLight.shadow.camera.bottom = -sd;
      sunLight.shadow.bias = -0.0005;
      sunLight.shadow.normalBias = 0.025;
      scene.add(sunLight);
      scene.add(sunLight.target);

      const rimLight = new THREE.DirectionalLight(0x93c5fd, 0.45);
      rimLight.position.set(-24, 16, -28);
      scene.add(rimLight);

      // ------------------------------------------------------------------
      // 2. Procedural Canvas Textures (Zero-404 Guaranteed)
      // ------------------------------------------------------------------
      const maxAniso = renderer.capabilities.getMaxAnisotropy();

      function createRoadTexture() {
        const c = document.createElement('canvas');
        c.width = 256;
        c.height = 256;
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#334155';
        ctx.fillRect(0, 0, 256, 256);
        for (let i = 0; i < 1800; i++) {
          const x = (i * 53) % 256;
          const y = (i * 97) % 256;
          ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.045)' : 'rgba(0,0,0,0.08)';
          ctx.fillRect(x, y, 2, 2);
        }
        // Edge shoulders
        ctx.fillStyle = '#e2e8f0';
        ctx.fillRect(10, 0, 5, 256);
        ctx.fillRect(241, 0, 5, 256);
        // Dashed center line
        ctx.fillStyle = '#fbbf24';
        ctx.fillRect(125, 16, 6, 92);
        ctx.fillRect(125, 148, 6, 92);

        const tex = new THREE.CanvasTexture(c);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.anisotropy = maxAniso;
        return tex;
      }

      function createGroundTexture() {
        const c = document.createElement('canvas');
        c.width = 256;
        c.height = 256;
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#5c8a47';
        ctx.fillRect(0, 0, 256, 256);
        for (let i = 0; i < 600; i++) {
          const x = (i * 73) % 256;
          const y = (i * 41) % 256;
          ctx.fillStyle = i % 3 === 0 ? '#689b51' : i % 3 === 1 ? '#4f7a3c' : '#6c904b';
          ctx.fillRect(x, y, 10, 10);
        }
        const tex = new THREE.CanvasTexture(c);
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        tex.repeat.set(28, 28);
        tex.anisotropy = maxAniso;
        return tex;
      }

      function createContactShadowTexture() {
        const c = document.createElement('canvas');
        c.width = 128;
        c.height = 128;
        const ctx = c.getContext('2d');
        const g = ctx.createRadialGradient(64, 64, 8, 64, 64, 60);
        g.addColorStop(0, 'rgba(15,23,42,0.58)');
        g.addColorStop(0.55, 'rgba(15,23,42,0.24)');
        g.addColorStop(1, 'rgba(15,23,42,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, 128, 128);
        const tex = new THREE.CanvasTexture(c);
        return tex;
      }

      const roadTex = createRoadTexture();
      const groundTex = createGroundTexture();
      const contactShadowTex = createContactShadowTexture();

      // ------------------------------------------------------------------
      // 3. Village World, Road Network, Perimeter Hills & Compound Gate
      // ------------------------------------------------------------------
      const groundMat = new THREE.MeshStandardMaterial({
        map: groundTex,
        roughness: 0.92,
        metalness: 0.0,
      });
      const ground = new THREE.Mesh(new THREE.PlaneGeometry(340, 340), groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);

      // Village Courtyard Cobble Pad
      const courtyardMat = new THREE.MeshStandardMaterial({
        color: 0xd6cfc2,
        roughness: 0.88,
        metalness: 0.02,
      });
      const courtyard = new THREE.Mesh(new THREE.BoxGeometry(26, 0.06, 24), courtyardMat);
      courtyard.position.set(0, 0.01, 2);
      courtyard.receiveShadow = true;
      scene.add(courtyard);

      // Road Segments (Outer Loop + Courtyard Entrance Road)
      function addRoadStrip(x, z, w, l, rotY = 0) {
        const t = roadTex.clone();
        t.needsUpdate = true;
        t.repeat.set(1, Math.max(1, l / 10));
        const mat = new THREE.MeshStandardMaterial({
          map: t,
          roughness: 0.82,
          metalness: 0.05,
        });
        const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, l), mat);
        mesh.rotation.x = -Math.PI / 2;
        mesh.rotation.z = rotY;
        mesh.position.set(x, 0.03, z);
        mesh.receiveShadow = true;
        scene.add(mesh);
      }

      // Outer loop rectangle (X = +-36, Z = +-36)
      addRoadStrip(0, -36, 9, 81, Math.PI / 2);
      addRoadStrip(0, 36, 9, 81, Math.PI / 2);
      addRoadStrip(-36, 0, 9, 72, 0);
      addRoadStrip(36, 0, 9, 72, 0);
      // Central driveway connecting courtyard through compound gate to north loop
      addRoadStrip(0, -22, 6.8, 28, 0);

      // Natural Horizon Perimeter Hills (no indoor box wall!)
      const hillMat = new THREE.MeshStandardMaterial({
        color: 0x4e7c44,
        roughness: 0.94,
        metalness: 0.0,
      });
      for (let i = 0; i < 18; i++) {
        const ang = (i / 18) * Math.PI * 2;
        const dist = 96 + (i % 3) * 18;
        const r = 18 + (i % 4) * 7;
        const hill = new THREE.Mesh(
          new THREE.ConeGeometry(r, 12 + (i % 3) * 5, 7),
          hillMat
        );
        hill.position.set(Math.cos(ang) * dist, 5.5, Math.sin(ang) * dist);
        hill.scale.set(1.4, 0.65, 1.2);
        scene.add(hill);
      }

      // Instanced Stylized Trees (multi-tier foliage + varied tint/scale)
      const treeCoords = [
        [-22, -24], [-15, -24], [15, -24], [22, -24],
        [-26, -6], [-26, 8], [-26, 20], [26, -6], [26, 8], [26, 20],
        [-18, 24], [-6, 24], [8, 24], [19, 24],
        [-48, -44], [-48, -20], [-48, 4], [-48, 26], [-48, 46],
        [48, -44], [48, -18], [48, 6], [48, 28], [48, 46],
        [-24, -48], [0, -48], [24, -48], [-22, 48], [4, 48], [26, 48],
      ];
      const trunkGeo = new THREE.CylinderGeometry(0.24, 0.36, 2.4, 7);
      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x6b4423, roughness: 0.92 });
      const canopyGeo = new THREE.ConeGeometry(2.0, 4.4, 8);
      const canopyMat = new THREE.MeshStandardMaterial({ color: 0x2f7d32, roughness: 0.85 });

      const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCoords.length);
      const canopyInst = new THREE.InstancedMesh(canopyGeo, canopyMat, treeCoords.length);
      trunkInst.castShadow = !isSoftwareGl;
      canopyInst.castShadow = !isSoftwareGl;
      canopyInst.receiveShadow = true;

      const _dummy = new THREE.Object3D();
      const _tint = new THREE.Color();
      treeCoords.forEach(([tx, tz], i) => {
        const s = 0.85 + ((i * 37) % 30) / 100;
        _dummy.position.set(tx, 1.2 * s, tz);
        _dummy.rotation.set(0, (i * 1.1) % 6.28, 0);
        _dummy.scale.set(s, s, s);
        _dummy.updateMatrix();
        trunkInst.setMatrixAt(i, _dummy.matrix);

        _dummy.position.set(tx, 3.8 * s, tz);
        _dummy.scale.set(s, s * 1.05, s);
        _dummy.updateMatrix();
        canopyInst.setMatrixAt(i, _dummy.matrix);

        _tint.setHSL(0.3 + ((i % 5) - 2) * 0.015, 0.48, 0.33 + (i % 3) * 0.04);
        canopyInst.setColorAt(i, _tint);
      });
      trunkInst.instanceMatrix.needsUpdate = true;
      canopyInst.instanceMatrix.needsUpdate = true;
      if (canopyInst.instanceColor) canopyInst.instanceColor.needsUpdate = true;
      trunkInst.computeBoundingSphere();
      canopyInst.computeBoundingSphere();
      scene.add(trunkInst, canopyInst);

      // Composite Village Buildings (5-8 distinct parts each, grounded at y=0)
      const colliders = [];

      function buildVillageHouse(x, z, rotY, wallHex, roofHex, width = 7.4, depth = 5.8) {
        const g = new THREE.Group();
        g.position.set(x, 0, z);
        g.rotation.y = rotY;

        const base = new THREE.Mesh(
          new THREE.BoxGeometry(width + 0.5, 0.45, depth + 0.5),
          new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.9 })
        );
        base.position.y = 0.225;
        base.receiveShadow = true;
        g.add(base);

        const wall = new THREE.Mesh(
          new THREE.BoxGeometry(width, 3.3, depth),
          new THREE.MeshStandardMaterial({ color: wallHex, roughness: 0.86 })
        );
        wall.position.y = 2.1;
        wall.castShadow = !isSoftwareGl;
        wall.receiveShadow = true;
        g.add(wall);

        const roof = new THREE.Mesh(
          new THREE.ConeGeometry(Math.max(width, depth) * 0.78, 2.3, 4),
          new THREE.MeshStandardMaterial({ color: roofHex, roughness: 0.76, metalness: 0.08 })
        );
        roof.position.y = 4.9;
        roof.rotation.y = Math.PI / 4;
        roof.castShadow = !isSoftwareGl;
        g.add(roof);

        const door = new THREE.Mesh(
          new THREE.BoxGeometry(1.3, 2.15, 0.16),
          new THREE.MeshStandardMaterial({ color: 0x5b3a29, roughness: 0.78 })
        );
        door.position.set(0, 1.52, depth / 2 + 0.04);
        g.add(door);

        const winMat = new THREE.MeshStandardMaterial({
          color: 0xfef3c7,
          emissive: 0xf59e0b,
          emissiveIntensity: 0.28,
          roughness: 0.2,
          metalness: 0.2,
        });
        for (const sx of [-width * 0.3, width * 0.3]) {
          const win = new THREE.Mesh(new THREE.BoxGeometry(1.15, 1.0, 0.14), winMat);
          win.position.set(sx, 2.25, depth / 2 + 0.04);
          g.add(win);
        }

        const awning = new THREE.Mesh(
          new THREE.BoxGeometry(2.6, 0.14, 1.25),
          new THREE.MeshStandardMaterial({ color: roofHex, roughness: 0.65 })
        );
        awning.position.set(0, 2.75, depth / 2 + 0.55);
        awning.rotation.x = 0.22;
        g.add(awning);

        scene.add(g);
        colliders.push({ x, z, r: Math.max(width, depth) * 0.54 });
        return g;
      }

      buildVillageHouse(-18, 2, Math.PI / 2, 0xfef3c7, 0xb45309, 7.6, 5.8);
      buildVillageHouse(18, 2, -Math.PI / 2, 0xe0f2fe, 0x1d4ed8, 7.6, 5.8);
      buildVillageHouse(-16, 16, 0, 0xfce7f3, 0x9f1239, 6.8, 5.4);
      buildVillageHouse(16, 16, 0, 0xdcfce7, 0x15803d, 7.0, 5.4);
      buildVillageHouse(0, 20, Math.PI, 0xf1f5f9, 0x475569, 9.2, 5.8);
      buildVillageHouse(-20, -18, Math.PI / 4, 0xffedd5, 0xc2410c, 6.6, 5.2);
      buildVillageHouse(20, -18, -Math.PI / 4, 0xede9fe, 0x5b21b6, 6.6, 5.2);

      // Animated Compound Gate at (0, 0, -11.5)
      const gateState = { open: false, angle: 0, targetAngle: 0 };
      const gateGroup = new THREE.Group();
      gateGroup.position.set(0, 0, -11.5);
      scene.add(gateGroup);

      const pillarMat = new THREE.MeshStandardMaterial({ color: 0xd6d3d1, roughness: 0.88 });
      const ironMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.35, metalness: 0.78 });
      const goldTrimMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.25, metalness: 0.85 });

      for (const sx of [-4.2, 4.2]) {
        const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.95, 3.8, 0.95), pillarMat);
        pillar.position.set(sx, 1.9, 0);
        pillar.castShadow = !isSoftwareGl;
        pillar.receiveShadow = true;
        gateGroup.add(pillar);

        const cap = new THREE.Mesh(new THREE.BoxGeometry(1.18, 0.26, 1.18), ironMat);
        cap.position.set(sx, 3.92, 0);
        gateGroup.add(cap);

        const lamp = new THREE.Mesh(
          new THREE.SphereGeometry(0.24, 10, 10),
          new THREE.MeshStandardMaterial({
            color: 0xfef08a,
            emissive: 0xf59e0b,
            emissiveIntensity: 0.7,
            roughness: 0.2,
          })
        );
        lamp.position.set(sx, 4.24, 0);
        gateGroup.add(lamp);

        // Side compound boundary fence flanking gate
        const fence = new THREE.Mesh(new THREE.BoxGeometry(8.5, 1.6, 0.28), pillarMat);
        fence.position.set(sx + (sx < 0 ? -4.7 : 4.7), 0.8, 0);
        gateGroup.add(fence);
      }

      // Overhead Gate Arch Beam
      const archBeam = new THREE.Mesh(new THREE.BoxGeometry(9.4, 0.32, 0.42), ironMat);
      archBeam.position.set(0, 3.7, 0);
      gateGroup.add(archBeam);

      function buildGateLeaf(dir) {
        const pivot = new THREE.Group();
        pivot.position.set(dir * 3.72, 0, 0);

        const frameTop = new THREE.Mesh(new THREE.BoxGeometry(3.65, 0.14, 0.14), ironMat);
        frameTop.position.set(-dir * 1.82, 2.3, 0);
        pivot.add(frameTop);

        const frameBot = new THREE.Mesh(new THREE.BoxGeometry(3.65, 0.16, 0.14), ironMat);
        frameBot.position.set(-dir * 1.82, 0.26, 0);
        pivot.add(frameBot);

        for (let b = 0; b < 7; b++) {
          const bar = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 2.1, 6), ironMat);
          bar.position.set(-dir * (0.28 + b * 0.52), 1.28, 0);
          pivot.add(bar);

          const tip = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.22, 6), goldTrimMat);
          tip.position.set(-dir * (0.28 + b * 0.52), 2.48, 0);
          pivot.add(tip);
        }

        const plate = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.52, 0.08), goldTrimMat);
        plate.position.set(-dir * 1.82, 0.88, 0);
        pivot.add(plate);

        gateGroup.add(pivot);
        return pivot;
      }

      const gateLeftPivot = buildGateLeaf(-1);
      const gateRightPivot = buildGateLeaf(1);

      // ------------------------------------------------------------------
      // 4. Composite Procedural Player Vehicle (Truck / SUV / Sports / Car)
      // ------------------------------------------------------------------
      const vehicleRoot = new THREE.Group();
      vehicleRoot.position.set(0, 0, 2);
      scene.add(vehicleRoot);

      const proceduralVehicleGroup = new THREE.Group();
      vehicleRoot.add(proceduralVehicleGroup);

      const wheelPivots = [];
      const wheelSpinMeshes = [];
      let brakeLightMat = null;
      let reverseLightMat = null;

      function buildProceduralVehicle(archetype) {
        const paintHex =
          archetype === 'truck'
            ? 0xea580c
            : archetype === 'suv'
              ? 0x059669
              : archetype === 'sports'
                ? 0xdc2626
                : 0x0284c7;

        const paintMat = new THREE.MeshPhysicalMaterial({
          color: paintHex,
          metalness: 0.45,
          roughness: 0.24,
          clearcoat: 1.0,
          clearcoatRoughness: 0.12,
        });
        const trimMat = new THREE.MeshStandardMaterial({
          color: 0x1e293b,
          roughness: 0.65,
          metalness: 0.25,
        });
        const chromeMat = new THREE.MeshStandardMaterial({
          color: 0xe2e8f0,
          roughness: 0.16,
          metalness: 0.92,
        });
        const glassMat = new THREE.MeshPhysicalMaterial({
          color: 0x0f172a,
          roughness: 0.08,
          metalness: 0.1,
          transparent: true,
          opacity: 0.78,
        });
        const headLightMat = new THREE.MeshStandardMaterial({
          color: 0xfef9c3,
          emissive: 0xfef08a,
          emissiveIntensity: 1.4,
          roughness: 0.15,
        });
        brakeLightMat = new THREE.MeshStandardMaterial({
          color: 0x991b1b,
          emissive: 0xef4444,
          emissiveIntensity: 0.35,
          roughness: 0.2,
        });
        reverseLightMat = new THREE.MeshStandardMaterial({
          color: 0xe2e8f0,
          emissive: 0xffffff,
          emissiveIntensity: 0.05,
          roughness: 0.2,
        });

        const isTruck = archetype === 'truck';
        const isSports = archetype === 'sports';
        const bodyLen = isTruck ? 5.2 : isSports ? 4.35 : 4.45;
        const bodyW = isTruck ? 2.15 : 1.98;
        const chassisY = isTruck ? 0.85 : isSports ? 0.56 : 0.72;

        // Primary chassis body
        const lowerBody = new THREE.Mesh(
          new THREE.BoxGeometry(bodyW, isTruck ? 0.72 : 0.64, bodyLen),
          paintMat
        );
        lowerBody.position.set(0, chassisY, 0);
        lowerBody.castShadow = !isSoftwareGl;
        lowerBody.receiveShadow = true;
        proceduralVehicleGroup.add(lowerBody);

        // Cabin or Cargo Truck Cab + Wooden Bed
        if (isTruck) {
          const cab = new THREE.Mesh(new THREE.BoxGeometry(2.04, 1.25, 1.95), paintMat);
          cab.position.set(0, 1.72, -1.32);
          cab.castShadow = !isSoftwareGl;
          proceduralVehicleGroup.add(cab);

          const wind = new THREE.Mesh(new THREE.BoxGeometry(1.88, 0.72, 0.14), glassMat);
          wind.position.set(0, 1.82, -2.28);
          wind.rotation.x = -0.14;
          proceduralVehicleGroup.add(wind);

          const bedMat = new THREE.MeshStandardMaterial({ color: 0x0f766e, roughness: 0.68, metalness: 0.18 });
          const cargoBed = new THREE.Mesh(new THREE.BoxGeometry(2.12, 1.02, 2.85), bedMat);
          cargoBed.position.set(0, 1.62, 1.15);
          cargoBed.castShadow = !isSoftwareGl;
          proceduralVehicleGroup.add(cargoBed);

          // Twin chrome exhaust stacks
          for (const sx of [-1.06, 1.06]) {
            const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.55, 8), chromeMat);
            stack.position.set(sx, 1.85, -0.35);
            proceduralVehicleGroup.add(stack);
          }
        } else {
          const cabLen = isSports ? 1.95 : 2.35;
          const cabH = isSports ? 0.56 : 0.78;
          const cab = new THREE.Mesh(new THREE.BoxGeometry(bodyW - 0.22, cabH, cabLen), paintMat);
          cab.position.set(0, chassisY + (isSports ? 0.54 : 0.66), 0.18);
          cab.castShadow = !isSoftwareGl;
          proceduralVehicleGroup.add(cab);

          const glassBand = new THREE.Mesh(
            new THREE.BoxGeometry(bodyW - 0.16, cabH - 0.14, cabLen - 0.18),
            glassMat
          );
          glassBand.position.set(0, chassisY + (isSports ? 0.54 : 0.66), 0.18);
          proceduralVehicleGroup.add(glassBand);

          if (isSports) {
            const spoiler = new THREE.Mesh(new THREE.BoxGeometry(1.88, 0.09, 0.34), trimMat);
            spoiler.position.set(0, chassisY + 0.58, bodyLen * 0.45);
            proceduralVehicleGroup.add(spoiler);
          } else {
            for (const sx of [-0.68, 0.68]) {
              const rail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 1.85), chromeMat);
              rail.position.set(sx, chassisY + 1.1, 0.2);
              proceduralVehicleGroup.add(rail);
            }
          }
        }

        // Front & Rear Chrome Bumpers + Grille
        const frontBumper = new THREE.Mesh(new THREE.BoxGeometry(bodyW + 0.08, 0.26, 0.24), chromeMat);
        frontBumper.position.set(0, chassisY - 0.18, -bodyLen / 2 - 0.04);
        proceduralVehicleGroup.add(frontBumper);

        const rearBumper = new THREE.Mesh(new THREE.BoxGeometry(bodyW + 0.08, 0.24, 0.22), trimMat);
        rearBumper.position.set(0, chassisY - 0.18, bodyLen / 2 + 0.03);
        proceduralVehicleGroup.add(rearBumper);

        const grille = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.32, 0.1), chromeMat);
        grille.position.set(0, chassisY + 0.02, -bodyLen / 2 - 0.01);
        proceduralVehicleGroup.add(grille);

        // Headlights, Brake Lights, Reverse Lights
        for (const sx of [-0.68, 0.68]) {
          const hl = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.2, 0.12), headLightMat);
          hl.position.set(sx, chassisY + 0.08, -bodyLen / 2 - 0.02);
          proceduralVehicleGroup.add(hl);

          const bl = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.18, 0.12), brakeLightMat);
          bl.position.set(sx, chassisY + 0.1, bodyLen / 2 + 0.02);
          proceduralVehicleGroup.add(bl);

          const rl = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.14, 0.12), reverseLightMat);
          rl.position.set(sx * 0.56, chassisY + 0.06, bodyLen / 2 + 0.02);
          proceduralVehicleGroup.add(rl);
        }

        // 4 Wheel Assemblies (front steerable, all spinning)
        const wheelR = isTruck ? 0.48 : 0.4;
        const tireMat = new THREE.MeshStandardMaterial({ color: 0x171717, roughness: 0.88, metalness: 0.04 });
        const rimMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, roughness: 0.22, metalness: 0.88 });
        const axleZ = isTruck ? [-1.62, 1.56] : [-1.36, 1.36];
        const trackX = bodyW / 2 + 0.02;

        axleZ.forEach((wz, axleIdx) => {
          [-trackX, trackX].forEach((wx) => {
            const steerPivot = new THREE.Group();
            steerPivot.position.set(wx, wheelR, wz);

            const spinGroup = new THREE.Group();
            const tire = new THREE.Mesh(
              new THREE.CylinderGeometry(wheelR, wheelR, 0.32, 16),
              tireMat
            );
            tire.rotation.z = Math.PI / 2;
            tire.castShadow = !isSoftwareGl;
            spinGroup.add(tire);

            const rim = new THREE.Mesh(
              new THREE.CylinderGeometry(wheelR * 0.58, wheelR * 0.58, 0.34, 10),
              rimMat
            );
            rim.rotation.z = Math.PI / 2;
            spinGroup.add(rim);

            const spoke = new THREE.Mesh(
              new THREE.BoxGeometry(0.35, wheelR * 0.96, 0.1),
              trimMat
            );
            spinGroup.add(spoke);

            steerPivot.add(spinGroup);
            proceduralVehicleGroup.add(steerPivot);
            if (axleIdx === 0) wheelPivots.push(steerPivot);
            wheelSpinMeshes.push(spinGroup);
          });
        });

        // Soft Contact Shadow Plane beneath vehicle
        const cShadow = new THREE.Mesh(
          new THREE.PlaneGeometry(bodyW + 1.1, bodyLen + 1.2),
          new THREE.MeshBasicMaterial({
            map: contactShadowTex,
            transparent: true,
            depthWrite: false,
            opacity: 0.52,
          })
        );
        cShadow.rotation.x = -Math.PI / 2;
        cShadow.position.y = 0.045;
        vehicleRoot.add(cShadow);
      }

      buildProceduralVehicle(CONFIG.archetype);

      // ------------------------------------------------------------------
      // 5. Composite Articulated 3rd-Person Driver Character (Enter/Exit)
      // ------------------------------------------------------------------
      function createCompositeCharacter(shirtHex, pantsHex, capHex) {
        const root = new THREE.Group();
        const body = new THREE.Group();
        root.add(body);

        const skinMat = new THREE.MeshStandardMaterial({ color: 0xf1c27d, roughness: 0.72 });
        const shirtMat = new THREE.MeshStandardMaterial({ color: shirtHex, roughness: 0.75 });
        const pantsMat = new THREE.MeshStandardMaterial({ color: pantsHex, roughness: 0.85 });
        const capMat = new THREE.MeshStandardMaterial({ color: capHex, roughness: 0.62 });
        const shoeMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.7 });

        const torso = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.62, 0.28), shirtMat);
        torso.position.y = 1.06;
        torso.castShadow = !isSoftwareGl;
        body.add(torso);

        const pack = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.44, 0.16), capMat);
        pack.position.set(0, 1.08, 0.2);
        body.add(pack);

        const head = new THREE.Mesh(new THREE.SphereGeometry(0.21, 12, 12), skinMat);
        head.position.y = 1.56;
        head.castShadow = !isSoftwareGl;
        body.add(head);

        const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.11, 12), capMat);
        cap.position.y = 1.69;
        body.add(cap);

        const brim = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.04, 0.18), capMat);
        brim.position.set(0, 1.65, -0.18);
        body.add(brim);

        function makeLimb(x, y, w, h, mat, shoe = false) {
          const p = new THREE.Group();
          p.position.set(x, y, 0);
          const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, w), mat);
          m.position.y = -h / 2;
          m.castShadow = !isSoftwareGl;
          p.add(m);
          if (shoe) {
            const s = new THREE.Mesh(new THREE.BoxGeometry(w + 0.03, 0.11, w + 0.1), shoeMat);
            s.position.set(0, -h + 0.04, -0.04);
            p.add(s);
          }
          body.add(p);
          return p;
        }

        const leftLeg = makeLimb(-0.14, 0.74, 0.17, 0.72, pantsMat, true);
        const rightLeg = makeLimb(0.14, 0.74, 0.17, 0.72, pantsMat, true);
        const leftArm = makeLimb(-0.35, 1.32, 0.14, 0.56, shirtMat, false);
        const rightArm = makeLimb(0.35, 1.32, 0.14, 0.56, shirtMat, false);

        const shadow = new THREE.Mesh(
          new THREE.PlaneGeometry(0.95, 0.95),
          new THREE.MeshBasicMaterial({
            map: contactShadowTex,
            transparent: true,
            depthWrite: false,
            opacity: 0.44,
          })
        );
        shadow.rotation.x = -Math.PI / 2;
        shadow.position.y = 0.045;
        root.add(shadow);

        return { root, body, leftLeg, rightLeg, leftArm, rightArm };
      }

      const playerChar = createCompositeCharacter(0x2563eb, 0x1e293b, 0xf59e0b);
      playerChar.root.visible = false;
      scene.add(playerChar.root);

      // ------------------------------------------------------------------
      // 6. AI Traffic Cars + Walking Village NPCs
      // ------------------------------------------------------------------
      const trafficLoop = [
        new THREE.Vector3(-34, 0, -34),
        new THREE.Vector3(34, 0, -34),
        new THREE.Vector3(34, 0, 34),
        new THREE.Vector3(-34, 0, 34),
      ];

      function createTrafficCar(colorHex) {
        const g = new THREE.Group();
        const body = new THREE.Mesh(
          new THREE.BoxGeometry(1.85, 0.62, 3.8),
          new THREE.MeshPhysicalMaterial({
            color: colorHex,
            metalness: 0.35,
            roughness: 0.3,
            clearcoat: 0.8,
          })
        );
        body.position.y = 0.62;
        body.castShadow = !isSoftwareGl;
        g.add(body);

        const cabin = new THREE.Mesh(
          new THREE.BoxGeometry(1.62, 0.62, 1.9),
          new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.25, metalness: 0.2 })
        );
        cabin.position.set(0, 1.18, 0.12);
        g.add(cabin);

        const wheelMat = new THREE.MeshStandardMaterial({ color: 0x171717, roughness: 0.88 });
        const wheels = [];
        for (const wz of [-1.18, 1.18]) {
          for (const wx of [-0.94, 0.94]) {
            const w = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.26, 12), wheelMat);
            w.rotation.z = Math.PI / 2;
            w.position.set(wx, 0.35, wz);
            g.add(w);
            wheels.push(w);
          }
        }
        scene.add(g);
        return { group: g, wheels };
      }

      const trafficConfigs = [
        { color: 0xeab308, wp: 0, t: 0.15, speed: 9.5, laneOffset: 2.1 },
        { color: 0xef4444, wp: 1, t: 0.45, speed: 11.2, laneOffset: 2.1 },
        { color: 0xf8fafc, wp: 2, t: 0.72, speed: 8.6, laneOffset: 2.1 },
      ];
      const trafficCars = trafficConfigs.map((cfg) => {
        const built = createTrafficCar(cfg.color);
        const start = trafficLoop[cfg.wp].clone().lerp(trafficLoop[(cfg.wp + 1) % 4], cfg.t);
        built.group.position.copy(start);
        return { ...cfg, ...built, currentSpeed: cfg.speed };
      });

      const npcRoutes = [
        { shirt: 0xec4899, pants: 0x334155, cap: 0xf43f5e, pts: [[-11, -7], [-11, 11], [11, 11], [11, -7]], speed: 1.9 },
        { shirt: 0x10b981, pants: 0x1e293b, cap: 0x059669, pts: [[12, 8], [-12, 8], [-12, -5], [12, -5]], speed: 1.65 },
        { shirt: 0x8b5cf6, pants: 0x0f172a, cap: 0xf59e0b, pts: [[-29, -28], [29, -28], [29, -20], [-29, -20]], speed: 2.1 },
        { shirt: 0xf97316, pants: 0x374151, cap: 0x0284c7, pts: [[28, -14], [28, 24], [22, 24], [22, -14]], speed: 1.8 },
      ];
      const villageNpcs = npcRoutes.map((r, idx) => {
        const rig = createCompositeCharacter(r.shirt, r.pants, r.cap);
        const waypoints = r.pts.map(([x, z]) => new THREE.Vector3(x, 0, z));
        rig.root.position.copy(waypoints[0]);
        scene.add(rig.root);
        return { rig, waypoints, targetIdx: 1, speed: r.speed, phase: idx * 1.4 };
      });

      // ------------------------------------------------------------------
      // 7. GLTF / DRACO / RGBE Asset Injection + AnimationMixer
      // ------------------------------------------------------------------
      const mixers = [];
      let playerCharMixer = null;
      let playerCharAction = null;

      const dracoLoader = new DRACOLoader();
      dracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.6/');
      const gltfLoader = new GLTFLoader();
      gltfLoader.setDRACOLoader(dracoLoader);

      function isLoadable3DUrl(url) {
        return /\.(glb|gltf)(\?.*)?$/i.test(url);
      }

      function normalizeModelToGround(model, targetMaxDim) {
        const box = new THREE.Box3().setFromObject(model);
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z, 0.001);
        const scale = targetMaxDim / maxDim;
        model.scale.setScalar(scale);
        model.updateMatrixWorld(true);
        const scaledBox = new THREE.Box3().setFromObject(model);
        const center = scaledBox.getCenter(new THREE.Vector3());
        model.position.x -= center.x;
        model.position.z -= center.z;
        model.position.y -= scaledBox.min.y;
        model.traverse((child) => {
          if (child.isMesh) {
            child.castShadow = !isSoftwareGl;
            child.receiveShadow = true;
          }
        });
      }

      async function injectSelectedStudioAssets() {
        const a = CONFIG.assets || {};

        // HDRI Sky via RGBELoader
        if (Array.isArray(a.hdriSky) && a.hdriSky.length > 0) {
          const hdri = a.hdriSky[0];
          if (/\.hdr(\?.*)?$/i.test(hdri.url)) {
            new RGBELoader().load(
              hdri.url,
              (tex) => {
                const envMap = pmremGenerator.fromEquirectangular(tex).texture;
                scene.environment = envMap;
                scene.background = envMap;
                tex.dispose();
                showToast('HDRI Sky loaded: ' + hdri.name);
              },
              undefined,
              () => {}
            );
          }
        }

        // Vehicle .glb injection (with procedural fallback always ready)
        if (Array.isArray(a.vehicles)) {
          const glbVeh = a.vehicles.find((v) => isLoadable3DUrl(v.url));
          if (glbVeh) {
            gltfLoader.load(
              glbVeh.url,
              (gltf) => {
                const model = gltf.scene;
                normalizeModelToGround(model, 4.6);
                proceduralVehicleGroup.visible = false;
                vehicleRoot.add(model);
                if (gltf.animations && gltf.animations.length > 0) {
                  const m = new THREE.AnimationMixer(model);
                  gltf.animations.forEach((clip) => m.clipAction(clip).play());
                  mixers.push(m);
                }
                showToast('3D Vehicle loaded: ' + glbVeh.name);
              },
              undefined,
              () => {}
            );
          }
        }

        // Character .glb injection + AnimationMixer
        if (Array.isArray(a.characters)) {
          const glbChar = a.characters.find((c) => isLoadable3DUrl(c.url));
          if (glbChar) {
            gltfLoader.load(
              glbChar.url,
              (gltf) => {
                const model = gltf.scene;
                normalizeModelToGround(model, 1.8);
                playerChar.body.visible = false;
                playerChar.root.add(model);
                if (gltf.animations && gltf.animations.length > 0) {
                  playerCharMixer = new THREE.AnimationMixer(model);
                  const walkClip =
                    gltf.animations.find((cl) => /walk|run/i.test(cl.name)) ||
                    gltf.animations[0];
                  playerCharAction = playerCharMixer.clipAction(walkClip);
                  playerCharAction.play();
                  mixers.push(playerCharMixer);
                }
                showToast('3D Driver loaded: ' + glbChar.name);
              },
              undefined,
              () => {}
            );
          }
        }

        // Village World .glb prop injection
        if (Array.isArray(a.villageWorld)) {
          const glbProps = a.villageWorld.filter((w) => isLoadable3DUrl(w.url)).slice(0, 3);
          glbProps.forEach((prop, idx) => {
            gltfLoader.load(
              prop.url,
              (gltf) => {
                const model = gltf.scene;
                normalizeModelToGround(model, 6.5);
                model.position.set(idx === 0 ? -12 : idx === 1 ? 12 : 0, 0, -4);
                scene.add(model);
                if (gltf.animations && gltf.animations.length > 0) {
                  const m = new THREE.AnimationMixer(model);
                  m.clipAction(gltf.animations[0]).play();
                  mixers.push(m);
                }
              },
              undefined,
              () => {}
            );
          });
        }
      }

      injectSelectedStudioAssets();

      // ------------------------------------------------------------------
      // 8. .wav SFX Engine + Web Audio Engine / Horn / Gate Synthesizer
      // ------------------------------------------------------------------
      class StudioSfxEngine {
        constructor() {
          this.ctx = null;
          this.enabled = true;
          this.engineOsc = null;
          this.engineSubOsc = null;
          this.engineGain = null;
          this.wavElements = [];
          this.unlocked = false;

          const sfxList = (CONFIG.assets && CONFIG.assets.audioSfx) || [];
          for (const item of sfxList.slice(0, 4)) {
            if (item.url) {
              try {
                const audio = new Audio(item.url);
                audio.preload = 'none';
                audio.crossOrigin = 'anonymous';
                this.wavElements.push({ name: (item.name || '').toLowerCase(), audio });
              } catch {}
            }
          }
        }

        unlock() {
          if (this.unlocked) {
            if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
            return;
          }
          try {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            this.ctx = new AC();
            if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});

            const filter = this.ctx.createBiquadFilter();
            filter.type = 'lowpass';
            filter.frequency.value = 260;

            this.engineGain = this.ctx.createGain();
            this.engineGain.gain.value = 0.0;

            this.engineOsc = this.ctx.createOscillator();
            this.engineOsc.type = 'sawtooth';
            this.engineOsc.frequency.value = 54;

            this.engineSubOsc = this.ctx.createOscillator();
            this.engineSubOsc.type = 'triangle';
            this.engineSubOsc.frequency.value = 27;

            this.engineOsc.connect(filter);
            this.engineSubOsc.connect(filter);
            filter.connect(this.engineGain);
            this.engineGain.connect(this.ctx.destination);

            this.engineOsc.start();
            this.engineSubOsc.start();
            this.unlocked = true;
          } catch {}
        }

        setEnabled(on) {
          this.enabled = on;
          if (!on && this.engineGain && this.ctx) {
            this.engineGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.05);
          }
        }

        updateEngine(speedAbs, throttle, isDriving) {
          if (!this.unlocked || !this.ctx || !this.engineGain || !this.engineOsc) return;
          const now = this.ctx.currentTime;
          if (!this.enabled || !isDriving) {
            this.engineGain.gain.setTargetAtTime(0.0, now, 0.08);
            return;
          }
          const rpmFreq = 46 + speedAbs * 3.8 + (throttle ? 26 : 0);
          this.engineOsc.frequency.setTargetAtTime(rpmFreq, now, 0.07);
          this.engineSubOsc.frequency.setTargetAtTime(rpmFreq * 0.5, now, 0.07);
          const targetVol = 0.032 + (throttle ? 0.028 : 0.008) + Math.min(0.03, speedAbs * 0.0012);
          this.engineGain.gain.setTargetAtTime(targetVol, now, 0.08);
        }

        playExternalWav(keyword) {
          if (!this.enabled || this.wavElements.length === 0) return false;
          const match =
            this.wavElements.find((w) => w.name.includes(keyword)) || this.wavElements[0];
          if (!match) return false;
          try {
            match.audio.currentTime = 0;
            const p = match.audio.play();
            if (p && typeof p.catch === 'function') p.catch(() => {});
            return true;
          } catch {
            return false;
          }
        }

        playHorn() {
          this.unlock();
          if (!this.enabled) return;
          if (this.playExternalWav('horn')) return;
          if (!this.ctx) return;
          const now = this.ctx.currentTime;
          [380, 476].forEach((freq) => {
            const osc = this.ctx.createOscillator();
            const g = this.ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.value = freq;
            g.gain.setValueAtTime(0.001, now);
            g.gain.exponentialRampToValueAtTime(0.06, now + 0.02);
            g.gain.exponentialRampToValueAtTime(0.001, now + 0.34);
            osc.connect(g);
            g.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.36);
          });
        }

        playGate(opening) {
          this.unlock();
          if (!this.enabled) return;
          this.playExternalWav('gate');
          if (!this.ctx) return;
          const now = this.ctx.currentTime;
          const osc = this.ctx.createOscillator();
          const g = this.ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(opening ? 140 : 210, now);
          osc.frequency.linearRampToValueAtTime(opening ? 220 : 120, now + 0.42);
          g.gain.setValueAtTime(0.06, now);
          g.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
          osc.connect(g);
          g.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + 0.47);
        }

        playClick(pitch = 520) {
          this.unlock();
          if (!this.enabled || !this.ctx) return;
          const now = this.ctx.currentTime;
          const osc = this.ctx.createOscillator();
          const g = this.ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(pitch, now);
          g.gain.setValueAtTime(0.045, now);
          g.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
          osc.connect(g);
          g.connect(this.ctx.destination);
          osc.start(now);
          osc.stop(now + 0.09);
        }
      }

      const sfx = new StudioSfxEngine();

      // ------------------------------------------------------------------
      // 9. Controls State: Steering Wheel, Gearbox (R/N/1/2/3), Pedals, Gate, Enter/Exit
      // ------------------------------------------------------------------
      const GEAR_SPECS = {
        R: { maxSpeed: 6.5, accel: 11.0, dir: -1, badgeClass: 'gear-r' },
        N: { maxSpeed: 0.0, accel: 0.0, dir: 0, badgeClass: 'gear-n' },
        '1': { maxSpeed: 8.2, accel: 14.5, dir: 1, badgeClass: '' },
        '2': { maxSpeed: 16.5, accel: 12.2, dir: 1, badgeClass: '' },
        '3': { maxSpeed: 26.8, accel: 10.6, dir: 1, badgeClass: '' },
      };

      const state = {
        mode: 'driving', // 'driving' | 'walking'
        gear: '1',
        speed: 0,
        heading: 0,
        steerInput: 0,
        wheelAngleDeg: 0,
        gas: false,
        brake: false,
        walkHeading: 0,
        walkPhase: 0,
        camMode: 0, // 0: chase, 1: hood/close, 2: elevated
      };

      const keys = { left: false, right: false, up: false, down: false };

      const elSpeed = document.getElementById('hud-speed');
      const elGearBadge = document.getElementById('hud-gear-badge');
      const elModeLabel = document.getElementById('hud-mode-label');
      const elToast = document.getElementById('hud-toast');
      const elWheel = document.getElementById('steering-wheel');
      const elWheelRot = document.getElementById('steering-wheel-rotator');
      const elGateBtn = document.getElementById('btn-gate');
      const elEnterExitBtn = document.getElementById('btn-enter-exit');
      const elBrake = document.getElementById('pedal-brake');
      const elGas = document.getElementById('pedal-gas');
      const elControls = document.getElementById('hud-controls');
      const elSfxBtn = document.getElementById('btn-sfx');
      const gearBtns = Array.from(document.querySelectorAll('.gear-btn'));

      let toastTimer = 0;
      function showToast(msg) {
        elToast.textContent = msg;
        elToast.classList.add('show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => elToast.classList.remove('show'), 2000);
      }

      function setGear(g) {
        if (!GEAR_SPECS[g]) return;
        state.gear = g;
        elGearBadge.textContent = g;
        elGearBadge.className = 'hud-gear-badge ' + GEAR_SPECS[g].badgeClass;
        gearBtns.forEach((btn) => {
          btn.className = 'gear-btn';
          if (btn.dataset.gear === g) {
            btn.classList.add('active-' + g.toLowerCase());
          }
        });
        sfx.playClick(g === 'R' ? 380 : g === 'N' ? 460 : 540 + Number(g) * 60);
      }

      gearBtns.forEach((btn) => {
        btn.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          sfx.unlock();
          setGear(btn.dataset.gear);
        });
      });

      function toggleGate() {
        sfx.unlock();
        gateState.open = !gateState.open;
        gateState.targetAngle = gateState.open ? Math.PI * 0.52 : 0;
        elGateBtn.textContent = gateState.open ? 'Close Gate' : 'Open Gate';
        elGateBtn.classList.toggle('gate-open', gateState.open);
        sfx.playGate(gateState.open);
        showToast(gateState.open ? 'Compound Gate Opened' : 'Compound Gate Closed');
      }

      function toggleEnterExitVehicle() {
        sfx.unlock();
        if (state.mode === 'driving') {
          state.mode = 'walking';
          state.speed = 0;
          const exitOffset = new THREE.Vector3(-2.15, 0, 0).applyAxisAngle(
            new THREE.Vector3(0, 1, 0),
            state.heading
          );
          playerChar.root.position.copy(vehicleRoot.position).add(exitOffset);
          playerChar.root.position.y = 0;
          state.walkHeading = state.heading;
          playerChar.root.rotation.y = state.walkHeading;
          playerChar.root.visible = true;
          elModeLabel.textContent = 'WALK';
          elEnterExitBtn.textContent = 'Enter Car';
          elEnterExitBtn.classList.add('walk-mode');
          sfx.playClick(320);
          showToast('Exited Vehicle · Walking Mode');
        } else {
          state.mode = 'driving';
          playerChar.root.visible = false;
          elModeLabel.textContent = 'DRIVE';
          elEnterExitBtn.textContent = 'Exit Car';
          elEnterExitBtn.classList.remove('walk-mode');
          sfx.playClick(440);
          showToast('Entered Vehicle · Drive Ready');
        }
      }

      elGateBtn.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        toggleGate();
      });

      elEnterExitBtn.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        toggleEnterExitVehicle();
      });

      document.getElementById('btn-horn').addEventListener('pointerdown', (e) => {
        e.preventDefault();
        sfx.playHorn();
      });

      document.getElementById('btn-cam').addEventListener('pointerdown', (e) => {
        e.preventDefault();
        sfx.unlock();
        state.camMode = (state.camMode + 1) % 3;
        const names = ['Chase Cam', 'Hood Cam', 'Village Bird Cam'];
        showToast(names[state.camMode]);
      });

      elSfxBtn.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        sfx.unlock();
        sfx.setEnabled(!sfx.enabled);
        elSfxBtn.classList.toggle('active', sfx.enabled);
        elSfxBtn.textContent = sfx.enabled ? 'SFX' : 'MUTE';
      });

      document.getElementById('btn-hud-toggle').addEventListener('pointerdown', (e) => {
        e.preventDefault();
        elControls.classList.toggle('hidden-hud');
      });

      // Multi-touch Steering Wheel Dragging
      let steerPointerId = null;
      let steerStartX = 0;

      elWheel.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        sfx.unlock();
        steerPointerId = e.pointerId;
        steerStartX = e.clientX;
        elWheel.setPointerCapture(e.pointerId);
      });

      elWheel.addEventListener('pointermove', (e) => {
        if (steerPointerId !== e.pointerId) return;
        const rect = elWheel.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const dxCenter = (e.clientX - cx) / Math.max(24, rect.width * 0.55);
        const dxDrag = (e.clientX - steerStartX) / Math.max(28, rect.width * 0.65);
        const blended = THREE.MathUtils.clamp(dxCenter * 0.55 + dxDrag * 0.65, -1, 1);
        state.steerInput = blended;
      });

      function releaseSteer(e) {
        if (steerPointerId !== e.pointerId) return;
        steerPointerId = null;
        state.steerInput = 0;
      }
      elWheel.addEventListener('pointerup', releaseSteer);
      elWheel.addEventListener('pointercancel', releaseSteer);

      // Multi-touch Gas & Brake Pedals
      function bindPedal(el, prop) {
        let activePtr = null;
        el.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          sfx.unlock();
          activePtr = e.pointerId;
          state[prop] = true;
          el.classList.add('pressed');
          el.setPointerCapture(e.pointerId);
        });
        const release = (e) => {
          if (activePtr !== null && e.pointerId !== activePtr) return;
          activePtr = null;
          state[prop] = false;
          el.classList.remove('pressed');
        };
        el.addEventListener('pointerup', release);
        el.addEventListener('pointercancel', release);
      }
      bindPedal(elGas, 'gas');
      bindPedal(elBrake, 'brake');

      // Keyboard fallback for desktop testing
      window.addEventListener('keydown', (e) => {
        sfx.unlock();
        const k = e.key.toLowerCase();
        if (k === 'w' || k === 'arrowup') keys.up = true;
        if (k === 's' || k === 'arrowdown') keys.down = true;
        if (k === 'a' || k === 'arrowleft') keys.left = true;
        if (k === 'd' || k === 'arrowright') keys.right = true;
        if (k === 'r') setGear('R');
        if (k === 'n') setGear('N');
        if (k === '1') setGear('1');
        if (k === '2') setGear('2');
        if (k === '3') setGear('3');
        if (k === 'g') toggleGate();
        if (k === 'e') toggleEnterExitVehicle();
        if (k === 'h') sfx.playHorn();
        if (k === 'c') {
          state.camMode = (state.camMode + 1) % 3;
        }
        if (k === 'u') elControls.classList.toggle('hidden-hud');
      });

      window.addEventListener('keyup', (e) => {
        const k = e.key.toLowerCase();
        if (k === 'w' || k === 'arrowup') keys.up = false;
        if (k === 's' || k === 'arrowdown') keys.down = false;
        if (k === 'a' || k === 'arrowleft') keys.left = false;
        if (k === 'd' || k === 'arrowright') keys.right = false;
      });

      // ------------------------------------------------------------------
      // 10. Pre-allocated Loop Helpers & Physics / Animation Tick
      // ------------------------------------------------------------------
      const _camGoal = new THREE.Vector3();
      const _camLook = new THREE.Vector3();
      const _dirVec = new THREE.Vector3();
      const _nextPos = new THREE.Vector3();
      const clock = new THREE.Clock();

      let frameId = 0;

      function afterDraw(cb) {
        const gl = renderer.getContext();
        if (gl && typeof gl.fenceSync === 'function') {
          const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
          gl.flush();
          const poll = () => {
            const st = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
            if (st === gl.UNSIGNALED) {
              frameId = window.setTimeout(poll, 5);
            } else {
              if (sync) gl.deleteSync(sync);
              frameId = window.setTimeout(cb, 80);
            }
          };
          frameId = window.setTimeout(poll, 5);
        } else {
          frameId = window.setTimeout(cb, 80);
        }
      }

      function collidesWithWorld(px, pz, radius) {
        if (Math.abs(px) > 64 || Math.abs(pz) > 64) return true;
        // Closed compound gate barrier
        if (gateState.angle < 0.75) {
          if (Math.abs(pz - -11.5) < radius + 0.45 && Math.abs(px) < 4.1) {
            return true;
          }
        }
        // Compound fence walls beside gate
        if (Math.abs(pz - -11.5) < radius + 0.4 && Math.abs(px) >= 4.0 && Math.abs(px) < 13.5) {
          return true;
        }
        for (let i = 0; i < colliders.length; i++) {
          const c = colliders[i];
          const dx = px - c.x;
          const dz = pz - c.z;
          const minR = c.r + radius;
          if (dx * dx + dz * dz < minR * minR) return true;
        }
        return false;
      }

      function tick() {
        const dt = Math.min(clock.getDelta(), 0.08);
        const gasActive = state.gas || keys.up;
        const brakeActive = state.brake || keys.down;
        const keySteer = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
        const targetSteer = steerPointerId !== null ? state.steerInput : keySteer;

        // Smooth Steering Wheel Visual Rotation
        const targetWheelDeg = targetSteer * 155;
        state.wheelAngleDeg = THREE.MathUtils.damp(state.wheelAngleDeg, targetWheelDeg, 12, dt);
        elWheelRot.style.transform = 'rotate(' + state.wheelAngleDeg.toFixed(1) + 'deg)';

        // Smooth Compound Gate Swing
        gateState.angle = THREE.MathUtils.damp(gateState.angle, gateState.targetAngle, 5.5, dt);
        gateLeftPivot.rotation.y = gateState.angle;
        gateRightPivot.rotation.y = -gateState.angle;

        // Vehicle OR Walking Character Kinematics
        if (state.mode === 'driving') {
          const spec = GEAR_SPECS[state.gear];

          if (gasActive && spec.dir !== 0) {
            const targetV = spec.maxSpeed * spec.dir;
            state.speed = THREE.MathUtils.damp(state.speed, targetV, spec.accel * 0.14, dt);
          } else {
            // Smooth rolling resistance
            state.speed = THREE.MathUtils.damp(state.speed, 0, 1.35, dt);
          }

          if (brakeActive) {
            state.speed = THREE.MathUtils.damp(state.speed, 0, 7.5, dt);
          }

          if (Math.abs(state.speed) < 0.03 && !gasActive) state.speed = 0;

          // Steer front wheels visually
          const steerRad = -targetSteer * 0.5;
          for (let i = 0; i < wheelPivots.length; i++) {
            wheelPivots[i].rotation.y = THREE.MathUtils.damp(
              wheelPivots[i].rotation.y,
              steerRad,
              12,
              dt
            );
          }

          // Turning physics (reverses turn direction naturally in R gear)
          if (Math.abs(state.speed) > 0.08) {
            const turnFactor = THREE.MathUtils.clamp(Math.abs(state.speed) / 7, 0.22, 1.0);
            const dirSign = state.speed >= 0 ? 1 : -1;
            state.heading -= targetSteer * 1.95 * turnFactor * dirSign * dt;
          }

          _nextPos.set(
            vehicleRoot.position.x - Math.sin(state.heading) * state.speed * dt,
            0,
            vehicleRoot.position.z - Math.cos(state.heading) * state.speed * dt
          );

          if (!collidesWithWorld(_nextPos.x, _nextPos.z, 1.65)) {
            vehicleRoot.position.x = _nextPos.x;
            vehicleRoot.position.z = _nextPos.z;
          } else {
            state.speed *= -0.25;
          }

          vehicleRoot.rotation.y = state.heading;

          // Spin all 4 wheels
          const wheelRotDelta = (state.speed * dt) / 0.42;
          for (let i = 0; i < wheelSpinMeshes.length; i++) {
            wheelSpinMeshes[i].rotation.x -= wheelRotDelta;
          }

          // Dynamic Brake & Reverse Taillights
          if (brakeLightMat) {
            brakeLightMat.emissiveIntensity = brakeActive ? 2.4 : 0.35;
          }
          if (reverseLightMat) {
            reverseLightMat.emissiveIntensity = state.gear === 'R' ? 2.1 : 0.05;
          }

          const kmh = Math.round(Math.abs(state.speed) * 3.6);
          elSpeed.textContent = kmh + ' km/h';
          sfx.updateEngine(Math.abs(state.speed), gasActive, true);
        } else {
          // 3rd-Person Walking Mode
          state.walkHeading -= targetSteer * 2.4 * dt;
          const moveDir = (gasActive ? 1 : 0) - (brakeActive ? 1 : 0);
          const walkSpeed = moveDir * 4.6;
          if (moveDir !== 0) {
            const nx = playerChar.root.position.x - Math.sin(state.walkHeading) * walkSpeed * dt;
            const nz = playerChar.root.position.z - Math.cos(state.walkHeading) * walkSpeed * dt;
            if (!collidesWithWorld(nx, nz, 0.55)) {
              playerChar.root.position.x = nx;
              playerChar.root.position.z = nz;
            }
            state.walkPhase += dt * 9.5;
          } else {
            state.walkPhase = THREE.MathUtils.damp(state.walkPhase, 0, 8, dt);
          }

          playerChar.root.rotation.y = state.walkHeading;
          const swing = moveDir !== 0 ? Math.sin(state.walkPhase) * 0.55 : 0;
          playerChar.leftLeg.rotation.x = swing;
          playerChar.rightLeg.rotation.x = -swing;
          playerChar.leftArm.rotation.x = -swing * 0.7;
          playerChar.rightArm.rotation.x = swing * 0.7;

          if (playerCharAction) {
            playerCharAction.timeScale = moveDir !== 0 ? 1.1 : 0.0;
          }

          elSpeed.textContent = moveDir !== 0 ? '5 km/h' : '0 km/h';
          sfx.updateEngine(0, false, false);
        }

        // Update AI Traffic Cars along village road loop
        for (let i = 0; i < trafficCars.length; i++) {
          const car = trafficCars[i];
          const nextIdx = (car.wp + 1) % trafficLoop.length;
          const targetPt = trafficLoop[nextIdx];
          _dirVec.subVectors(targetPt, car.group.position);
          const dist = _dirVec.length();

          // Yield softly if player is close ahead
          const distToPlayer = car.group.position.distanceTo(vehicleRoot.position);
          const desiredSpd = distToPlayer < 8.5 ? 1.2 : car.speed;
          car.currentSpeed = THREE.MathUtils.damp(car.currentSpeed, desiredSpd, 4, dt);

          if (dist < 1.8) {
            car.wp = nextIdx;
          } else {
            _dirVec.normalize();
            car.group.position.addScaledVector(_dirVec, car.currentSpeed * dt);
            const targetYaw = Math.atan2(-_dirVec.x, -_dirVec.z);
            let diff = targetYaw - car.group.rotation.y;
            while (diff > Math.PI) diff -= Math.PI * 2;
            while (diff < -Math.PI) diff += Math.PI * 2;
            car.group.rotation.y += diff * Math.min(1, dt * 6);
          }
          const wDelta = (car.currentSpeed * dt) / 0.35;
          for (let w = 0; w < car.wheels.length; w++) {
            car.wheels[w].rotation.x -= wDelta;
          }
        }

        // Update Autonomous Village NPCs
        for (let i = 0; i < villageNpcs.length; i++) {
          const npc = villageNpcs[i];
          const wp = npc.waypoints[npc.targetIdx];
          _dirVec.subVectors(wp, npc.rig.root.position);
          const dist = _dirVec.length();
          if (dist < 0.7) {
            npc.targetIdx = (npc.targetIdx + 1) % npc.waypoints.length;
          } else {
            _dirVec.normalize();
            npc.rig.root.position.addScaledVector(_dirVec, npc.speed * dt);
            npc.rig.root.rotation.y = Math.atan2(-_dirVec.x, -_dirVec.z);
            npc.phase += dt * 7.2;
            const sw = Math.sin(npc.phase) * 0.45;
            npc.rig.leftLeg.rotation.x = sw;
            npc.rig.rightLeg.rotation.x = -sw;
            npc.rig.leftArm.rotation.x = -sw * 0.65;
            npc.rig.rightArm.rotation.x = sw * 0.65;
          }
        }

        // Update all loaded GLB AnimationMixers
        for (let i = 0; i < mixers.length; i++) {
          mixers[i].update(dt);
        }

        // Follow Camera with Smooth Exponential Damping
        const focusObj = state.mode === 'driving' ? vehicleRoot : playerChar.root;
        const focusHeading = state.mode === 'driving' ? state.heading : state.walkHeading;

        const camDist =
          state.mode === 'walking' ? 4.8 : state.camMode === 1 ? 1.1 : state.camMode === 2 ? 15.5 : 8.6;
        const camHeight =
          state.mode === 'walking' ? 2.5 : state.camMode === 1 ? 1.95 : state.camMode === 2 ? 11.5 : 3.9;
        const lookAhead = state.camMode === 1 ? 12 : 2.5;

        _camGoal.set(
          focusObj.position.x + Math.sin(focusHeading) * camDist,
          focusObj.position.y + camHeight,
          focusObj.position.z + Math.cos(focusHeading) * camDist
        );
        camera.position.x = THREE.MathUtils.damp(camera.position.x, _camGoal.x, 6.5, dt);
        camera.position.y = THREE.MathUtils.damp(camera.position.y, _camGoal.y, 6.5, dt);
        camera.position.z = THREE.MathUtils.damp(camera.position.z, _camGoal.z, 6.5, dt);

        _camLook.set(
          focusObj.position.x - Math.sin(focusHeading) * lookAhead,
          focusObj.position.y + (state.mode === 'walking' ? 1.35 : 1.15),
          focusObj.position.z - Math.cos(focusHeading) * lookAhead
        );
        camera.lookAt(_camLook);

        // Keep Sun Shadow Frustum centered on player
        sunLight.position.set(focusObj.position.x + 24, 38, focusObj.position.z + 20);
        sunLight.target.position.copy(focusObj.position);
        sunLight.target.updateMatrixWorld();

        renderer.render(scene, camera);

        if (isSoftwareGl) {
          afterDraw(tick);
        } else {
          frameId = requestAnimationFrame(tick);
        }
      }

      // Set initial camera pose cleanly before first frame
      camera.position.set(0, 4.2, 11.5);
      camera.lookAt(0, 1.2, 0);

      window.addEventListener('resize', () => {
        const w = Math.max(1, window.innerWidth);
        const h = Math.max(1, window.innerHeight);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      });

      window.addEventListener('beforeunload', () => {
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);
        pmremGenerator.dispose();
        renderer.dispose();
      });

      showToast(CONFIG.title + ' · Tap GAS or Steer');
      tick();
    </script>
  </body>
</html>
`;
}

export async function generatePro3DGameFiles(
  options: GeneratePro3DGameOptions
): Promise<GeneratedPro3DGameResult> {
  const theme = options.theme?.trim() || 'Village 3D Drive';
  const title = options.title?.trim() || `${theme} — Sarfealam 3D Studio`;
  const archetype = resolveThemeArchetype(theme);
  const selectedAssets = options.selectedAssets ?? [];

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 18,
    message: `Preparing Pro 3D Three.js runtime (${theme})...`,
  });

  // Respect cooperative Pause/Resume checkpoints
  await waitIfPaused(options.signal);

  const assetsPayload = extractGameAssets(selectedAssets);
  const injectedAssetsCount =
    assetsPayload.vehicles.length +
    assetsPayload.characters.length +
    assetsPayload.villageWorld.length +
    assetsPayload.hdriSky.length +
    assetsPayload.texturesPbr.length +
    assetsPayload.audioSfx.length;

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'working',
    progress: 58,
    message: `Injecting ${injectedAssetsCount} Vault assets + Touch Controls & AI Traffic...`,
  });

  await waitIfPaused(options.signal);

  const now = Date.now();
  const indexHtml = buildPro3DGameHtml({
    title,
    theme,
    archetype,
    assets: assetsPayload,
    appsSupabaseUrl: options.appsSupabaseUrl,
    appsSupabaseAnonKey: options.appsSupabaseAnonKey,
  });

  const manifestJson = buildManifestJson(
    title,
    theme,
    selectedAssets,
    options.appsSupabaseUrl
  );

  await waitIfPaused(options.signal);

  const files: VirtualFile[] = [
    {
      path: 'index.html',
      language: 'html',
      content: indexHtml,
      updatedAt: now,
      generatedBy: 'code',
    },
    {
      path: 'assets/manifest.json',
      language: 'json',
      content: manifestJson,
      updatedAt: now,
      generatedBy: 'asset',
    },
  ];

  studioBus.emit('bot:progress', {
    botId: 'code',
    status: 'ready',
    progress: 100,
    message: `3D Game ready (${theme}) · ${injectedAssetsCount} assets wired`,
  });

  return {
    files,
    entryPath: 'index.html',
    title,
    theme,
    injectedAssetsCount,
  };
}
