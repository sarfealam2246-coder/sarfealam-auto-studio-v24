import { DEFAULT_2026_MODELS } from './secretsService';
import { buildMemoryContext } from './memoryService';
import {
  deduplicateActions,
  detectLocalUIActions,
  sanitizeUIActions,
  type UIAction,
} from './uiActuators';
import type { VirtualFile, WorldState } from '../types/studio';

export interface RouteCommandResult {
  reply: string;
  actions: UIAction[];
  providerUsed: string;
  errorNote?: string;
}

interface ProviderAttemptConfig {
  id: 'gemini' | 'groq' | 'nvidia' | 'openrouter' | 'cohere';
  label: string;
  apiKey: string;
  model: string;
}

const REQUEST_TIMEOUT_MS = 15_000;

function buildSystemPrompt(state: WorldState): string {
  const fileList = state.files.map((f) => f.path).join(', ') || 'none';
  const langInstruction =
    state.language === 'hi'
      ? 'Respond in natural, friendly Hindi / Hinglish (Devanagari or crisp Hinglish).'
      : 'Respond in crisp, concise, helpful English.';
  const memoryBlock = buildMemoryContext(state.memoryRules);

  return [
    'You are Sarfealam Auto-Studio JARVIS, an on-device mobile studio copilot.',
    langInstruction,
    `Current Studio State: mode=${state.mode}, language=${state.language}, engine=${state.targetEngine}, displayMode=${state.displayMode}, stage="${state.currentStage}", paused=${state.paused}, activePanel=${state.activePanel}, files=[${fileList}].`,
    ...(memoryBlock ? [memoryBlock] : []),
    'ALWAYS return strict JSON ONLY (no markdown fences) with this exact schema:',
    '{"reply":"short helpful response","actions":[]}',
    'Valid actions array items (only include actions explicitly requested by the user):',
    '- {"type":"open_panel","panel":"none"|"secrets"|"code"|"vault"|"admin"|"camera"}',
    '- {"type":"set_display_mode","mode":"expanded"|"floating"|"collapsed"}',
    '- {"type":"set_language","language":"en"|"hi"}',
    '- {"type":"set_mode","mode":"jarvis"|"manual"}',
    '- {"type":"set_engine","engine":"auto"|"capacitor"|"godot4"|"flutter"|"unity"}',
    '- {"type":"select_file","path":"exact path from files list"}',
    '- {"type":"set_stage","stage":1|2|3|4|5}',
    '- {"type":"save_memory","rule":"concise permanent preference or rule to remember"}',
    '- {"type":"set_paused","paused":true|false}',
    '- {"type":"search_assets","query":"keywords","categories":["vehicles"|"characters"|"weapons_gear"|"village_world"|"textures_pbr"|"hdri_sky"|"audio_sfx"|"app_audio"|"wikimedia_photos"|"iconify_icons"]}',
    '- {"type":"select_asset","target":"1|2|first|second|last|all|asset name","decision":"keep"|"reject"}',
    '- {"type":"clone_repo","repoUrl":"owner/repo or https://github.com/owner/repo"}',
    '- {"type":"build_3d_game","theme":"optional theme e.g. Village Cargo Truck or Village 3D Car Drive"}',
    '- {"type":"build_commercial_app","category":"fintech"|"fantasy"|"ecommerce"|"booking","prompt":"optional app details"}',
    '- {"type":"create_broadcast","topic":"topic for 2-voice 9:16 broadcast short video"}',
    '- {"type":"spawn_sub_bot","role":"specialist role e.g. QA Reviewer or Physics Tuner","task":"focused inspection or tuning task"}',
    '- {"type":"fetch_any_api","name":"short skill name","url":"https://..."}',
  ].join('\n');
}

function parseRouterResponse(
  rawText: string,
  files: VirtualFile[]
): { reply: string; actions: UIAction[] } {
  const trimmed = rawText.trim();
  if (!trimmed) {
    return { reply: 'Done.', actions: [] };
  }

  // Strip markdown code fences if model wrapped JSON
  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenceMatch ? fenceMatch[1].trim() : trimmed;

  const tryParse = (input: string): { reply: string; actions: UIAction[] } | null => {
    try {
      const parsed: unknown = JSON.parse(input);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        const obj = parsed as Record<string, unknown>;
        const reply =
          typeof obj.reply === 'string' && obj.reply.trim()
            ? obj.reply.trim()
            : '';
        const actions = sanitizeUIActions(obj.actions, files);
        if (reply || actions.length > 0) {
          return {
            reply: reply || 'Action executed.',
            actions,
          };
        }
      }
    } catch {
      return null;
    }
    return null;
  };

  const direct = tryParse(candidate);
  if (direct) return direct;

  // Try extracting first balanced JSON object substring
  const firstBrace = candidate.indexOf('{');
  const lastBrace = candidate.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    const sliced = tryParse(candidate.slice(firstBrace, lastBrace + 1));
    if (sliced) return sliced;
  }

  // Safe fallback to plain text reply
  return {
    reply: trimmed,
    actions: [],
  };
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<Response> {
  const controller = new AbortController();
  const timerId = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    window.clearTimeout(timerId);
  }
}

function buildRecentChatHistory(state: WorldState): {
  role: 'user' | 'assistant';
  content: string;
}[] {
  return state.messages
    .filter((m) => m.role === 'user' || m.role === 'jarvis')
    .slice(-6)
    .map((m) => ({
      role: m.role === 'user' ? 'user' : 'assistant',
      content: m.text,
    }));
}

async function callGemini(
  provider: ProviderAttemptConfig,
  systemPrompt: string,
  userInput: string,
  state: WorldState
): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(
    provider.model
  )}:generateContent?key=${encodeURIComponent(provider.apiKey)}`;

  const history = buildRecentChatHistory(state).map((msg) => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.content }],
  }));

  const response = await fetchWithTimeout(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: {
        parts: [{ text: systemPrompt }],
      },
      contents: [
        ...history,
        {
          role: 'user',
          parts: [{ text: userInput }],
        },
      ],
      generationConfig: {
        temperature: 0.35,
        responseMimeType: 'application/json',
      },
    }),
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const data = (await response.json()) as {
    candidates?: {
      content?: {
        parts?: { text?: string }[];
      };
    }[];
  };

  const text = data.candidates?.[0]?.content?.parts
    ?.map((p) => p.text ?? '')
    .join('')
    .trim();

  if (!text) {
    throw new Error('Empty Gemini response');
  }
  return text;
}

async function callOpenAICompatible(
  endpoint: string,
  provider: ProviderAttemptConfig,
  systemPrompt: string,
  userInput: string,
  state: WorldState,
  extraHeaders?: Record<string, string>
): Promise<string> {
  const history = buildRecentChatHistory(state);

  const response = await fetchWithTimeout(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${provider.apiKey}`,
      ...(extraHeaders ?? {}),
    },
    body: JSON.stringify({
      model: provider.model,
      temperature: 0.35,
      messages: [
        { role: 'system', content: systemPrompt },
        ...history,
        { role: 'user', content: userInput },
      ],
    }),
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const data = (await response.json()) as {
    choices?: {
      message?: {
        content?: string;
      };
    }[];
  };

  const text = data.choices?.[0]?.message?.content?.trim();
  if (!text) {
    throw new Error(`Empty ${provider.label} response`);
  }
  return text;
}

async function callCohere(
  provider: ProviderAttemptConfig,
  systemPrompt: string,
  userInput: string,
  state: WorldState
): Promise<string> {
  const history = buildRecentChatHistory(state);

  const response = await fetchWithTimeout('https://api.cohere.com/v2/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${provider.apiKey}`,
    },
    body: JSON.stringify({
      model: provider.model,
      temperature: 0.35,
      messages: [
        { role: 'system', content: systemPrompt },
        ...history,
        { role: 'user', content: userInput },
      ],
    }),
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const data = (await response.json()) as {
    message?: {
      content?: { type?: string; text?: string }[];
    };
  };

  const text = data.message?.content
    ?.map((chunk) => (typeof chunk.text === 'string' ? chunk.text : ''))
    .join('')
    .trim();

  if (!text) {
    throw new Error('Empty Cohere response');
  }
  return text;
}

function collectConfiguredProviders(state: WorldState): ProviderAttemptConfig[] {
  const s = state.secrets;
  const list: ProviderAttemptConfig[] = [];

  if (s.geminiApiKey?.trim()) {
    const model = s.geminiModel?.trim() || DEFAULT_2026_MODELS.gemini;
    list.push({
      id: 'gemini',
      label: model.includes('3.8') ? 'Gemini 3.8' : 'Gemini',
      apiKey: s.geminiApiKey.trim(),
      model,
    });
  }

  if (s.groqApiKey?.trim()) {
    list.push({
      id: 'groq',
      label: 'Groq',
      apiKey: s.groqApiKey.trim(),
      model: s.groqModel?.trim() || DEFAULT_2026_MODELS.groq,
    });
  }

  if (s.nvidiaApiKey?.trim()) {
    list.push({
      id: 'nvidia',
      label: 'NVIDIA',
      apiKey: s.nvidiaApiKey.trim(),
      model: s.nvidiaModel?.trim() || DEFAULT_2026_MODELS.nvidia,
    });
  }

  if (s.openRouterApiKey?.trim()) {
    list.push({
      id: 'openrouter',
      label: 'OpenRouter',
      apiKey: s.openRouterApiKey.trim(),
      model: s.openRouterModel?.trim() || DEFAULT_2026_MODELS.openRouter,
    });
  }

  if (s.cohereApiKey?.trim()) {
    list.push({
      id: 'cohere',
      label: 'Cohere',
      apiKey: s.cohereApiKey.trim(),
      model: s.cohereModel?.trim() || DEFAULT_2026_MODELS.cohere,
    });
  }

  return list;
}

export async function routeStudioCommand(
  userInput: string,
  state: WorldState
): Promise<RouteCommandResult> {
  const localActions = detectLocalUIActions(userInput, state);
  const providers = collectConfiguredProviders(state);

  // Zero keys configured: still execute local actuators + prompt user clearly
  if (providers.length === 0) {
    const hasLocal = localActions.length > 0;
    const reply =
      state.language === 'hi'
        ? hasLocal
          ? 'लोकल कमांड चला दिया गया है। स्मार्ट AI उत्तर के लिए नीचे "Secrets" टैप करके कोई भी API key जोड़ें।'
          : 'अभी कोई AI API key सेव नहीं है। नीचे "Secrets" पर टैप करके Gemini, Groq, NVIDIA, OpenRouter या Cohere की key जोड़ें।'
        : hasLocal
          ? 'Executed your local studio command. Tap "Secrets" below to add an API key for full JARVIS AI responses.'
          : 'No AI API keys are saved yet. Tap "Secrets" below to add a Gemini, Groq, NVIDIA, OpenRouter, or Cohere API key.';

    return {
      reply,
      actions: localActions,
      providerUsed: 'Local',
    };
  }

  const systemPrompt = buildSystemPrompt(state);
  const failures: string[] = [];

  for (const provider of providers) {
    try {
      let rawText = '';

      switch (provider.id) {
        case 'gemini':
          rawText = await callGemini(provider, systemPrompt, userInput, state);
          break;
        case 'groq':
          rawText = await callOpenAICompatible(
            'https://api.groq.com/openai/v1/chat/completions',
            provider,
            systemPrompt,
            userInput,
            state
          );
          break;
        case 'nvidia':
          rawText = await callOpenAICompatible(
            'https://integrate.api.nvidia.com/v1/chat/completions',
            provider,
            systemPrompt,
            userInput,
            state
          );
          break;
        case 'openrouter':
          rawText = await callOpenAICompatible(
            'https://openrouter.ai/api/v1/chat/completions',
            provider,
            systemPrompt,
            userInput,
            state,
            {
              'HTTP-Referer':
                typeof window !== 'undefined'
                  ? window.location.origin
                  : 'https://sarfealam.autostudio',
              'X-Title': 'Sarfealam Auto-Studio',
            }
          );
          break;
        case 'cohere':
          rawText = await callCohere(provider, systemPrompt, userInput, state);
          break;
      }

      const parsed = parseRouterResponse(rawText, state.files);
      const mergedActions = deduplicateActions([
        ...localActions,
        ...parsed.actions,
      ]);

      return {
        reply: parsed.reply,
        actions: mergedActions,
        providerUsed: provider.label,
        errorNote:
          failures.length > 0
            ? `Fallback after: ${failures.join(', ')}`
            : undefined,
      };
    } catch (err) {
      const reason =
        err instanceof DOMException && err.name === 'AbortError'
          ? '15s timeout'
          : err instanceof Error
            ? err.message
            : 'failed';
      failures.push(`${provider.label} (${reason})`);
    }
  }

  // All configured providers failed — fall back cleanly to local actuators
  const errorSummary = failures.join(' · ');
  const fallbackReply =
    state.language === 'hi'
      ? localActions.length > 0
        ? `AI प्रोवाइडर उपलब्ध नहीं हैं (${errorSummary}), लेकिन लोकल कमांड चला दिया गया है।`
        : `सभी कॉन्फ़िगर किए गए AI प्रोवाइडर विफल रहे (${errorSummary})। कृपया Secrets में अपनी API keys जाँचें।`
      : localActions.length > 0
        ? `AI providers could not be reached (${errorSummary}), but your local studio action was executed.`
        : `All configured AI providers failed (${errorSummary}). Please check your keys in Secrets.`;

  return {
    reply: fallbackReply,
    actions: localActions,
    providerUsed: 'Local',
    errorNote: errorSummary,
  };
}

export interface RawAICompletionResult {
  ok: boolean;
  rawText: string;
  providerUsed: string;
  error?: string;
}

export async function requestStudioAICompletion(
  systemPrompt: string,
  userPrompt: string,
  state: WorldState
): Promise<RawAICompletionResult> {
  const providers = collectConfiguredProviders(state);
  if (providers.length === 0) {
    return {
      ok: false,
      rawText: '',
      providerUsed: 'Local',
      error:
        state.language === 'hi'
          ? 'AI कोड एडिट के लिए पहले Secrets में कोई API Key जोड़ें।'
          : 'Add at least one AI API Key in Secrets to run AI File Edits.',
    };
  }

  const failures: string[] = [];
  const emptyHistoryState: WorldState = {
    ...state,
    messages: [],
  };

  for (const provider of providers) {
    try {
      let rawText = '';
      switch (provider.id) {
        case 'gemini':
          rawText = await callGemini(
            provider,
            systemPrompt,
            userPrompt,
            emptyHistoryState
          );
          break;
        case 'groq':
          rawText = await callOpenAICompatible(
            'https://api.groq.com/openai/v1/chat/completions',
            provider,
            systemPrompt,
            userPrompt,
            emptyHistoryState
          );
          break;
        case 'nvidia':
          rawText = await callOpenAICompatible(
            'https://integrate.api.nvidia.com/v1/chat/completions',
            provider,
            systemPrompt,
            userPrompt,
            emptyHistoryState
          );
          break;
        case 'openrouter':
          rawText = await callOpenAICompatible(
            'https://openrouter.ai/api/v1/chat/completions',
            provider,
            systemPrompt,
            userPrompt,
            emptyHistoryState,
            {
              'HTTP-Referer':
                typeof window !== 'undefined'
                  ? window.location.origin
                  : 'https://sarfealam.autostudio',
              'X-Title': 'Sarfealam Auto-Studio',
            }
          );
          break;
        case 'cohere':
          rawText = await callCohere(
            provider,
            systemPrompt,
            userPrompt,
            emptyHistoryState
          );
          break;
      }

      return {
        ok: true,
        rawText,
        providerUsed: provider.label,
      };
    } catch (err) {
      const reason =
        err instanceof DOMException && err.name === 'AbortError'
          ? '15s timeout'
          : err instanceof Error
            ? err.message
            : 'failed';
      failures.push(`${provider.label} (${reason})`);
    }
  }

  return {
    ok: false,
    rawText: '',
    providerUsed: 'Local',
    error: `All configured AI providers failed (${failures.join(' · ')}).`,
  };
}

