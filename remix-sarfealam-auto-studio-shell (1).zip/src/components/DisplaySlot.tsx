import { Monitor, Maximize2, PictureInPicture2, Minimize2, FolderOpen } from 'lucide-react';
import {
  TARGET_ENGINES,
  type DisplayMode,
  type Language,
  type TargetEngine,
} from '../types/studio';

interface DisplaySlotProps {
  displayMode: DisplayMode;
  targetEngine: TargetEngine;
  language: Language;
  filesCount: number;
  assetsCount: number;
  currentStage: string;
  onDisplayModeChange: (mode: DisplayMode) => void;
}

const MODE_OPTIONS: {
  id: DisplayMode;
  label: string;
  activeClass: string;
  Icon: typeof Maximize2;
}[] = [
  {
    id: 'expanded',
    label: 'Expand',
    activeClass: 'bg-[#007AFF] text-white shadow-[0_2px_10px_rgba(0,122,255,0.28)]',
    Icon: Maximize2,
  },
  {
    id: 'floating',
    label: 'Float',
    activeClass: 'bg-[#5856D6] text-white shadow-[0_2px_10px_rgba(88,86,214,0.28)]',
    Icon: PictureInPicture2,
  },
  {
    id: 'collapsed',
    label: 'Collapse',
    activeClass: 'bg-[#F59E0B] text-white shadow-[0_2px_10px_rgba(245,158,11,0.28)]',
    Icon: Minimize2,
  },
];

export function DisplaySlot({
  displayMode,
  targetEngine,
  language,
  filesCount,
  assetsCount,
  currentStage,
  onDisplayModeChange,
}: DisplaySlotProps) {
  const engineLabel =
    TARGET_ENGINES.find((item) => item.value === targetEngine)?.label ?? 'Auto';

  return (
    <section
      aria-label="Display A Viewport Slot"
      className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_8px_30px_rgba(15,23,42,0.06)] rounded-2xl overflow-hidden transition-all duration-200"
    >
      {/* Header Row */}
      <div className="px-3 py-2.5 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div
            className="w-7 h-7 rounded-lg bg-[#007AFF]/10 text-[#007AFF] flex items-center justify-center shrink-0"
            aria-hidden="true"
          >
            <Monitor className="w-3.5 h-3.5 stroke-[2.2]" />
          </div>
          <div className="min-w-0">
            <h2 className="text-[12.5px] sm:text-[13px] font-bold text-[#0F172A] tracking-tight truncate whitespace-nowrap">
              Display A · Ready for Step 2
            </h2>
          </div>
        </div>

        {/* 3 Colorful Mode Pills */}
        <div
          className="inline-flex items-center gap-1 shrink-0"
          role="group"
          aria-label="Display A Mode"
        >
          {MODE_OPTIONS.map(({ id, label, activeClass, Icon }) => {
            const isActive = displayMode === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => onDisplayModeChange(id)}
                aria-pressed={isActive}
                className={`inline-flex items-center gap-1 px-2.5 h-7 rounded-full text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  isActive
                    ? activeClass
                    : 'bg-slate-100/90 text-[#64748B] hover:text-[#0F172A] hover:bg-slate-200/70'
                }`}
              >
                <Icon className="w-3 h-3 shrink-0" aria-hidden="true" />
                <span>{label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Body based on displayMode */}
      {displayMode === 'expanded' && (
        <div className="px-3 pb-3">
          <div className="rounded-xl border border-dashed border-slate-300/90 bg-gradient-to-br from-[#F7FAFF] via-white to-[#F5F4FF] p-3.5 min-h-[128px] lg:min-h-[260px] flex flex-col justify-between gap-3">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="text-[12.5px] font-semibold text-[#0F172A]">
                  {language === 'hi'
                    ? 'फ्लोटिंग डिस्प्ले A और फाइल ड्रॉअर स्लॉट'
                    : 'Floating Display A + File Drawer Slot'}
                </p>
                <p className="text-[11.5px] text-[#64748B] mt-0.5 leading-relaxed">
                  {language === 'hi'
                    ? 'स्टेप 2 में लाइव प्रीव्यू कैनवास और वर्चुअल फाइल ड्रॉअर यहाँ माउंट होगा।'
                    : 'Mounted cleanly in Step 2 for live preview canvas and virtual file inspection.'}
                </p>
              </div>
              <div className="w-8 h-8 rounded-xl bg-[#5856D6]/10 text-[#5856D6] flex items-center justify-center shrink-0">
                <FolderOpen className="w-4 h-4" aria-hidden="true" />
              </div>
            </div>

            <div className="pt-2.5 border-t border-slate-200/75 flex flex-wrap items-center justify-between gap-x-3 gap-y-1 text-[11.5px] text-[#64748B]">
              <div className="flex items-center gap-2 min-w-0">
                <span className="font-medium text-[#0F172A] truncate">
                  {currentStage}
                </span>
                <span aria-hidden="true">·</span>
                <span className="whitespace-nowrap">{engineLabel}</span>
              </div>
              <div className="flex items-center gap-2 font-mono text-[11px] tabular-nums shrink-0">
                <span>{filesCount} files</span>
                <span aria-hidden="true">/</span>
                <span>{assetsCount} assets</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {displayMode === 'floating' && (
        <div className="px-3 pb-3">
          <div className="rounded-xl border border-[#5856D6]/25 bg-gradient-to-r from-[#5856D6]/8 via-white to-[#007AFF]/8 px-3 py-2.5 flex items-center justify-between gap-2 shadow-xs">
            <div className="min-w-0">
              <p className="text-[12px] font-semibold text-[#0F172A] truncate">
                {language === 'hi'
                  ? 'फ्लोटिंग मोड सक्रिय'
                  : 'Floating PiP Slot Active'}
              </p>
              <p className="text-[11px] text-[#64748B] truncate">
                {engineLabel} · {currentStage}
              </p>
            </div>
            <span className="font-mono text-[11px] font-medium text-[#5856D6] tabular-nums whitespace-nowrap shrink-0">
              {filesCount} files
            </span>
          </div>
        </div>
      )}
    </section>
  );
}
