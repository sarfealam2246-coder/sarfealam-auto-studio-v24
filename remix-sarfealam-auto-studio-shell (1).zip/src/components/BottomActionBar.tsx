import {
  KeyRound,
  FileCode2,
  Archive,
  ShieldCheck,
  Camera,
  Pause,
  Play,
  Radio,
  CheckCircle2,
  PackageCheck,
  Home,
} from 'lucide-react';
import type { Language, PanelId, WorldState } from '../types/studio';

interface BottomActionBarProps {
  language: Language;
  activePanel: PanelId;
  paused: boolean;
  liveActive: boolean;
  world: WorldState;
  onSelectPanel: (panel: PanelId) => void;
  onTogglePause: () => void;
  onToggleLive: () => void;
  onApproveOk: () => void;
  onOpenApk: () => void;
  onGoHome: () => void;
}

const QUICK_PANELS: {
  id: Exclude<PanelId, 'none'>;
  label: string;
  Icon: typeof KeyRound;
  accentText: string;
  activeClass: string;
  summary: (world: WorldState) => string;
}[] = [
  {
    id: 'secrets',
    label: 'Secrets',
    Icon: KeyRound,
    accentText: 'text-[#D97706]',
    activeClass: 'bg-[#F59E0B] text-white border-[#F59E0B] shadow-xs',
    summary: (w) =>
      w.secrets.geminiApiKey || w.secrets.githubToken
        ? 'Local keys stored'
        : 'Zero-server local vault ready',
  },
  {
    id: 'code',
    label: 'Code',
    Icon: FileCode2,
    accentText: 'text-[#007AFF]',
    activeClass: 'bg-[#007AFF] text-white border-[#007AFF] shadow-xs',
    summary: (w) => `${w.files.length} virtual files tracked`,
  },
  {
    id: 'vault',
    label: 'Vault',
    Icon: Archive,
    accentText: 'text-[#10B981]',
    activeClass: 'bg-[#10B981] text-white border-[#10B981] shadow-xs',
    summary: (w) => `${w.selectedAssets.length} selected assets`,
  },
  {
    id: 'admin',
    label: 'Admin',
    Icon: ShieldCheck,
    accentText: 'text-[#5856D6]',
    activeClass: 'bg-[#5856D6] text-white border-[#5856D6] shadow-xs',
    summary: (w) => `${w.memoryRules.length} memory rules configured`,
  },
  {
    id: 'camera',
    label: 'Camera',
    Icon: Camera,
    accentText: 'text-[#FF3B30]',
    activeClass: 'bg-[#FF3B30] text-white border-[#FF3B30] shadow-xs',
    summary: (w) => `Mode: ${w.mode.toUpperCase()} · Vision slot standby`,
  },
];

export function BottomActionBar({
  language,
  activePanel,
  paused,
  liveActive,
  world: _world,
  onSelectPanel,
  onTogglePause,
  onToggleLive,
  onApproveOk,
  onOpenApk,
  onGoHome,
}: BottomActionBarProps) {
  return (
    <>
      {/* Fixed Bottom Dock: Quick Panel Strip + 5-Button Bottom Bar */}
      <nav
        aria-label="Studio Controls"
        className="fixed bottom-0 left-0 right-0 z-30 w-full bg-white/90 backdrop-blur-xl border-t border-slate-200/85 shadow-[0_-8px_28px_rgba(15,23,42,0.07)]"
      >
        <div className="max-w-5xl mx-auto px-2 sm:px-5 pt-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] flex flex-col gap-1.5">
          {/* Quick Panel Strip (5 items fitting 360px cleanly) */}
          <div className="grid grid-cols-5 gap-1 w-full">
            {QUICK_PANELS.map(({ id, label, Icon, accentText, activeClass }) => {
              const isSelected = activePanel === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onSelectPanel(isSelected ? 'none' : id)}
                  aria-pressed={isSelected}
                  className={`h-8 px-1 rounded-lg border inline-flex items-center justify-center gap-1 text-[10.5px] sm:text-[11.5px] font-semibold transition-all whitespace-nowrap min-w-0 cursor-pointer active:scale-[0.97] ${
                    isSelected
                      ? activeClass
                      : 'bg-slate-50/90 border-slate-200/75 text-[#0F172A] hover:bg-slate-100'
                  }`}
                >
                  <Icon
                    className={`w-3 h-3 shrink-0 ${
                      isSelected ? 'text-white' : accentText
                    }`}
                    aria-hidden="true"
                  />
                  <span className="truncate">{label}</span>
                </button>
              );
            })}
          </div>

          {/* Fixed 5-Button Bottom Bar fitting 360px without clipping */}
          <div className="grid grid-cols-5 gap-1 w-full">
            {/* Pause / Resume */}
            <button
              type="button"
              onClick={onTogglePause}
              aria-pressed={paused}
              className={`h-11 px-1 rounded-xl border inline-flex items-center justify-center gap-1 text-[10.5px] sm:text-[12px] font-semibold transition-all whitespace-nowrap min-w-0 cursor-pointer active:scale-[0.97] ${
                paused
                  ? 'bg-gradient-to-r from-[#10B981] to-[#059669] border-[#10B981] text-white shadow-[0_3px_14px_rgba(16,185,129,0.32)]'
                  : 'bg-[#F59E0B]/12 border-[#F59E0B]/35 text-[#B45309] hover:bg-[#F59E0B]/20'
              }`}
            >
              {paused ? (
                <Play className="w-3.5 h-3.5 shrink-0 fill-current" aria-hidden="true" />
              ) : (
                <Pause
                  className="w-3.5 h-3.5 shrink-0 text-[#D97706]"
                  aria-hidden="true"
                />
              )}
              <span className="truncate">{paused ? 'Resume' : 'Pause'}</span>
            </button>

            {/* Live */}
            <button
              type="button"
              onClick={onToggleLive}
              aria-pressed={liveActive}
              className={`h-11 px-1 rounded-xl border inline-flex items-center justify-center gap-1 text-[10.5px] sm:text-[12px] font-semibold transition-all whitespace-nowrap min-w-0 cursor-pointer active:scale-[0.97] ${
                liveActive
                  ? 'bg-gradient-to-r from-[#10B981] to-[#007AFF] border-[#007AFF] text-white shadow-[0_3px_14px_rgba(0,122,255,0.3)]'
                  : 'bg-white border-slate-200/90 text-[#0F172A] hover:bg-slate-50'
              }`}
            >
              <Radio
                className={`w-3.5 h-3.5 shrink-0 ${
                  liveActive ? 'text-white' : 'text-[#007AFF]'
                }`}
                aria-hidden="true"
              />
              <span className="truncate">{liveActive ? 'Live' : 'Voice'}</span>
            </button>

            {/* OK (Approve pending edits/selections or advance pipeline stage) */}
            <button
              type="button"
              onClick={onApproveOk}
              title={
                language === 'hi'
                  ? 'बदलाव मंजूर करें या अगला स्टेज चलाएँ'
                  : 'Approve pending edits/assets or advance stage'
              }
              className="h-11 px-1 rounded-xl bg-gradient-to-r from-[#10B981] to-[#059669] hover:brightness-105 text-white border border-[#10B981] shadow-[0_3px_12px_rgba(16,185,129,0.28)] inline-flex items-center justify-center gap-1 text-[11px] sm:text-[12px] font-bold transition-all whitespace-nowrap min-w-0 cursor-pointer active:scale-[0.97]"
            >
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span className="truncate">OK</span>
            </button>

            {/* APK (Opens Admin & APK Release Hub) */}
            <button
              type="button"
              onClick={onOpenApk}
              aria-pressed={activePanel === 'admin'}
              className={`h-11 px-1 rounded-xl border inline-flex items-center justify-center gap-1 text-[11px] sm:text-[12px] font-bold transition-all whitespace-nowrap min-w-0 cursor-pointer active:scale-[0.97] ${
                activePanel === 'admin'
                  ? 'bg-gradient-to-r from-[#5856D6] to-[#007AFF] border-[#5856D6] text-white shadow-[0_3px_12px_rgba(88,86,214,0.32)]'
                  : 'bg-[#5856D6]/10 border-[#5856D6]/30 text-[#5856D6] hover:bg-[#5856D6]/18'
              }`}
            >
              <PackageCheck className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span className="truncate">APK</span>
            </button>

            {/* Home */}
            <button
              type="button"
              onClick={onGoHome}
              className={`h-11 px-1 rounded-xl border inline-flex items-center justify-center gap-1 text-[10.5px] sm:text-[12px] font-semibold transition-all whitespace-nowrap min-w-0 cursor-pointer active:scale-[0.97] ${
                activePanel === 'none'
                  ? 'bg-[#007AFF]/10 border-[#007AFF]/30 text-[#007AFF]'
                  : 'bg-white border-slate-200/90 text-[#0F172A] hover:bg-slate-50'
              }`}
            >
              <Home className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span className="truncate">Home</span>
            </button>
          </div>
        </div>
      </nav>
    </>
  );
}
