import { useCallback, useEffect, useRef, useState, type ChangeEvent } from 'react';
import {
  Camera,
  CameraOff,
  SwitchCamera,
  Aperture,
  ImagePlus,
  Sparkles,
  Wand2,
  X,
  Loader2,
  Eye,
  AlertCircle,
  CheckCircle2,
  Mic,
} from 'lucide-react';
import {
  analyzeImageWithGemini,
  generateConceptVisual,
} from '../services/visionService';
import type {
  Language,
  StudioSecrets,
  UserMemoryRule,
} from '../types/studio';

interface CameraVisionPanelProps {
  open: boolean;
  language: Language;
  secrets: StudioSecrets;
  memoryRules: UserMemoryRule[];
  liveActive: boolean;
  onVisionMessage: (text: string, providerUsed: string) => void;
  onOpenSecrets: () => void;
  onClose: () => void;
}

type PreviewOrigin = 'capture' | 'upload' | 'concept';

export function CameraVisionPanel({
  open,
  language,
  secrets,
  memoryRules,
  liveActive,
  onVisionMessage,
  onOpenSecrets,
  onClose,
}: CameraVisionPanelProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const [previewDataUrl, setPreviewDataUrl] = useState<string | null>(null);
  const [previewOrigin, setPreviewOrigin] = useState<PreviewOrigin>('capture');
  const [prompt, setPrompt] = useState('');

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [visionReply, setVisionReply] = useState<{
    ok: boolean;
    text: string;
    badge: string;
    durationMs: number;
    note?: string;
  } | null>(null);

  const stopCameraTracks = useCallback(() => {
    const stream = streamRef.current;
    if (stream) {
      for (const track of stream.getTracks()) {
        try {
          track.stop();
        } catch {
          // ignore track cleanup errors
        }
      }
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  }, []);

  // Mandatory cleanup on panel close or component unmount
  useEffect(() => {
    if (!open) {
      stopCameraTracks();
    }
  }, [open, stopCameraTracks]);

  useEffect(() => {
    return () => {
      stopCameraTracks();
    };
  }, [stopCameraTracks]);

  // Attach MediaStream whenever cameraActive becomes true
  useEffect(() => {
    if (cameraActive && videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
      void videoRef.current.play().catch(() => {});
    }
  }, [cameraActive]);

  const startCamera = useCallback(
    async (targetFacing: 'environment' | 'user' = facingMode) => {
      setCameraError(null);
      stopCameraTracks();

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCameraError(
          language === 'hi'
            ? 'इस ब्राउज़र/WebView में कैमरा उपलब्ध नहीं है। Upload Photo का उपयोग करें।'
            : 'Camera access is unavailable in this browser/WebView. Use Upload Photo instead.'
        );
        return;
      }

      try {
        // MANDATORY: audio: false so camera NEVER steals the microphone from Gemini Live Voice
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: targetFacing } },
          audio: false,
        });
        streamRef.current = stream;
        setCameraActive(true);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }
      } catch (err) {
        stopCameraTracks();
        const reason =
          err instanceof Error && err.message
            ? err.message
            : 'Camera permission denied.';
        setCameraError(reason);
      }
    },
    [facingMode, language, stopCameraTracks]
  );

  const handleFlipCamera = useCallback(() => {
    const nextFacing = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextFacing);
    if (cameraActive) {
      void startCamera(nextFacing);
    }
  }, [cameraActive, facingMode, startCamera]);

  const captureVideoFrame = useCallback((): string | null => {
    const video = videoRef.current;
    if (!video || !cameraActive || video.videoWidth === 0 || video.videoHeight === 0) {
      return null;
    }
    const maxWidth = 1024;
    const scale = Math.min(1, maxWidth / video.videoWidth);
    const width = Math.max(1, Math.round(video.videoWidth * scale));
    const height = Math.max(1, Math.round(video.videoHeight * scale));

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, width, height);
    return canvas.toDataURL('image/jpeg', 0.85);
  }, [cameraActive]);

  const runAnalysisOnImage = useCallback(
    async (dataUrl: string) => {
      if (isAnalyzing || isGenerating) return;
      setIsAnalyzing(true);
      setCameraError(null);

      try {
        const res = await analyzeImageWithGemini({
          base64DataUrl: dataUrl,
          prompt,
          geminiKey: secrets.geminiApiKey,
          geminiModel: secrets.geminiModel,
          language,
          memoryRules,
        });

        setVisionReply({
          ok: res.ok,
          text: res.text,
          badge: res.modelUsed,
          durationMs: res.durationMs,
        });

        if (res.ok) {
          onVisionMessage(
            `[Vision Eye] ${res.text}`,
            `Vision (${res.modelUsed})`
          );
        }
      } finally {
        setIsAnalyzing(false);
      }
    },
    [
      isAnalyzing,
      isGenerating,
      language,
      memoryRules,
      onVisionMessage,
      prompt,
      secrets.geminiApiKey,
      secrets.geminiModel,
    ]
  );

  const handleCaptureAndAnalyze = useCallback(() => {
    const frame = captureVideoFrame();
    if (!frame) {
      setCameraError(
        language === 'hi'
          ? 'फ्रेम कैप्चर करने के लिए पहले Start Camera दबाएँ।'
          : 'Tap Start Camera first to capture a live frame.'
      );
      return;
    }
    setPreviewDataUrl(frame);
    setPreviewOrigin('capture');
    void runAnalysisOnImage(frame);
  }, [captureVideoFrame, language, runAnalysisOnImage]);

  const handleAnalyzeCurrent = useCallback(() => {
    if (previewDataUrl) {
      void runAnalysisOnImage(previewDataUrl);
      return;
    }
    if (cameraActive) {
      handleCaptureAndAnalyze();
      return;
    }
    setCameraError(
      language === 'hi'
        ? 'पहले कैमरा कैप्चर करें या गैलरी से फ़ोटो अपलोड करें।'
        : 'Capture a camera frame or upload a photo first.'
    );
  }, [cameraActive, handleCaptureAndAnalyze, language, previewDataUrl, runAnalysisOnImage]);

  const handleUploadPhoto = useCallback((e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setCameraError(null);
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPreviewDataUrl(reader.result);
        setPreviewOrigin('upload');
        setVisionReply(null);
      }
    };
    reader.onerror = () => {
      setCameraError('Could not read the selected image file.');
    };
    reader.readAsDataURL(file);
  }, []);

  const handleGenerateVisual = useCallback(async () => {
    if (isGenerating || isAnalyzing) return;
    setIsGenerating(true);
    setCameraError(null);

    try {
      const effectivePrompt =
        prompt.trim() ||
        'Indian village 3D offroad truck racing scene, sunny daylight, Apple-clean vibrant colors';
      const res = await generateConceptVisual(
        effectivePrompt,
        secrets.geminiApiKey
      );
      setPreviewDataUrl(res.dataUrl);
      setPreviewOrigin('concept');

      const sourceBadge =
        res.source === 'gemini-image'
          ? 'Gemini Image'
          : res.source === 'imagen-3'
            ? 'Imagen 3'
            : 'Local Canvas';

      setVisionReply({
        ok: res.ok,
        text: res.caption,
        badge: sourceBadge,
        durationMs: res.durationMs,
        note: res.note,
      });

      onVisionMessage(
        `[Concept Visual · ${sourceBadge}] ${res.caption}`,
        sourceBadge
      );
    } finally {
      setIsGenerating(false);
    }
  }, [isAnalyzing, isGenerating, onVisionMessage, prompt, secrets.geminiApiKey]);

  const handleClose = () => {
    stopCameraTracks();
    onClose();
  };

  if (!open) return null;

  const busy = isAnalyzing || isGenerating;
  const hasGeminiKey = Boolean(secrets.geminiApiKey?.trim());

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[3px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={handleClose}
      role="dialog"
      aria-modal="true"
      aria-label="Camera Vision Eye"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-full sm:max-w-xl mx-auto bg-[#F8FAFE]/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-14px_48px_rgba(15,23,42,0.18)] flex flex-col max-h-[90dvh] sm:max-h-[86dvh] overflow-hidden"
      >
        {/* Mobile Drag Handle */}
        <div className="pt-2.5 pb-1 flex justify-center sm:hidden shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-300/90" aria-hidden="true" />
        </div>

        {/* Sticky Sheet Header */}
        <div className="px-3.5 sm:px-5 py-2.5 bg-white/85 backdrop-blur-xl border-b border-slate-200/80 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#FF3B30] via-[#EC4899] to-[#5856D6] text-white flex items-center justify-center shadow-xs shrink-0"
              aria-hidden="true"
            >
              <Eye className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-[14px] sm:text-[15px] font-bold text-[#0F172A] tracking-tight truncate">
                {language === 'hi' ? 'कैमरा विज़न आई' : 'Camera Vision Eye'}
              </h2>
              <p className="text-[11px] font-medium text-[#64748B] truncate">
                {language === 'hi'
                  ? 'gemini-3.8-flash विज़न · कॉन्सेप्ट विज़ुअल'
                  : 'gemini-3.8-flash Vision · Concept Visuals'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {liveActive && (
              <span className="px-2 py-0.5 rounded-full bg-[#10B981]/12 border border-[#10B981]/30 text-[#047857] text-[10px] font-bold inline-flex items-center gap-1 whitespace-nowrap">
                <Mic className="w-2.5 h-2.5 shrink-0" aria-hidden="true" />
                <span>Mic Safe</span>
              </span>
            )}
            <button
              type="button"
              onClick={handleClose}
              aria-label="Close Camera Vision Eye"
              className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Vision Body */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-3 sm:px-5 pt-3 pb-8 flex flex-col gap-3">
          {/* Hidden Gallery File Picker */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleUploadPhoto}
            className="hidden"
          />

          {/* Live Camera Viewport / Image Preview Stage */}
          <div className="relative w-full aspect-[16/10] rounded-2xl bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A] border border-slate-200/80 overflow-hidden shadow-sm flex items-center justify-center">
            <video
              ref={videoRef}
              playsInline
              muted
              autoPlay
              className={`w-full h-full object-cover ${cameraActive ? 'block' : 'hidden'}`}
            />

            {!cameraActive && previewDataUrl && (
              <img
                src={previewDataUrl}
                alt="Vision Preview"
                className="w-full h-full object-contain bg-[#F3F6FB]"
              />
            )}

            {!cameraActive && !previewDataUrl && (
              <div className="flex flex-col items-center justify-center text-center px-4 gap-2">
                <div className="w-11 h-11 rounded-2xl bg-white/10 border border-white/15 text-white flex items-center justify-center">
                  <Camera className="w-5 h-5" aria-hidden="true" />
                </div>
                <p className="text-[12.5px] font-bold text-white">
                  {language === 'hi'
                    ? 'लाइव कैमरा शुरू करें या फ़ोटो अपलोड करें'
                    : 'Start Live Camera or Upload a Photo'}
                </p>
                <p className="text-[10.5px] text-slate-300 max-w-[260px] leading-relaxed">
                  {language === 'hi'
                    ? 'audio: false लॉक — Gemini Live माइक कभी बंद नहीं होगा।'
                    : 'Video-only stream (audio: false) keeps Gemini Live Voice uninterrupted.'}
                </p>
              </div>
            )}

            {/* Status Pill Overlay */}
            <div className="absolute top-2 left-2 flex items-center gap-1.5">
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold backdrop-blur-md border ${
                  cameraActive
                    ? 'bg-[#FF3B30]/85 border-white/25 text-white'
                    : previewDataUrl
                      ? 'bg-white/90 border-slate-200/80 text-[#0F172A]'
                      : 'bg-slate-900/70 border-white/15 text-slate-200'
                }`}
              >
                {cameraActive
                  ? `Live · ${facingMode === 'environment' ? 'Rear' : 'Front'}`
                  : previewDataUrl
                    ? previewOrigin === 'concept'
                      ? 'Concept Visual'
                      : previewOrigin === 'upload'
                        ? 'Gallery Upload'
                        : 'Captured Frame'
                    : 'Camera Standby'}
              </span>
            </div>

            {/* Thumbnail inset of last captured/generated image while camera is live */}
            {cameraActive && previewDataUrl && (
              <img
                src={previewDataUrl}
                alt="Last frame"
                className="absolute bottom-2 right-2 w-16 h-11 rounded-lg object-cover border-2 border-white shadow-md"
              />
            )}
          </div>

          {/* Camera & Upload Controls Grid (fits 360px cleanly) */}
          <div className="grid grid-cols-2 gap-1.5 w-full">
            <button
              type="button"
              onClick={() => (cameraActive ? stopCameraTracks() : void startCamera())}
              className={`h-9 px-2.5 rounded-xl border text-[11.5px] font-bold inline-flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap min-w-0 active:scale-[0.98] ${
                cameraActive
                  ? 'bg-[#FF3B30] border-[#FF3B30] text-white shadow-xs'
                  : 'bg-white border-slate-200/90 text-[#0F172A] hover:bg-slate-50'
              }`}
            >
              {cameraActive ? (
                <>
                  <CameraOff className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span className="truncate">Stop Camera</span>
                </>
              ) : (
                <>
                  <Camera className="w-3.5 h-3.5 text-[#FF3B30] shrink-0" aria-hidden="true" />
                  <span className="truncate">Start Camera</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleFlipCamera}
              className="h-9 px-2.5 rounded-xl bg-white border border-slate-200/90 hover:bg-slate-50 text-[#0F172A] text-[11.5px] font-semibold inline-flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap min-w-0 active:scale-[0.98]"
            >
              <SwitchCamera className="w-3.5 h-3.5 text-[#5856D6] shrink-0" aria-hidden="true" />
              <span className="truncate">
                Flip ({facingMode === 'environment' ? 'Rear' : 'Front'})
              </span>
            </button>

            <button
              type="button"
              onClick={handleCaptureAndAnalyze}
              disabled={!cameraActive || busy}
              className="h-9 px-2.5 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#EC4899] hover:brightness-105 disabled:opacity-45 text-white text-[11.5px] font-bold inline-flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer whitespace-nowrap min-w-0 active:scale-[0.98]"
            >
              <Aperture className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span className="truncate">Capture &amp; Analyze</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={busy}
              className="h-9 px-2.5 rounded-xl bg-white border border-slate-200/90 hover:bg-slate-50 disabled:opacity-50 text-[#0F172A] text-[11.5px] font-semibold inline-flex items-center justify-center gap-1.5 transition-all cursor-pointer whitespace-nowrap min-w-0 active:scale-[0.98]"
            >
              <ImagePlus className="w-3.5 h-3.5 text-[#10B981] shrink-0" aria-hidden="true" />
              <span className="truncate">Upload Photo</span>
            </button>
          </div>

          {/* Camera / Input Error Notice */}
          {cameraError && (
            <div className="rounded-xl bg-[#FF3B30]/10 border border-[#FF3B30]/25 px-3 py-2 flex items-center gap-2 text-[11.5px] font-medium text-[#B91C1C]">
              <AlertCircle className="w-4 h-4 shrink-0 text-[#DC2626]" aria-hidden="true" />
              <span className="min-w-0 break-words">{cameraError}</span>
            </div>
          )}

          {/* Vision Prompt + Analyze / Generate Buttons */}
          <div className="bg-white/85 backdrop-blur-xl border border-slate-200/80 rounded-2xl p-3 flex flex-col gap-2.5 shadow-[0_4px_16px_rgba(15,23,42,0.04)]">
            <label
              htmlFor="vision-prompt-input"
              className="text-[11.5px] font-bold text-[#0F172A] flex items-center justify-between gap-2"
            >
              <span>
                {language === 'hi'
                  ? 'विज़न या कॉन्सेप्ट प्रॉम्प्ट'
                  : 'Vision / Concept Prompt'}
              </span>
              {!hasGeminiKey && (
                <button
                  type="button"
                  onClick={() => {
                    stopCameraTracks();
                    onOpenSecrets();
                  }}
                  className="text-[10.5px] font-semibold text-[#D97706] hover:underline cursor-pointer"
                >
                  Add Gemini Key →
                </button>
              )}
            </label>

            <input
              id="vision-prompt-input"
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={
                language === 'hi'
                  ? 'जैसे: इस स्केच से 3D सीन या UI सुझाव बताओ...'
                  : 'e.g., Inspect this UI sketch or generate a village racer concept...'
              }
              className="w-full min-w-0 h-10 px-3 rounded-xl bg-[#F8FAFE] border border-slate-200/90 text-[12px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15"
            />

            {/* Quick Prompt Presets */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 studio-scroll w-full min-w-0">
              {[
                'Describe for 3D scene & assets',
                'Review UI layout & colors',
                'Indian village racer concept poster',
                'Low-poly truck game cover art',
              ].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setPrompt(preset)}
                  className="h-7 px-2.5 rounded-full bg-[#F3F6FB] hover:bg-[#E7EEF9] border border-slate-200/80 text-[10.5px] font-semibold text-[#475569] shrink-0 whitespace-nowrap cursor-pointer"
                >
                  {preset}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-1.5 w-full">
              <button
                type="button"
                onClick={handleAnalyzeCurrent}
                disabled={busy}
                className="h-10 px-2.5 rounded-xl bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-60 text-white text-[11.5px] font-bold inline-flex items-center justify-center gap-1.5 shadow-[0_4px_14px_rgba(0,122,255,0.24)] transition-all cursor-pointer whitespace-nowrap min-w-0 active:scale-[0.98]"
              >
                {isAnalyzing ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                )}
                <span className="truncate">
                  {isAnalyzing ? 'Analyzing...' : 'Analyze Image'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => void handleGenerateVisual()}
                disabled={busy}
                className="h-10 px-2.5 rounded-xl bg-gradient-to-r from-[#10B981] via-[#0EA5E9] to-[#5856D6] hover:brightness-105 disabled:opacity-60 text-white text-[11.5px] font-bold inline-flex items-center justify-center gap-1.5 shadow-[0_4px_14px_rgba(16,185,129,0.24)] transition-all cursor-pointer whitespace-nowrap min-w-0 active:scale-[0.98]"
              >
                {isGenerating ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                ) : (
                  <Wand2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                )}
                <span className="truncate">
                  {isGenerating ? 'Generating...' : 'Generate Visual'}
                </span>
              </button>
            </div>
          </div>

          {/* Vision Response Card */}
          {visionReply && (
            <div
              className={`rounded-2xl border p-3 flex flex-col gap-1.5 shadow-2xs ${
                visionReply.ok
                  ? 'bg-white/90 border-[#10B981]/30'
                  : 'bg-[#FFF5F5] border-[#FF3B30]/30'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span
                  className={`inline-flex items-center gap-1 text-[11px] font-bold ${
                    visionReply.ok ? 'text-[#047857]' : 'text-[#DC2626]'
                  }`}
                >
                  {visionReply.ok ? (
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  ) : (
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  )}
                  <span>{visionReply.badge}</span>
                </span>
                <span className="text-[10px] font-mono text-[#64748B] tabular-nums">
                  {visionReply.durationMs}ms
                </span>
              </div>

              <p className="text-[12px] leading-relaxed text-[#0F172A] whitespace-pre-wrap break-words">
                {visionReply.text}
              </p>

              {visionReply.note && (
                <p className="text-[10.5px] text-[#64748B] pt-1 border-t border-slate-200/70">
                  {visionReply.note}
                </p>
              )}
            </div>
          )}
        </div>

        {/* Compact Footer */}
        <div className="px-3.5 sm:px-5 py-2 bg-white/90 border-t border-slate-200/80 flex items-center justify-between gap-2 text-[10.5px] text-[#64748B] shrink-0 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
          <span className="truncate">
            {language === 'hi'
              ? 'विज़न सारांश CommandCenter में सहेजा जाता है'
              : 'Vision summaries append directly to CommandCenter'}
          </span>
          <span className="font-mono text-[#007AFF] font-semibold shrink-0">
            audio: false
          </span>
        </div>
      </div>
    </div>
  );
}
