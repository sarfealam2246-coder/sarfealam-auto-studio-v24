import { useEffect, useRef, useState } from 'react';
import {
  KeyRound,
  Eye,
  EyeOff,
  X,
  Github,
  Box,
  Database,
  Copy,
  Check,
  Lock,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  Save,
} from 'lucide-react';
import type { Language, StudioSecrets } from '../types/studio';
import {
  DEFAULT_2026_MODELS,
  DEFAULT_ASSET_VAULT_URL,
  DEFAULT_TARGET_REPO,
  STUDIO_SUPABASE_SQL,
  saveSecrets,
  verifyAssetVault,
  type VaultVerifyResult,
} from '../services/secretsService';

interface SecretsPanelProps {
  open: boolean;
  secrets: StudioSecrets;
  language: Language;
  onSave: (updated: StudioSecrets) => void;
  onClose: () => void;
}

type SecretVisibilityKey =
  | 'gemini'
  | 'nvidia'
  | 'groq'
  | 'openRouter'
  | 'cohere'
  | 'github'
  | 'studioSupabase'
  | 'appsSupabase';

type SaveSlotKey =
  | 'gemini'
  | 'nvidia'
  | 'groq'
  | 'openRouter'
  | 'cohere'
  | 'githubVault'
  | 'studioDb'
  | 'appsDb';

export function SecretsPanel({
  open,
  secrets,
  language,
  onSave,
  onClose,
}: SecretsPanelProps) {
  const [draft, setDraft] = useState<StudioSecrets>(secrets);
  const [visible, setVisible] = useState<Record<SecretVisibilityKey, boolean>>({
    gemini: false,
    nvidia: false,
    groq: false,
    openRouter: false,
    cohere: false,
    github: false,
    studioSupabase: false,
    appsSupabase: false,
  });
  const [verifying, setVerifying] = useState(false);
  const [verifyResult, setVerifyResult] = useState<VaultVerifyResult | null>(null);
  const [sqlCopied, setSqlCopied] = useState(false);
  const [savedSlots, setSavedSlots] = useState<Partial<Record<SaveSlotKey, boolean>>>({});
  const saveTimersRef = useRef<Partial<Record<SaveSlotKey, number>>>({});
  const wasOpenRef = useRef(false);

  useEffect(() => {
    if (open && !wasOpenRef.current) {
      setDraft(secrets);
      setVerifyResult(null);
      setSqlCopied(false);
      setSavedSlots({});
    }
    wasOpenRef.current = open;
  }, [open, secrets]);

  useEffect(() => {
    const timers = saveTimersRef.current;
    return () => {
      Object.values(timers).forEach((timerId) => {
        if (typeof timerId === 'number') {
          window.clearTimeout(timerId);
        }
      });
    };
  }, []);

  if (!open) return null;

  const toggleShow = (key: SecretVisibilityKey) => {
    setVisible((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const updateField = <K extends keyof StudioSecrets>(
    field: K,
    value: StudioSecrets[K]
  ) => {
    setDraft((prev) => ({ ...prev, [field]: value }));
  };

  const savePartialSecrets = (slot: SaveSlotKey) => {
    const saved = saveSecrets(draft);
    onSave(saved);
    setSavedSlots((prev) => ({ ...prev, [slot]: true }));
    const existingTimer = saveTimersRef.current[slot];
    if (typeof existingTimer === 'number') {
      window.clearTimeout(existingTimer);
    }
    saveTimersRef.current[slot] = window.setTimeout(() => {
      setSavedSlots((prev) => ({ ...prev, [slot]: false }));
      delete saveTimersRef.current[slot];
    }, 2000);
  };

  const handleVerifyVault = async () => {
    setVerifying(true);
    setVerifyResult(null);
    const result = await verifyAssetVault(
      draft.assetVaultUrl ?? DEFAULT_ASSET_VAULT_URL
    );
    setVerifyResult(result);
    setVerifying(false);
  };

  const handleCopySql = async () => {
    try {
      await navigator.clipboard.writeText(STUDIO_SUPABASE_SQL);
      setSqlCopied(true);
      window.setTimeout(() => setSqlCopied(false), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = STUDIO_SUPABASE_SQL;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setSqlCopied(true);
      window.setTimeout(() => setSqlCopied(false), 2000);
    }
  };

  const handleSaveAndLock = () => {
    const saved = saveSecrets(draft);
    onSave(saved);
    onClose();
  };

  const inputBaseClass =
    'w-full min-w-0 h-10 px-3 rounded-xl bg-white border border-slate-200/90 text-[12px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15 transition-all';

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[3px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="API Keys & Vault Secrets"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-full sm:max-w-xl mx-auto bg-[#F8FAFE]/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-14px_48px_rgba(15,23,42,0.18)] flex flex-col max-h-[90dvh] sm:max-h-[86dvh] overflow-hidden"
      >
        {/* Drag Handle (mobile) */}
        <div className="pt-2.5 pb-1 flex justify-center sm:hidden shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-300/90" aria-hidden="true" />
        </div>

        {/* Sticky Sheet Header */}
        <div className="px-3.5 sm:px-5 py-2.5 bg-white/85 backdrop-blur-xl border-b border-slate-200/80 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#F59E0B] to-[#EA580C] text-white flex items-center justify-center shadow-xs shrink-0"
              aria-hidden="true"
            >
              <KeyRound className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-[14px] sm:text-[15px] font-bold text-[#0F172A] tracking-tight truncate">
                API Keys &amp; Vault Secrets
              </h2>
              <p className="text-[11px] font-medium text-[#64748B] truncate">
                {language === 'hi'
                  ? 'लोकल डिवाइस वॉल्ट · ज़ीरो-सर्वर स्टोरेज'
                  : 'Local device vault · Zero-server storage'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close API Keys and Vault Secrets"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Vertically Scrollable Form Body */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-3 sm:px-5 pt-3 pb-8 flex flex-col gap-3">
          {/* SECTION A: 5 AI Provider Keys */}
          <section className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_6px_22px_rgba(15,23,42,0.04)] rounded-2xl p-3 flex flex-col gap-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-6 h-6 rounded-lg bg-[#007AFF]/10 text-[#007AFF] flex items-center justify-center shrink-0">
                  <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                </span>
                <h3 className="text-[12.5px] font-bold text-[#0F172A] truncate">
                  Section A · 5 AI Provider Keys
                </h3>
              </div>
              <span className="text-[10.5px] font-mono font-semibold text-[#007AFF] shrink-0">
                2026 Models
              </span>
            </div>

            {/* 1. Google Gemini */}
            <div className="flex flex-col gap-1.5 pb-2.5 border-b border-slate-100">
              <div className="flex flex-wrap items-center justify-between gap-1">
                <label
                  htmlFor="secret-gemini-key"
                  className="text-[11.5px] font-bold text-[#0F172A]"
                >
                  1. Google Gemini API Key
                </label>
                <span className="px-2 py-0.5 rounded-md bg-[#007AFF]/10 text-[#007AFF] font-mono text-[10px] font-semibold">
                  {draft.geminiModel || DEFAULT_2026_MODELS.gemini}
                </span>
              </div>
              <div className="flex items-center gap-1.5 min-w-0">
                <div className="relative flex-1 min-w-0 flex items-center">
                  <input
                    id="secret-gemini-key"
                    type={visible.gemini ? 'text' : 'password'}
                    value={draft.geminiApiKey}
                    onChange={(e) => updateField('geminiApiKey', e.target.value)}
                    placeholder="AIza..."
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('gemini')}
                    aria-label={visible.gemini ? 'Hide Gemini key' : 'Show Gemini key'}
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.gemini ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => savePartialSecrets('gemini')}
                  aria-label="Save Google Gemini API Key"
                  className={`h-10 px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 ${
                    savedSlots.gemini
                      ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                      : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                  }`}
                >
                  {savedSlots.gemini ? (
                    <span>Saved ✓</span>
                  ) : (
                    <>
                      <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>Save</span>
                    </>
                  )}
                </button>
              </div>
              <p className="text-[10px] font-mono text-[#64748B] truncate">
                Live: {draft.geminiLiveModel || DEFAULT_2026_MODELS.geminiLive} · TTS:{' '}
                {draft.geminiTtsModel || DEFAULT_2026_MODELS.geminiTts}
              </p>
            </div>

            {/* 2. NVIDIA NIM */}
            <div className="flex flex-col gap-1.5 pb-2.5 border-b border-slate-100">
              <div className="flex flex-wrap items-center justify-between gap-1">
                <label
                  htmlFor="secret-nvidia-key"
                  className="text-[11.5px] font-bold text-[#0F172A]"
                >
                  2. NVIDIA NIM API Key
                </label>
                <span className="px-2 py-0.5 rounded-md bg-[#10B981]/12 text-[#047857] font-mono text-[10px] font-semibold truncate max-w-full">
                  {draft.nvidiaModel || DEFAULT_2026_MODELS.nvidia}
                </span>
              </div>
              <div className="flex items-center gap-1.5 min-w-0">
                <div className="relative flex-1 min-w-0 flex items-center">
                  <input
                    id="secret-nvidia-key"
                    type={visible.nvidia ? 'text' : 'password'}
                    value={draft.nvidiaApiKey ?? ''}
                    onChange={(e) => updateField('nvidiaApiKey', e.target.value)}
                    placeholder="nvapi-..."
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('nvidia')}
                    aria-label={visible.nvidia ? 'Hide NVIDIA key' : 'Show NVIDIA key'}
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.nvidia ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => savePartialSecrets('nvidia')}
                  aria-label="Save NVIDIA NIM API Key"
                  className={`h-10 px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 ${
                    savedSlots.nvidia
                      ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                      : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                  }`}
                >
                  {savedSlots.nvidia ? (
                    <span>Saved ✓</span>
                  ) : (
                    <>
                      <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>Save</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 3. Groq */}
            <div className="flex flex-col gap-1.5 pb-2.5 border-b border-slate-100">
              <div className="flex flex-wrap items-center justify-between gap-1">
                <label
                  htmlFor="secret-groq-key"
                  className="text-[11.5px] font-bold text-[#0F172A]"
                >
                  3. Groq API Key
                </label>
                <span className="px-2 py-0.5 rounded-md bg-[#F59E0B]/14 text-[#B45309] font-mono text-[10px] font-semibold">
                  {draft.groqModel || DEFAULT_2026_MODELS.groq}
                </span>
              </div>
              <div className="flex items-center gap-1.5 min-w-0">
                <div className="relative flex-1 min-w-0 flex items-center">
                  <input
                    id="secret-groq-key"
                    type={visible.groq ? 'text' : 'password'}
                    value={draft.groqApiKey ?? ''}
                    onChange={(e) => updateField('groqApiKey', e.target.value)}
                    placeholder="gsk_..."
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('groq')}
                    aria-label={visible.groq ? 'Hide Groq key' : 'Show Groq key'}
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.groq ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => savePartialSecrets('groq')}
                  aria-label="Save Groq API Key"
                  className={`h-10 px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 ${
                    savedSlots.groq
                      ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                      : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                  }`}
                >
                  {savedSlots.groq ? (
                    <span>Saved ✓</span>
                  ) : (
                    <>
                      <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>Save</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 4. OpenRouter */}
            <div className="flex flex-col gap-1.5 pb-2.5 border-b border-slate-100">
              <label
                htmlFor="secret-openrouter-key"
                className="text-[11.5px] font-bold text-[#0F172A]"
              >
                4. OpenRouter API Key
              </label>
              <div className="flex items-center gap-1.5 min-w-0">
                <div className="relative flex-1 min-w-0 flex items-center">
                  <input
                    id="secret-openrouter-key"
                    type={visible.openRouter ? 'text' : 'password'}
                    value={draft.openRouterApiKey ?? ''}
                    onChange={(e) => updateField('openRouterApiKey', e.target.value)}
                    placeholder="sk-or-v1-..."
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('openRouter')}
                    aria-label={
                      visible.openRouter ? 'Hide OpenRouter key' : 'Show OpenRouter key'
                    }
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.openRouter ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => savePartialSecrets('openRouter')}
                  aria-label="Save OpenRouter API Key"
                  className={`h-10 px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 ${
                    savedSlots.openRouter
                      ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                      : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                  }`}
                >
                  {savedSlots.openRouter ? (
                    <span>Saved ✓</span>
                  ) : (
                    <>
                      <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>Save</span>
                    </>
                  )}
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                <label
                  htmlFor="secret-openrouter-model"
                  className="text-[10.5px] font-semibold text-[#64748B] shrink-0"
                >
                  Model:
                </label>
                <input
                  id="secret-openrouter-model"
                  type="text"
                  value={draft.openRouterModel ?? DEFAULT_2026_MODELS.openRouter}
                  onChange={(e) => updateField('openRouterModel', e.target.value)}
                  className="flex-1 min-w-0 h-8 px-2.5 rounded-lg bg-[#F6F9FE] border border-slate-200/80 font-mono text-[11px] text-[#5856D6] font-semibold focus:outline-none focus:border-[#5856D6]"
                />
              </div>
            </div>

            {/* 5. Cohere */}
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="secret-cohere-key"
                className="text-[11.5px] font-bold text-[#0F172A]"
              >
                5. Cohere API Key
              </label>
              <div className="flex items-center gap-1.5 min-w-0">
                <div className="relative flex-1 min-w-0 flex items-center">
                  <input
                    id="secret-cohere-key"
                    type={visible.cohere ? 'text' : 'password'}
                    value={draft.cohereApiKey ?? ''}
                    onChange={(e) => updateField('cohereApiKey', e.target.value)}
                    placeholder="cohere-api-key..."
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('cohere')}
                    aria-label={visible.cohere ? 'Hide Cohere key' : 'Show Cohere key'}
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.cohere ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => savePartialSecrets('cohere')}
                  aria-label="Save Cohere API Key"
                  className={`h-10 px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-95 ${
                    savedSlots.cohere
                      ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                      : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                  }`}
                >
                  {savedSlots.cohere ? (
                    <span>Saved ✓</span>
                  ) : (
                    <>
                      <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>Save</span>
                    </>
                  )}
                </button>
              </div>
              <div className="flex items-center gap-1.5">
                <label
                  htmlFor="secret-cohere-model"
                  className="text-[10.5px] font-semibold text-[#64748B] shrink-0"
                >
                  Model:
                </label>
                <input
                  id="secret-cohere-model"
                  type="text"
                  value={draft.cohereModel ?? DEFAULT_2026_MODELS.cohere}
                  onChange={(e) => updateField('cohereModel', e.target.value)}
                  className="flex-1 min-w-0 h-8 px-2.5 rounded-lg bg-[#F6F9FE] border border-slate-200/80 font-mono text-[11px] text-[#0F172A] font-semibold focus:outline-none focus:border-[#007AFF]"
                />
              </div>
            </div>
          </section>

          {/* SECTION B: GitHub & 3D Asset Vault */}
          <section className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_6px_22px_rgba(15,23,42,0.04)] rounded-2xl p-3 flex flex-col gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-6 h-6 rounded-lg bg-[#10B981]/12 text-[#10B981] flex items-center justify-center shrink-0">
                <Github className="w-3.5 h-3.5" aria-hidden="true" />
              </span>
              <h3 className="text-[12.5px] font-bold text-[#0F172A] truncate">
                Section B · GitHub &amp; 3D Asset Vault
              </h3>
            </div>

            {/* GitHub PAT */}
            <div className="flex flex-col gap-1">
              <label
                htmlFor="secret-github-pat"
                className="text-[11.5px] font-bold text-[#0F172A]"
              >
                GitHub PAT
              </label>
              <div className="relative flex items-center">
                <input
                  id="secret-github-pat"
                  type={visible.github ? 'text' : 'password'}
                  value={draft.githubToken}
                  onChange={(e) => updateField('githubToken', e.target.value)}
                  placeholder="github_pat_... or ghp_..."
                  autoComplete="off"
                  className={`${inputBaseClass} pr-10 font-mono`}
                />
                <button
                  type="button"
                  onClick={() => toggleShow('github')}
                  aria-label={visible.github ? 'Hide GitHub PAT' : 'Show GitHub PAT'}
                  className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                >
                  {visible.github ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Target GitHub Repo */}
            <div className="flex flex-col gap-1">
              <label
                htmlFor="secret-github-repo"
                className="text-[11.5px] font-bold text-[#0F172A]"
              >
                Target GitHub Repo (owner/repo)
              </label>
              <input
                id="secret-github-repo"
                type="text"
                value={draft.targetRepo ?? DEFAULT_TARGET_REPO}
                onChange={(e) => updateField('targetRepo', e.target.value)}
                placeholder={DEFAULT_TARGET_REPO}
                className={`${inputBaseClass} font-mono`}
              />
            </div>

            {/* 3D Asset Vault catalog.json URL + Verify Vault */}
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="secret-vault-url"
                className="text-[11.5px] font-bold text-[#0F172A] flex items-center gap-1.5"
              >
                <Box className="w-3.5 h-3.5 text-[#5856D6] shrink-0" aria-hidden="true" />
                <span>3D Asset Vault catalog.json URL</span>
              </label>
              <input
                id="secret-vault-url"
                type="url"
                value={draft.assetVaultUrl ?? DEFAULT_ASSET_VAULT_URL}
                onChange={(e) => {
                  updateField('assetVaultUrl', e.target.value);
                  if (verifyResult) setVerifyResult(null);
                }}
                placeholder={DEFAULT_ASSET_VAULT_URL}
                className={`${inputBaseClass} font-mono text-[11px]`}
              />

              <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleVerifyVault}
                    disabled={verifying}
                    className="h-9 px-3 rounded-xl bg-gradient-to-r from-[#10B981] to-[#007AFF] hover:brightness-105 disabled:opacity-60 text-white text-[11.5px] font-semibold inline-flex items-center gap-1.5 shadow-xs transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
                  >
                    {verifying ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
                    ) : (
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    )}
                    <span>{verifying ? 'Verifying...' : 'Verify Vault'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => savePartialSecrets('githubVault')}
                    className={`h-9 px-3 rounded-xl border text-[11.5px] font-bold inline-flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer active:scale-[0.98] ${
                      savedSlots.githubVault
                        ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                        : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                    }`}
                  >
                    {savedSlots.githubVault ? (
                      <span>Saved ✓</span>
                    ) : (
                      <>
                        <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span>Save GitHub &amp; Vault</span>
                      </>
                    )}
                  </button>
                </div>

                {verifyResult && (
                  <div
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold max-w-full ${
                      verifyResult.ok
                        ? 'bg-[#10B981]/12 text-[#047857]'
                        : 'bg-[#FF3B30]/10 text-[#DC2626]'
                    }`}
                  >
                    {verifyResult.ok ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span className="font-mono tabular-nums truncate">
                          Verified · {verifyResult.count} assets
                        </span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span className="truncate">{verifyResult.error}</span>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* SECTION C: Dual Isolated Supabase */}
          <section className="bg-white/85 backdrop-blur-xl border border-slate-200/80 shadow-[0_6px_22px_rgba(15,23,42,0.04)] rounded-2xl p-3 flex flex-col gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-6 h-6 rounded-lg bg-[#5856D6]/12 text-[#5856D6] flex items-center justify-center shrink-0">
                <Database className="w-3.5 h-3.5" aria-hidden="true" />
              </span>
              <h3 className="text-[12.5px] font-bold text-[#0F172A] truncate">
                Section C · Dual Isolated Supabase
              </h3>
            </div>

            {/* 1. Studio Supabase (Memory & Skills Only) */}
            <div className="rounded-xl bg-[#F6F9FE] border border-[#5856D6]/20 p-2.5 flex flex-col gap-2">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11.5px] font-bold text-[#0F172A]">
                  Studio Supabase (Memory &amp; Skills Only)
                </span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    type="button"
                    onClick={handleCopySql}
                    className={`h-7 px-2.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 transition-all whitespace-nowrap cursor-pointer ${
                      sqlCopied
                        ? 'bg-[#10B981] text-white'
                        : 'bg-[#5856D6] hover:bg-[#4947C2] text-white'
                    }`}
                  >
                    {sqlCopied ? (
                      <Check className="w-3 h-3 shrink-0" aria-hidden="true" />
                    ) : (
                      <Copy className="w-3 h-3 shrink-0" aria-hidden="true" />
                    )}
                    <span>{sqlCopied ? 'Copied!' : 'Copy Studio SQL'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => savePartialSecrets('studioDb')}
                    className={`h-7 px-2.5 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-95 ${
                      savedSlots.studioDb
                        ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                        : 'bg-[#007AFF]/10 hover:bg-[#007AFF]/18 text-[#007AFF] border-[#007AFF]/25'
                    }`}
                  >
                    {savedSlots.studioDb ? (
                      <span>Saved ✓</span>
                    ) : (
                      <>
                        <Save className="w-3 h-3 shrink-0" aria-hidden="true" />
                        <span>Save Studio DB</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <input
                  aria-label="Studio Supabase URL"
                  type="url"
                  value={draft.studioSupabaseUrl ?? ''}
                  onChange={(e) => updateField('studioSupabaseUrl', e.target.value)}
                  placeholder="https://your-studio-project.supabase.co"
                  className={`${inputBaseClass} font-mono text-[11px]`}
                />
                <div className="relative flex items-center">
                  <input
                    aria-label="Studio Supabase Anon Key"
                    type={visible.studioSupabase ? 'text' : 'password'}
                    value={draft.studioSupabaseAnonKey ?? ''}
                    onChange={(e) =>
                      updateField('studioSupabaseAnonKey', e.target.value)
                    }
                    placeholder="Studio Supabase Anon Key (eyJ...)"
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono text-[11px]`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('studioSupabase')}
                    aria-label={
                      visible.studioSupabase
                        ? 'Hide Studio Supabase key'
                        : 'Show Studio Supabase key'
                    }
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.studioSupabase ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* 2. Generated Apps Supabase (Exported Games/Apps Only) */}
            <div className="rounded-xl bg-[#F6FBF9] border border-[#10B981]/25 p-2.5 flex flex-col gap-2">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11.5px] font-bold text-[#0F172A]">
                  Generated Apps Supabase (Exported Games/Apps Only)
                </span>
                <button
                  type="button"
                  onClick={() => savePartialSecrets('appsDb')}
                  className={`h-7 px-2.5 rounded-lg border text-[11px] font-bold inline-flex items-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-95 ${
                    savedSlots.appsDb
                      ? 'bg-[#10B981] text-white border-[#10B981] shadow-xs'
                      : 'bg-[#10B981]/12 hover:bg-[#10B981]/20 text-[#047857] border-[#10B981]/30'
                  }`}
                >
                  {savedSlots.appsDb ? (
                    <span>Saved ✓</span>
                  ) : (
                    <>
                      <Save className="w-3 h-3 shrink-0" aria-hidden="true" />
                      <span>Save Apps DB</span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex flex-col gap-1.5">
                <input
                  aria-label="Generated Apps Supabase URL"
                  type="url"
                  value={draft.appsSupabaseUrl ?? ''}
                  onChange={(e) => updateField('appsSupabaseUrl', e.target.value)}
                  placeholder="https://your-exported-apps.supabase.co"
                  className={`${inputBaseClass} font-mono text-[11px]`}
                />
                <div className="relative flex items-center">
                  <input
                    aria-label="Generated Apps Supabase Anon Key"
                    type={visible.appsSupabase ? 'text' : 'password'}
                    value={draft.appsSupabaseAnonKey ?? ''}
                    onChange={(e) =>
                      updateField('appsSupabaseAnonKey', e.target.value)
                    }
                    placeholder="Exported Apps Anon Key (eyJ...)"
                    autoComplete="off"
                    className={`${inputBaseClass} pr-10 font-mono text-[11px]`}
                  />
                  <button
                    type="button"
                    onClick={() => toggleShow('appsSupabase')}
                    aria-label={
                      visible.appsSupabase
                        ? 'Hide Generated Apps Supabase key'
                        : 'Show Generated Apps Supabase key'
                    }
                    className="absolute right-1.5 w-8 h-8 rounded-lg text-[#64748B] hover:text-[#0F172A] flex items-center justify-center cursor-pointer"
                  >
                    {visible.appsSupabase ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Sticky Footer */}
        <div className="px-3.5 sm:px-5 py-3 bg-white/92 backdrop-blur-xl border-t border-slate-200/80 shrink-0 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          <button
            type="button"
            onClick={handleSaveAndLock}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-[#007AFF] via-[#5856D6] to-[#10B981] hover:brightness-105 active:scale-[0.98] text-white text-[13px] font-bold inline-flex items-center justify-center gap-2 shadow-[0_6px_18px_rgba(0,122,255,0.28)] transition-all cursor-pointer"
          >
            <Lock className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>Save &amp; Lock Secrets</span>
          </button>
        </div>
      </div>
    </div>
  );
}
