import { useEffect, useState, type FormEvent } from 'react';
import {
  FileCode2,
  Save,
  RotateCcw,
  Copy,
  Check,
  X,
  ChevronDown,
  Sparkles,
  Loader2,
  CheckCheck,
  AlertCircle,
} from 'lucide-react';
import type { Language, VirtualFile } from '../types/studio';

export interface PendingAIEditState {
  backupFiles: VirtualFile[];
  changedPaths: string[];
  summary: string;
  providerUsed: string;
}

interface CodePanelProps {
  open: boolean;
  files: VirtualFile[];
  activeFilePath: string | null;
  language: Language;
  pendingAIEdit?: PendingAIEditState | null;
  isAIEditing?: boolean;
  aiEditError?: string | null;
  onSelectFile: (path: string) => void;
  onSaveFile: (path: string, content: string) => void;
  onRunAIEdit?: (instruction: string) => void;
  onKeepAllEdits?: () => void;
  onRevertAIEdit?: () => void;
  onClose: () => void;
}

export function CodePanel({
  open,
  files,
  activeFilePath,
  language,
  pendingAIEdit = null,
  isAIEditing = false,
  aiEditError = null,
  onSelectFile,
  onSaveFile,
  onRunAIEdit,
  onKeepAllEdits,
  onRevertAIEdit,
  onClose,
}: CodePanelProps) {
  const activeFile =
    files.find((f) => f.path === activeFilePath) ?? files[0] ?? null;

  const [draft, setDraft] = useState(activeFile?.content ?? '');
  const [copied, setCopied] = useState(false);
  const [justSaved, setJustSaved] = useState(false);
  const [aiInstruction, setAiInstruction] = useState('');

  // Sync draft when selected file or saved content changes
  useEffect(() => {
    setDraft(activeFile?.content ?? '');
    setJustSaved(false);
  }, [activeFile?.path, activeFile?.content]);

  if (!open) return null;

  const isDirty = activeFile ? draft !== activeFile.content : false;
  const lineCount = draft ? draft.split('\n').length : 0;

  const handleSave = () => {
    if (!activeFile) return;
    onSaveFile(activeFile.path, draft);
    setJustSaved(true);
    window.setTimeout(() => setJustSaved(false), 1800);
  };

  const handleRevert = () => {
    if (!activeFile) return;
    setDraft(activeFile.content);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(draft);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Fallback copy via temporary textarea if clipboard API is restricted
      const el = document.createElement('textarea');
      el.value = draft;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] bg-slate-900/25 backdrop-blur-[2px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Code Editor Panel"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl mx-auto bg-white/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-12px_40px_rgba(15,23,42,0.16)] px-3.5 sm:px-5 pt-2.5 pb-8 flex flex-col gap-2.5 max-h-[90dvh] sm:max-h-[84dvh] overflow-y-auto studio-scroll"
      >
        {/* Drag Handle (mobile) */}
        <div
          className="w-10 h-1 rounded-full bg-slate-300/90 mx-auto sm:hidden"
          aria-hidden="true"
        />

        {/* Sheet Header */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div
              className="w-8 h-8 rounded-xl bg-[#007AFF]/10 text-[#007AFF] flex items-center justify-center shrink-0"
              aria-hidden="true"
            >
              <FileCode2 className="w-4 h-4" />
            </div>

            {files.length > 0 && activeFile ? (
              <div className="relative min-w-0 flex-1 max-w-[230px] sm:max-w-xs">
                <label htmlFor="code-panel-file-select" className="sr-only">
                  Select file to edit
                </label>
                <select
                  id="code-panel-file-select"
                  value={activeFile.path}
                  onChange={(e) => onSelectFile(e.target.value)}
                  className="w-full appearance-none h-8 pl-2.5 pr-7 rounded-xl bg-[#F6F9FE] border border-slate-200/90 font-mono text-[11.5px] font-semibold text-[#0F172A] truncate focus:outline-none focus:border-[#007AFF] cursor-pointer"
                >
                  {files.map((file) => (
                    <option key={file.path} value={file.path}>
                      {file.path}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  className="w-3.5 h-3.5 text-[#64748B] pointer-events-none absolute right-2 top-1/2 -translate-y-1/2"
                  aria-hidden="true"
                />
              </div>
            ) : (
              <h3 className="text-[13.5px] font-bold text-[#0F172A] truncate">
                Code Editor
              </h3>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close code editor"
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live AI File Edit Instruction Bar */}
        {onRunAIEdit && (
          <form
            onSubmit={(e: FormEvent) => {
              e.preventDefault();
              const clean = aiInstruction.trim();
              if (!clean || isAIEditing) return;
              onRunAIEdit(clean);
              setAiInstruction('');
            }}
            className="flex items-center gap-1.5 w-full min-w-0"
          >
            <div className="relative flex-1 min-w-0">
              <Sparkles
                className="w-3.5 h-3.5 text-[#5856D6] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="text"
                value={aiInstruction}
                onChange={(e) => setAiInstruction(e.target.value)}
                disabled={isAIEditing}
                placeholder={
                  language === 'hi'
                    ? 'AI एडिट: जैसे "हीरो कार्ड और बटन जोड़ो"...'
                    : 'AI Edit: e.g. "add an interactive score counter"...'
                }
                aria-label="AI file edit instruction"
                className="w-full min-w-0 h-9 pl-8 pr-2.5 rounded-xl bg-[#F6F9FE] border border-[#5856D6]/25 text-[11.5px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#5856D6] focus:ring-2 focus:ring-[#5856D6]/15"
              />
            </div>
            <button
              type="submit"
              disabled={isAIEditing || !aiInstruction.trim()}
              className="h-9 px-3 rounded-xl bg-gradient-to-r from-[#5856D6] to-[#007AFF] hover:brightness-105 disabled:opacity-50 text-white text-[11.5px] font-bold inline-flex items-center gap-1 shadow-xs transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-[0.98]"
            >
              {isAIEditing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" aria-hidden="true" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              )}
              <span>{isAIEditing ? 'Editing...' : 'AI Edit'}</span>
            </button>
          </form>
        )}

        {/* AI Edit Error Banner */}
        {aiEditError && !isAIEditing && (
          <div className="rounded-xl bg-[#FF3B30]/10 border border-[#FF3B30]/25 px-2.5 py-1.5 flex items-center gap-1.5 text-[11px] font-medium text-[#DC2626]">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            <span className="truncate">{aiEditError}</span>
          </div>
        )}

        {/* Frosted Staging Banner: Keep All (Apple-emerald) | Revert (coral) */}
        {pendingAIEdit && onKeepAllEdits && onRevertAIEdit && (
          <div className="rounded-2xl bg-gradient-to-r from-[#10B981]/10 via-white/95 to-[#007AFF]/10 backdrop-blur-xl border border-[#10B981]/35 px-3 py-2 flex flex-col gap-2 shadow-2xs">
            <div className="flex items-start justify-between gap-2 min-w-0">
              <div className="min-w-0">
                <p className="text-[11.5px] font-bold text-[#0F172A] line-clamp-1">
                  {pendingAIEdit.summary}
                </p>
                <p className="text-[10px] font-mono text-[#64748B] truncate mt-0.5">
                  {pendingAIEdit.changedPaths.length} file
                  {pendingAIEdit.changedPaths.length === 1 ? '' : 's'} ·{' '}
                  {pendingAIEdit.changedPaths.join(', ')} · {pendingAIEdit.providerUsed}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={onKeepAllEdits}
                className="h-8 px-2.5 rounded-xl bg-gradient-to-r from-[#10B981] to-[#059669] hover:brightness-105 text-white text-[11.5px] font-bold inline-flex items-center justify-center gap-1 shadow-xs transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap"
              >
                <CheckCheck className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>Keep All</span>
              </button>
              <button
                type="button"
                onClick={onRevertAIEdit}
                className="h-8 px-2.5 rounded-xl bg-[#FF3B30]/12 hover:bg-[#FF3B30]/20 border border-[#FF3B30]/30 text-[#DC2626] text-[11.5px] font-bold inline-flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-[0.98] whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>Revert</span>
              </button>
            </div>
          </div>
        )}

        {/* File Path & Line Count Metadata Strip */}
        {activeFile && (
          <div className="flex items-center justify-between gap-2 px-1 text-[11px] text-[#64748B]">
            <div className="flex items-center gap-1.5 min-w-0">
              <span className="font-mono font-semibold text-[#0F172A] truncate">
                {activeFile.path}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono uppercase text-[10px] shrink-0">
                {activeFile.language}
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono tabular-nums shrink-0">
              <span>{lineCount} lines</span>
              <span aria-hidden="true">·</span>
              <span
                className={
                  isDirty
                    ? 'text-[#F59E0B] font-semibold'
                    : justSaved
                      ? 'text-[#10B981] font-semibold'
                      : 'text-[#64748B]'
                }
              >
                {isDirty ? 'Modified' : justSaved ? 'Saved' : 'Synced'}
              </span>
            </div>
          </div>
        )}

        {/* Editable Monospace Textarea */}
        {activeFile ? (
          <div className="flex-1 min-h-0 flex flex-col">
            <label htmlFor="studio-code-textarea" className="sr-only">
              Code editor for {activeFile.path}
            </label>
            <textarea
              id="studio-code-textarea"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              spellCheck={false}
              autoCapitalize="off"
              autoCorrect="off"
              className="w-full flex-1 min-h-[200px] sm:min-h-[280px] p-3 rounded-2xl bg-[#F8FAFD] border border-slate-200/90 font-mono text-[12px] leading-[1.55] text-[#0F172A] resize-none focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15 studio-scroll"
            />
          </div>
        ) : (
          <div className="rounded-2xl bg-[#F8FAFD] border border-dashed border-slate-300 p-6 text-center text-[12.5px] text-[#64748B]">
            {language === 'hi'
              ? 'संपादित करने के लिए कोई फ़ाइल नहीं है। फ़ाइल ड्रॉअर से नई फ़ाइल जोड़ें।'
              : 'No files available. Create a file in the File Drawer to start editing.'}
          </div>
        )}

        {/* Action Buttons Row fitting 360px cleanly */}
        <div className="grid grid-cols-[1fr_auto_auto] gap-1.5 pt-0.5">
          <button
            type="button"
            onClick={handleSave}
            disabled={!activeFile || !isDirty}
            className="h-10 px-3 rounded-xl bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-45 text-white text-[12px] font-semibold inline-flex items-center justify-center gap-1.5 shadow-[0_3px_12px_rgba(0,122,255,0.25)] transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
          >
            {justSaved ? (
              <Check className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            ) : (
              <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            )}
            <span>
              {justSaved
                ? language === 'hi'
                  ? 'सहेजा गया'
                  : 'Saved'
                : language === 'hi'
                  ? 'बदलाव सहेजें'
                  : 'Save Changes'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleRevert}
            disabled={!activeFile || !isDirty}
            className="h-10 px-3 rounded-xl bg-white border border-slate-200/90 hover:bg-slate-50 disabled:opacity-45 text-[#0F172A] text-[12px] font-semibold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
          >
            <RotateCcw className="w-3.5 h-3.5 shrink-0 text-[#F59E0B]" aria-hidden="true" />
            <span>{language === 'hi' ? 'रीवर्ट' : 'Revert'}</span>
          </button>

          <button
            type="button"
            onClick={handleCopy}
            disabled={!activeFile}
            className="h-10 px-3 rounded-xl bg-white border border-slate-200/90 hover:bg-slate-50 disabled:opacity-45 text-[#0F172A] text-[12px] font-semibold inline-flex items-center justify-center gap-1 transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 shrink-0 text-[#10B981]" aria-hidden="true" />
            ) : (
              <Copy className="w-3.5 h-3.5 shrink-0 text-[#007AFF]" aria-hidden="true" />
            )}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
